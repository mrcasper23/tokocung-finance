import React, { useState } from 'react';
import { useFinance } from '../../context/FinanceContext';
import { formatRupiah, formatDate, downloadCSV, printReport } from '../../utils/formatters';
import { Plus, Landmark, TrendingUp, TrendingDown, FileSpreadsheet, Eye, Printer, X, CheckCircle2 } from 'lucide-react';
import { NonOperatingTransaction } from '../../types/finance';

export const NonOperatingModule: React.FC = () => {
  const { nonOperating, addNonOperating, entities } = useFinance();
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedNonOp, setSelectedNonOp] = useState<NonOperatingTransaction | null>(null);

  // Form state
  const [date, setDate] = useState('2026-03-31');
  const [category, setCategory] = useState<'Pendapatan Bunga' | 'Beban Bunga' | 'Pendapatan Lainnya' | 'Beban Lainnya'>('Pendapatan Bunga');
  const [amount, setAmount] = useState(3000000);
  const [description, setDescription] = useState('');
  const [entityId, setEntityId] = useState(entities[0]?.id || 'cung-retail');

  const totalIncome = nonOperating
    .filter(n => n.category === 'Pendapatan Bunga' || n.category === 'Pendapatan Lainnya')
    .reduce((sum, n) => sum + n.amount, 0);

  const totalExpense = nonOperating
    .filter(n => n.category === 'Beban Bunga' || n.category === 'Beban Lainnya')
    .reduce((sum, n) => sum + n.amount, 0);

  const netNonOp = totalIncome - totalExpense;

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    addNonOperating({
      date,
      category,
      amount,
      description,
      entityId,
      isDemo: false,
    });
    setShowAddModal(false);
    setDescription('');
  };

  const handleExport = () => {
    const headers = ['Tanggal', 'Entitas', 'Kategori', 'Nominal', 'Deskripsi'];
    const rows = nonOperating.map(n => [
      n.date,
      n.entityId,
      n.category,
      n.amount,
      n.description
    ]);
    downloadCSV('Laporan_Non_Operating_TokoCung', headers, rows);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="bg-white border border-slate-200/90 rounded-xl p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Non-Operating Income & Expense</h1>
          <p className="text-xs text-slate-500 mt-1">
            Pendapatan dan beban non-operasional: bunga bank, provisi kredit, dan lain-lain yang otomatis mempengaruhi <span className="font-semibold text-slate-700">EBT</span>.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExport}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border border-slate-200 hover:bg-slate-50 text-slate-700 transition-colors cursor-pointer"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={() => setShowAddModal(true)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white transition-colors cursor-pointer shadow-2xs"
          >
            <Plus className="w-4 h-4" />
            <span>+ Catat Transaksi Non-Op</span>
          </button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <span className="text-slate-500 font-medium block">Total Pendapatan Non-Operasional</span>
          <span className="text-lg font-bold text-emerald-600 font-mono tabular-nums">+{formatRupiah(totalIncome)}</span>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <span className="text-slate-500 font-medium block">Total Beban Bunga & Non-Op</span>
          <span className="text-lg font-bold text-rose-600 font-mono tabular-nums">-{formatRupiah(totalExpense)}</span>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <span className="text-slate-500 font-medium block">Net Dampak terhadap EBT</span>
          <span className={`text-lg font-bold font-mono tabular-nums ${netNonOp >= 0 ? 'text-indigo-700' : 'text-amber-700'}`}>
            {netNonOp >= 0 ? `+${formatRupiah(netNonOp)}` : formatRupiah(netNonOp)}
          </span>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                <th className="py-3 px-3">Tanggal</th>
                <th className="py-3 px-3">Entitas</th>
                <th className="py-3 px-3">Kategori</th>
                <th className="py-3 px-3">Keterangan / Transaksi</th>
                <th className="py-3 px-3 text-right">Nominal</th>
                <th className="py-3 px-3 text-center">Dampak EBT</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {nonOperating.map(n => {
                const isIncome = n.category === 'Pendapatan Bunga' || n.category === 'Pendapatan Lainnya';

                return (
                  <tr
                    key={n.id}
                    onClick={() => setSelectedNonOp(n)}
                    className="hover:bg-slate-50/90 transition-colors cursor-pointer group"
                  >
                    <td className="py-2.5 px-3 text-slate-600">{formatDate(n.date)}</td>
                    <td className="py-2.5 px-3 font-medium text-slate-700">
                      {entities.find(e => e.id === n.entityId)?.code || n.entityId}
                    </td>
                    <td className="py-2.5 px-3">
                      <span className={`px-2 py-0.5 rounded text-[11px] font-semibold ${
                        isIncome ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'
                      }`}>
                        {n.category}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-slate-800 font-medium">
                      <div className="flex items-center gap-1.5 group-hover:text-blue-700">
                        <span>{n.description}</span>
                        <Eye className="w-3.5 h-3.5 text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                      </div>
                    </td>
                    <td className={`py-2.5 px-3 text-right font-mono font-bold tabular-nums ${
                      isIncome ? 'text-emerald-700' : 'text-rose-700'
                    }`}>
                      {isIncome ? `+${formatRupiah(n.amount)}` : `-${formatRupiah(n.amount)}`}
                    </td>
                    <td className="py-2.5 px-3 text-center">
                      <span className="text-[11px] text-slate-500">
                        {isIncome ? 'Menambah EBT' : 'Mengurangi EBT'}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Non Operating Detail Modal */}
      {selectedNonOp && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 animate-in fade-in">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-lg w-full flex flex-col text-xs overflow-hidden animate-in zoom-in-95">
            <div className="p-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Landmark className="w-4 h-4 text-slate-700" />
                <span className="font-bold text-slate-900 text-sm">Voucher Non-Operasional</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={printReport}
                  className="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-100 text-slate-600 cursor-pointer"
                  title="Cetak Bukti"
                >
                  <Printer className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setSelectedNonOp(null)}
                  className="w-8 h-8 rounded-lg border border-slate-200 flex items-center justify-center text-slate-400 hover:text-slate-800 hover:bg-slate-100 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="p-5 space-y-4">
              <div className="p-4 rounded-xl bg-slate-900 text-white flex justify-between items-center">
                <div>
                  <span className="text-[10px] text-slate-400 block uppercase">Nominal Transaksi</span>
                  <span className="text-xl font-bold font-mono text-white">{formatRupiah(selectedNonOp.amount)}</span>
                </div>
                <span className={`px-2.5 py-1 rounded-full text-xs font-semibold ${
                  selectedNonOp.category === 'Pendapatan Bunga' || selectedNonOp.category === 'Pendapatan Lainnya'
                    ? 'bg-emerald-600 text-white'
                    : 'bg-rose-600 text-white'
                }`}>
                  {selectedNonOp.category}
                </span>
              </div>

              <div className="border border-slate-200 rounded-xl p-3.5 space-y-2 bg-slate-50">
                <div className="grid grid-cols-2 gap-2 text-[11px]">
                  <div>
                    <span className="text-slate-500 block">Tanggal:</span>
                    <span className="font-medium text-slate-800">{formatDate(selectedNonOp.date)}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Entitas:</span>
                    <span className="font-medium text-slate-800">
                      {entities.find(e => e.id === selectedNonOp.entityId)?.name || selectedNonOp.entityId}
                    </span>
                  </div>
                  <div className="col-span-2">
                    <span className="text-slate-500 block">Keterangan:</span>
                    <span className="font-semibold text-slate-900">{selectedNonOp.description}</span>
                  </div>
                </div>
              </div>

              <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3 flex items-center gap-2.5 text-emerald-900 text-[11px]">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <div>
                  <span className="font-semibold">Pengaruh ke EBT:</span> Transaksi ini secara langsung memengaruhi Laba Sebelum Pajak (EBT) pada periode berjalan tanpa melalui perhitungan EBITDA operasional.
                </div>
              </div>
            </div>

            <div className="p-3 border-t border-slate-200 bg-slate-50 flex justify-end">
              <button
                onClick={() => setSelectedNonOp(null)}
                className="px-4 py-1.5 rounded-lg text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white cursor-pointer"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Add Non Op */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-md w-full p-6 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h3 className="text-sm font-bold text-slate-900">Catat Transaksi Non-Operasional</h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-600">✕</button>
            </div>

            <form onSubmit={handleCreate} className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Tanggal</label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={e => setDate(e.target.value)}
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Entitas</label>
                  <select
                    value={entityId}
                    onChange={e => setEntityId(e.target.value)}
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                  >
                    {entities.map(e => (
                      <option key={e.id} value={e.id}>{e.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-600 font-medium mb-1">Kategori</label>
                <select
                  value={category}
                  onChange={e => setCategory(e.target.value as any)}
                  className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                >
                  <option value="Pendapatan Bunga">Pendapatan Bunga Deposito / Giro</option>
                  <option value="Beban Bunga">Beban Bunga Pinjaman Bank</option>
                  <option value="Pendapatan Lainnya">Pendapatan Lainnya</option>
                  <option value="Beban Lainnya">Beban Lainnya</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-600 font-medium mb-1">Nominal (Rp)</label>
                <input
                  type="number"
                  step={100000}
                  required
                  value={amount}
                  onChange={e => setAmount(Number(e.target.value))}
                  className="w-full border border-slate-200 rounded-lg p-2 text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-slate-600 font-medium mb-1">Keterangan</label>
                <input
                  type="text"
                  required
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  placeholder="Contoh: Bunga tabungan giro BCA bulan berjalan"
                  className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                />
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-600"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-semibold"
                >
                  Simpan Transaksi
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
