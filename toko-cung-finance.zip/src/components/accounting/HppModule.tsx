import React, { useState } from 'react';
import { useFinance } from '../../context/FinanceContext';
import { formatRupiah, formatDate, downloadCSV } from '../../utils/formatters';
import { Plus, Search, FileSpreadsheet, Package, Eye } from 'lucide-react';
import { HppDetailModal } from '../modals/HppDetailModal';
import { HppRecord } from '../../types/finance';

export const HppModule: React.FC = () => {
  const { hpp, addHpp, products, vendors } = useFinance();
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedHpp, setSelectedHpp] = useState<HppRecord | null>(null);

  // Form state
  const [date, setDate] = useState('2026-03-22');
  const [selectedProductId, setSelectedProductId] = useState(products[0]?.id || 'p1');
  const [qty, setQty] = useState(50);
  const [supplierName, setSupplierName] = useState(vendors[0]?.name || 'PT Indofood');
  const [poNumber, setPoNumber] = useState('PO-2026-03-99');
  const [referenceNumber, setReferenceNumber] = useState('REF-2026-001');

  const prod = products.find(p => p.id === selectedProductId) || products[0];
  const unitCost = prod.costPrice;
  const calculatedTotalHpp = qty * unitCost;

  const filtered = hpp.filter(h =>
    h.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
    h.productName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    h.supplierName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    h.poNumber.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const totalHppValue = filtered.reduce((sum, h) => sum + h.totalHpp, 0);

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    addHpp({
      date,
      sku: prod.sku,
      productName: prod.name,
      qty,
      unitCost,
      totalHpp: calculatedTotalHpp,
      supplierName,
      poNumber,
      referenceNumber,
      isDemo: false,
    });

    setShowAddModal(false);
  };

  const handleExport = () => {
    const headers = ['Tanggal', 'SKU', 'Nama Produk', 'Qty', 'Harga Pokok Satuan', 'Total HPP', 'Supplier', 'No PO', 'Ref'];
    const rows = filtered.map(h => [
      h.date,
      h.sku,
      h.productName,
      h.qty,
      h.unitCost,
      h.totalHpp,
      h.supplierName,
      h.poNumber,
      h.referenceNumber
    ]);
    downloadCSV('Laporan_HPP_COGS_TokoCung', headers, rows);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="bg-white border border-slate-200/90 rounded-xl p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">HPP / COGS (Harga Pokok Penjualan)</h1>
          <p className="text-xs text-slate-500 mt-1">
            Pencatatan beban pokok barang dagangan: <span className="font-semibold text-slate-700">Total HPP = Qty × Harga Pokok</span>.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExport}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border border-slate-200 hover:bg-slate-50 text-slate-700 transition-colors cursor-pointer"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={() => setShowAddModal(true)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white transition-colors cursor-pointer shadow-2xs"
          >
            <Plus className="w-4 h-4" />
            <span>+ Catat HPP Baru</span>
          </button>
        </div>
      </div>

      {/* Filter and Stats */}
      <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-xs flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2 flex-1 max-w-sm border border-slate-200 rounded-lg px-2.5 py-1.5 bg-slate-50">
          <Search className="w-3.5 h-3.5 text-slate-400" />
          <input
            type="text"
            placeholder="Cari SKU, produk, supplier, atau nomor PO..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full bg-transparent outline-none text-xs text-slate-800 placeholder-slate-400"
          />
        </div>

        <div className="bg-slate-100 px-3 py-1 rounded-lg font-medium text-slate-700 text-xs tabular-nums">
          Total HPP: <span className="font-bold text-slate-900">{formatRupiah(totalHppValue)}</span>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                <th className="py-3 px-3">Tanggal</th>
                <th className="py-3 px-3">SKU</th>
                <th className="py-3 px-3">Nama Produk</th>
                <th className="py-3 px-3">Supplier</th>
                <th className="py-3 px-3 text-right">Qty</th>
                <th className="py-3 px-3 text-right">Harga Pokok (Unit)</th>
                <th className="py-3 px-3 text-right">Total HPP</th>
                <th className="py-3 px-3">No. PO & Ref</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map(h => (
                <tr
                  key={h.id}
                  onClick={() => setSelectedHpp(h)}
                  className="hover:bg-slate-50/90 transition-colors cursor-pointer group"
                >
                  <td className="py-2.5 px-3 text-slate-600">{formatDate(h.date)}</td>
                  <td className="py-2.5 px-3 font-mono font-semibold text-slate-900">
                    <div className="flex items-center gap-1.5 group-hover:text-blue-700">
                      <span>{h.sku}</span>
                      <Eye className="w-3.5 h-3.5 text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                  </td>
                  <td className="py-2.5 px-3 font-medium text-slate-800">{h.productName}</td>
                  <td className="py-2.5 px-3 text-slate-700">{h.supplierName}</td>
                  <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-700">{h.qty}</td>
                  <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-600">
                    {formatRupiah(h.unitCost)}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono font-bold tabular-nums text-slate-900">
                    {formatRupiah(h.totalHpp)}
                  </td>
                  <td className="py-2.5 px-3 font-mono text-[10px] text-slate-500">
                    <div>{h.poNumber}</div>
                    <div className="text-slate-400">{h.referenceNumber}</div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Detail Modal */}
      {selectedHpp && (
        <HppDetailModal
          hpp={selectedHpp}
          onClose={() => setSelectedHpp(null)}
        />
      )}

      {/* Modal Add HPP */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-md w-full p-6 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h3 className="text-sm font-bold text-slate-900">Catat HPP Barang Baru</h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-600">✕</button>
            </div>

            <form onSubmit={handleCreate} className="space-y-3">
              <div>
                <label className="block text-slate-600 font-medium mb-1">Tanggal</label>
                <input
                  type="date"
                  required
                  value={date}
                  onChange={e => setDate(e.target.value)}
                  className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                />
              </div>

              <div>
                <label className="block text-slate-600 font-medium mb-1">Pilih Produk</label>
                <select
                  value={selectedProductId}
                  onChange={e => setSelectedProductId(e.target.value)}
                  className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                >
                  {products.map(p => (
                    <option key={p.id} value={p.id}>
                      {p.sku} - {p.name} (HPP: {formatRupiah(p.costPrice)})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Kuantitas (Qty)</label>
                  <input
                    type="number"
                    min={1}
                    required
                    value={qty}
                    onChange={e => setQty(Number(e.target.value))}
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Supplier</label>
                  <input
                    type="text"
                    required
                    value={supplierName}
                    onChange={e => setSupplierName(e.target.value)}
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Nomor PO</label>
                  <input
                    type="text"
                    required
                    value={poNumber}
                    onChange={e => setPoNumber(e.target.value)}
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-medium mb-1">No. Referensi</label>
                  <input
                    type="text"
                    value={referenceNumber}
                    onChange={e => setReferenceNumber(e.target.value)}
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs font-mono"
                  />
                </div>
              </div>

              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg flex justify-between font-bold text-slate-900">
                <span>Total Nilai HPP:</span>
                <span className="font-mono text-rose-700">{formatRupiah(calculatedTotalHpp)}</span>
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-600"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-semibold"
                >
                  Simpan HPP
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
