import React from 'react';
import { useFinance } from '../../context/FinanceContext';
import { formatRupiah, downloadCSV, printReport } from '../../utils/formatters';
import { FileSpreadsheet, Printer, ShieldCheck } from 'lucide-react';

export const LaporanKeuanganModule: React.FC = () => {
  const { currentMonthPnl, yearlyPnlSummary, assets, cashFlowStatement, globalFilter } = useFinance();

  const isYtd = globalFilter.period === 'YTD';
  const pnl = isYtd ? yearlyPnlSummary : currentMonthPnl;

  // Approximate Balance Sheet items
  const kasDanBank = cashFlowStatement.endingCash;
  const piutangUsaha = Math.round(pnl.sales * 0.15);
  const persediaanBarang = Math.round(pnl.hpp * 0.6);
  const totalAktivaLancar = kasDanBank + piutangUsaha + persediaanBarang;

  const totalAsetTetapBruto = assets.reduce((s, a) => s + a.acquisitionCost, 0);
  const totalAkumulasiDepr = assets.reduce((s, a) => s + a.accumulatedDepreciation, 0);
  const asetTetapNetto = totalAsetTetapBruto - totalAkumulasiDepr;

  const totalAktiva = totalAktivaLancar + asetTetapNetto;

  // Liabilities & Equity
  const hutangUsaha = Math.round(pnl.hpp * 0.2);
  const hutangPajak = Math.round(pnl.incomeTax);
  const totalKewajiban = hutangUsaha + hutangPajak;

  const modalDisetor = 1_000_000_000;
  const labaDitahan = totalAktiva - totalKewajiban - modalDisetor;
  const totalEkuitas = modalDisetor + labaDitahan;

  const handleExport = () => {
    const headers = ['Pos Neraca Keuangan', 'Nilai (Rp)'];
    const rows = [
      ['Aset Lancar: Kas & Bank', kasDanBank],
      ['Aset Lancar: Piutang Usaha', piutangUsaha],
      ['Aset Lancar: Persediaan Barang Dagang', persediaanBarang],
      ['TOTAL ASET LANCAR', totalAktivaLancar],
      ['Aset Tetap Bruto', totalAsetTetapBruto],
      ['Akumulasi Penyusutan', -totalAkumulasiDepr],
      ['TOTAL ASET TETAP BERSIH', asetTetapNetto],
      ['TOTAL AKTIVA (ASET)', totalAktiva],
      ['Hutang Usaha (Trade Payables)', hutangUsaha],
      ['Hutang Pajak Badan', hutangPajak],
      ['TOTAL KEWAJIBAN (LIABILITAS)', totalKewajiban],
      ['Modal Disetor', modalDisetor],
      ['Laba Ditahan & Berjalan', labaDitahan],
      ['TOTAL EKUITAS', totalEkuitas],
      ['TOTAL KEWAJIBAN & EKUITAS', totalKewajiban + totalEkuitas],
    ];
    downloadCSV(`Neraca_Keuangan_TokoCung_${globalFilter.year}`, headers, rows);
  };

  return (
    <div className="space-y-6 pb-12 print-full-width">
      <div className="bg-white border border-slate-200/90 rounded-xl p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Laporan Keuangan Konsolidasi (Neraca & Posisi Keuangan)</h1>
          <p className="text-xs text-slate-500 mt-1">
            Posisi aktiva, kewajiban, dan ekuitas pemegang saham Toko Cung per {globalFilter.year}.
          </p>
        </div>

        <div className="flex items-center gap-2 no-print">
          <button
            onClick={handleExport}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white transition-colors cursor-pointer shadow-2xs"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={printReport}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Cetak PDF</span>
          </button>
        </div>
      </div>

      {/* Balance Sheet Columns: Aktiva vs Pasiva */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
        {/* Sisi Aktiva (Aset) */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-4">
          <div className="border-b border-slate-200 pb-2">
            <h2 className="text-sm font-bold text-slate-900">AKTIVA (ASET)</h2>
            <span className="text-[11px] text-slate-500">Sumber daya ekonomi perusahaan</span>
          </div>

          <div className="space-y-2">
            <div className="font-bold text-slate-800">ASET LANCAR</div>
            <div className="flex justify-between pl-3 py-1 border-b border-slate-100 text-slate-600">
              <span>Kas & Setara Kas</span>
              <span className="font-mono">{formatRupiah(kasDanBank)}</span>
            </div>
            <div className="flex justify-between pl-3 py-1 border-b border-slate-100 text-slate-600">
              <span>Piutang Usaha</span>
              <span className="font-mono">{formatRupiah(piutangUsaha)}</span>
            </div>
            <div className="flex justify-between pl-3 py-1 border-b border-slate-100 text-slate-600">
              <span>Persediaan Barang Dagangan</span>
              <span className="font-mono">{formatRupiah(persediaanBarang)}</span>
            </div>
            <div className="flex justify-between p-2 rounded bg-slate-50 font-semibold text-slate-800">
              <span>Total Aset Lancar</span>
              <span className="font-mono">{formatRupiah(totalAktivaLancar)}</span>
            </div>
          </div>

          <div className="space-y-2 pt-2">
            <div className="font-bold text-slate-800">ASET TETAP</div>
            <div className="flex justify-between pl-3 py-1 border-b border-slate-100 text-slate-600">
              <span>Nilai Perolehan Aset Tetap</span>
              <span className="font-mono">{formatRupiah(totalAsetTetapBruto)}</span>
            </div>
            <div className="flex justify-between pl-3 py-1 border-b border-slate-100 text-rose-600">
              <span>Akumulasi Penyusutan (Depresiasi)</span>
              <span className="font-mono">-{formatRupiah(totalAkumulasiDepr)}</span>
            </div>
            <div className="flex justify-between p-2 rounded bg-slate-50 font-semibold text-slate-800">
              <span>Nilai Buku Bersih Aset Tetap</span>
              <span className="font-mono">{formatRupiah(asetTetapNetto)}</span>
            </div>
          </div>

          <div className="p-3 bg-slate-900 text-white rounded-lg flex justify-between items-center font-bold text-sm mt-4">
            <span>TOTAL AKTIVA</span>
            <span className="font-mono text-emerald-300">{formatRupiah(totalAktiva)}</span>
          </div>
        </div>

        {/* Sisi Pasiva (Kewajiban & Ekuitas) */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-4">
          <div className="border-b border-slate-200 pb-2">
            <h2 className="text-sm font-bold text-slate-900">KEWAJIBAN & EKUITAS</h2>
            <span className="text-[11px] text-slate-500">Struktur permodalan & liabilitas</span>
          </div>

          <div className="space-y-2">
            <div className="font-bold text-slate-800">KEWAJIBAN (LIABILITAS)</div>
            <div className="flex justify-between pl-3 py-1 border-b border-slate-100 text-slate-600">
              <span>Hutang Usaha Dagang</span>
              <span className="font-mono">{formatRupiah(hutangUsaha)}</span>
            </div>
            <div className="flex justify-between pl-3 py-1 border-b border-slate-100 text-slate-600">
              <span>Hutang Pajak Penghasilan</span>
              <span className="font-mono">{formatRupiah(hutangPajak)}</span>
            </div>
            <div className="flex justify-between p-2 rounded bg-slate-50 font-semibold text-slate-800">
              <span>Total Kewajiban Lancar</span>
              <span className="font-mono">{formatRupiah(totalKewajiban)}</span>
            </div>
          </div>

          <div className="space-y-2 pt-2">
            <div className="font-bold text-slate-800">EKUITAS PEMILIK</div>
            <div className="flex justify-between pl-3 py-1 border-b border-slate-100 text-slate-600">
              <span>Modal Disetor Saham</span>
              <span className="font-mono">{formatRupiah(modalDisetor)}</span>
            </div>
            <div className="flex justify-between pl-3 py-1 border-b border-slate-100 text-slate-600">
              <span>Laba Ditahan & Laba Berjalan</span>
              <span className="font-mono text-emerald-700">{formatRupiah(labaDitahan)}</span>
            </div>
            <div className="flex justify-between p-2 rounded bg-slate-50 font-semibold text-slate-800">
              <span>Total Ekuitas</span>
              <span className="font-mono">{formatRupiah(totalEkuitas)}</span>
            </div>
          </div>

          <div className="p-3 bg-slate-900 text-white rounded-lg flex justify-between items-center font-bold text-sm mt-4">
            <span>TOTAL PASIVA</span>
            <span className="font-mono text-emerald-300">{formatRupiah(totalKewajiban + totalEkuitas)}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
