import React, { useMemo } from 'react';
import { useFinance } from '../../context/FinanceContext';
import { formatRupiah, formatCompactRupiah, downloadCSV, printReport, MONTH_SHORT_ID } from '../../utils/formatters';
import { StatCard } from '../common/StatCard';
import { BarChart, MultiLineChart } from '../common/SimpleChart';
import { Wallet, ArrowDownRight, ArrowUpRight, ShieldCheck, FileSpreadsheet, Printer } from 'lucide-react';

export const ArusKasModule: React.FC = () => {
  const { currentMonthPnl, cashFlowStatement, twelveMonthsPnl, capexRequests, globalFilter } = useFinance();

  const ocf = cashFlowStatement.operatingCashFlow;
  const icf = cashFlowStatement.investingCashFlow;
  const fcf = cashFlowStatement.financingCashFlow;

  // Monthly Cash Flow simulation across 12 months 2026
  const monthlyCashData = useMemo(() => {
    let runningCash = 850_000_000;
    return twelveMonthsPnl.map((m, idx) => {
      const monthNum = idx + 1;
      const monthCapex = capexRequests
        .filter(c => {
          if (!c.acquisitionDate) return false;
          const [y, mStr] = c.acquisitionDate.split('-').map(Number);
          return y === globalFilter.year && mStr === monthNum && (c.status === 'Paid' || c.status === 'Asset Created');
        })
        .reduce((sum, c) => sum + c.acquisitionCost, 0);

      const monthOcf = m.netProfit + m.totalDepreciation - Math.round(m.netProfit * 0.05);
      const monthNetFlow = monthOcf - monthCapex;
      runningCash += monthNetFlow;

      return {
        label: MONTH_SHORT_ID[idx],
        cashIn: m.sales,
        cashOut: m.hpp + m.totalOpex + monthCapex + m.incomeTax,
        netFlow: monthNetFlow,
        endingCash: runningCash,
        capexOutflow: monthCapex,
      };
    });
  }, [twelveMonthsPnl, capexRequests, globalFilter.year]);

  // Chart 1: Cash In vs Cash Out
  const cashInVsOutData = monthlyCashData.map(d => ({
    label: d.label,
    value: d.cashIn,
    secondaryValue: d.cashOut,
    color: 'bg-emerald-600',
  }));

  // Chart 2: Net Cash Movement
  const netMovementData = monthlyCashData.map(d => ({
    label: d.label,
    value: Math.max(0, d.netFlow),
    secondaryValue: d.capexOutflow,
    color: 'bg-blue-600',
  }));

  // Chart 3: Ending Cash Line
  const endingCashTrend = monthlyCashData.map(d => ({
    label: d.label,
    v1: d.endingCash,
  }));

  const handleExport = () => {
    const headers = ['Pos Arus Kas', 'Nominal (Rp)', 'Keterangan'];
    const rows = [
      ['Saldo Kas Awal', cashFlowStatement.beginningCash, 'Awal Bulan / Periode'],
      ['Laba Bersih (Net Profit)', ocf.netProfit, 'Dari Laporan Laba Rugi'],
      ['Penyusutan (Non-Cash Add back)', ocf.depreciation, 'Penambahan beban depresiasi'],
      ['Penyesuaian Modal Kerja (WC)', ocf.workingCapitalChange, 'Piutang & Persediaan'],
      ['TOTAL ARUS KAS OPERASI (OCF)', ocf.total, 'Arus Kas Operasional Inti'],
      ['Belanja Modal / CAPEX (Investing Outflow)', icf.capexOutflow, 'Pengeluaran kas aktiva tetap'],
      ['TOTAL ARUS KAS INVESTASI', icf.total, 'Arus Kas Investasi'],
      ['TOTAL ARUS KAS PENDANAAN', fcf.total, 'Pinjaman & Ekuitas'],
      ['KENAIKAN / (PENURUNAN) KAS BERSIH', cashFlowStatement.netCashFlow, 'Pergerakan Kas'],
      ['SALDO KAS AKHIR', cashFlowStatement.endingCash, 'Kas & Bank Akhir Periode'],
    ];
    downloadCSV(`Laporan_Arus_Kas_TokoCung_${globalFilter.year}`, headers, rows);
  };

  return (
    <div className="space-y-6 pb-12 print-full-width">
      {/* Header */}
      <div className="bg-white border border-slate-200/90 rounded-xl p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Laporan & Dashboard Arus Kas (Cash Flow)</h1>
          <p className="text-xs text-slate-500 mt-1">
            Rekonsiliasi arus kas metode tidak langsung: <span className="font-semibold text-slate-700">Operating + Investing (-CAPEX) + Financing = Net Cash Flow</span>.
          </p>
        </div>

        <div className="flex items-center gap-2 no-print">
          <button
            onClick={handleExport}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white transition-colors cursor-pointer shadow-2xs"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={printReport}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Cetak PDF</span>
          </button>
        </div>
      </div>

      {/* KPI Cards: Exact from prompt page 5 */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Saldo Kas Awal"
          value={formatCompactRupiah(cashFlowStatement.beginningCash)}
          subtitle={formatRupiah(cashFlowStatement.beginningCash)}
          indicatorText="Kas & Setara Kas Awal"
          icon={<Wallet className="w-4 h-4" />}
        />
        <StatCard
          title="Arus Kas Operasi (OCF)"
          value={formatCompactRupiah(ocf.total)}
          subtitle={`Net Profit + Depr: ${formatCompactRupiah(ocf.netProfit + ocf.depreciation)}`}
          indicatorText="Arus Kas Masuk Operasional"
          icon={<ArrowUpRight className="w-4 h-4 text-emerald-600" />}
        />
        <StatCard
          title="Arus Kas Investasi (CAPEX)"
          value={formatCompactRupiah(icf.total)}
          subtitle={`Belanja Modal: ${formatCompactRupiah(icf.capexOutflow)}`}
          indicatorText="Pengeluaran Modal Aktiva"
          icon={<ArrowDownRight className="w-4 h-4 text-amber-600" />}
        />
        <StatCard
          title="Saldo Kas Akhir"
          value={formatCompactRupiah(cashFlowStatement.endingCash)}
          subtitle={formatRupiah(cashFlowStatement.endingCash)}
          indicatorText="Likuiditas Tersedia Saat Ini"
          icon={<Wallet className="w-4 h-4 text-emerald-600" />}
        />
      </div>

      {/* Detailed Cash Flow Statement Statement Structure */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs">
        <h2 className="text-sm font-bold text-slate-900 mb-1">Struktur Formal Laporan Arus Kas</h2>
        <p className="text-xs text-slate-500 mb-4">Metode Tidak Langsung (Indirect Method) Sesuai Standar Akuntansi Keuangan</p>

        <div className="space-y-4 text-xs">
          {/* 1. Saldo Awal */}
          <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg flex justify-between items-center font-semibold text-slate-800">
            <span>SALDO KAS AWAL PERIODE</span>
            <span className="font-mono text-sm">{formatRupiah(cashFlowStatement.beginningCash)}</span>
          </div>

          {/* 2. Arus Kas dari Aktivitas Operasi */}
          <div className="border border-slate-200 rounded-lg p-3 space-y-2">
            <div className="font-bold text-slate-900 border-b border-slate-100 pb-1.5 flex justify-between">
              <span>ARUS KAS DARI AKTIVITAS OPERASI</span>
              <span className="text-emerald-700 font-mono">+{formatRupiah(ocf.total)}</span>
            </div>
            <div className="flex justify-between pl-3 text-slate-600">
              <span>Laba Bersih Tahun Berjalan (Net Profit)</span>
              <span className="font-mono">{formatRupiah(ocf.netProfit)}</span>
            </div>
            <div className="flex justify-between pl-3 text-slate-600">
              <span>Penyesuaian Beban Non-Kas: Beban Penyusutan (Depresiasi)</span>
              <span className="font-mono text-indigo-700">+{formatRupiah(ocf.depreciation)}</span>
            </div>
            <div className="flex justify-between pl-3 text-slate-600">
              <span>Penyesuaian Modal Kerja (Working Capital: Piutang & Persediaan)</span>
              <span className="font-mono text-slate-700">{formatRupiah(ocf.workingCapitalChange)}</span>
            </div>
          </div>

          {/* 3. Arus Kas dari Aktivitas Investasi */}
          <div className="border border-slate-200 rounded-lg p-3 space-y-2">
            <div className="font-bold text-slate-900 border-b border-slate-100 pb-1.5 flex justify-between">
              <span>ARUS KAS DARI AKTIVITAS INVESTASI</span>
              <span className="text-amber-800 font-mono">{formatRupiah(icf.total)}</span>
            </div>
            <div className="flex justify-between pl-3 text-slate-600">
              <span>Perolehan Aktiva Tetap & Renovasi Toko (CAPEX Outflow)</span>
              <span className="font-mono text-rose-600">-{formatRupiah(icf.capexOutflow)}</span>
            </div>
          </div>

          {/* 4. Arus Kas dari Aktivitas Pendanaan */}
          <div className="border border-slate-200 rounded-lg p-3 space-y-2">
            <div className="font-bold text-slate-900 border-b border-slate-100 pb-1.5 flex justify-between">
              <span>ARUS KAS DARI AKTIVITAS PENDANAAN</span>
              <span className="text-slate-800 font-mono">{formatRupiah(fcf.total)}</span>
            </div>
            <div className="flex justify-between pl-3 text-slate-600">
              <span>Penerimaan / Pembayaran Pinjaman Bank & Ekuitas</span>
              <span className="font-mono">Rp 0</span>
            </div>
          </div>

          {/* 5. Net Movement & Ending Cash */}
          <div className="pt-2 space-y-2">
            <div className="p-3 bg-slate-100 border border-slate-200 rounded-lg flex justify-between items-center font-bold text-slate-900">
              <span>KENAIKAN / (PENURUNAN) KAS BERSIH</span>
              <span className={`font-mono text-sm ${cashFlowStatement.netCashFlow >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
                {cashFlowStatement.netCashFlow >= 0 ? `+${formatRupiah(cashFlowStatement.netCashFlow)}` : formatRupiah(cashFlowStatement.netCashFlow)}
              </span>
            </div>

            <div className="p-3.5 bg-slate-900 text-white rounded-lg flex justify-between items-center font-bold border-2 border-slate-800">
              <span>SALDO KAS & BANK AKHIR PERIODE</span>
              <span className="font-mono text-base text-emerald-300">{formatRupiah(cashFlowStatement.endingCash)}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Charts Grid: Cash In vs Out & Ending Cash Trend */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 no-print">
        {/* Chart: Cash In vs Cash Out */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between mb-2">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Cash In vs Cash Out (2026)</h3>
              <p className="text-xs text-slate-500">Penerimaan dari sales vs total pengeluaran kas</p>
            </div>
          </div>
          <div className="h-56">
            <BarChart
              data={cashInVsOutData}
              primaryLegend="Cash In (Sales)"
              secondaryLegend="Cash Out (HPP+OPEX+CAPEX)"
              height={210}
            />
          </div>
        </div>

        {/* Chart: Ending Cash Trend */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between mb-2">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Tren Saldo Kas Akhir (Ending Cash)</h3>
              <p className="text-xs text-slate-500">Akumulasi likuiditas rekening kas dan bank Toko Cung</p>
            </div>
          </div>
          <div className="h-56">
            <MultiLineChart
              data={endingCashTrend}
              labels={[{ key: 'v1', name: 'Saldo Kas Akhir', color: '#059669' }]}
              height={210}
            />
          </div>
        </div>
      </div>
    </div>
  );
};
