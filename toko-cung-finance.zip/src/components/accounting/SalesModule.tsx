import React, { useState } from 'react';
import { useFinance } from '../../context/FinanceContext';
import { formatRupiah, formatDate, downloadCSV, printReport } from '../../utils/formatters';
import { SalesTransaction } from '../../types/finance';
import { Plus, Search, Filter, FileSpreadsheet, ArrowUpDown, ChevronLeft, ChevronRight, CheckCircle2, Eye, Printer, Building2, User } from 'lucide-react';

export const SalesModule: React.FC = () => {
  const { sales, addSales, entities, products, customers } = useFinance();
  const [searchTerm, setSearchTerm] = useState('');
  const [entityFilter, setEntityFilter] = useState('ALL');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedSales, setSelectedSales] = useState<SalesTransaction | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  // New sales form
  const [date, setDate] = useState('2026-03-25');
  const [entityId, setEntityId] = useState(entities[0]?.id || 'cung-retail');
  const [customerName, setCustomerName] = useState(customers[0]?.name || 'Supermarket Bahagia');
  const [selectedProduct, setSelectedProduct] = useState(products[0]?.id || 'p1');
  const [qty, setQty] = useState(25);
  const [discount, setDiscount] = useState(0);

  const productObj = products.find(p => p.id === selectedProduct) || products[0];
  const unitPrice = productObj?.sellingPrice || 50000;
  const calculatedSales = Math.max(0, qty * unitPrice - discount);

  const filtered = sales.filter(s => {
    const matchSearch =
      s.transactionNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.productName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchEntity = entityFilter === 'ALL' || s.entityId === entityFilter;
    const matchStatus = statusFilter === 'ALL' || s.status === statusFilter;
    return matchSearch && matchEntity && matchStatus;
  });

  const totalPages = Math.ceil(filtered.length / itemsPerPage) || 1;
  const paginated = filtered.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);
  const totalSalesAmount = filtered.reduce((sum, s) => sum + s.totalSales, 0);

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    const trxNum = `TRX-2026-${Date.now().toString().slice(-4)}`;

    addSales({
      transactionNumber: trxNum,
      date,
      entityId,
      customerName,
      productName: productObj.name,
      productCategory: productObj.category,
      qty,
      unitPrice,
      discount,
      totalSales: calculatedSales,
      status: 'Lunas',
      isDemo: false,
    });

    setShowAddModal(false);
  };

  const handleExport = () => {
    const headers = ['No Transaksi', 'Tanggal', 'Entitas', 'Customer', 'Produk', 'Kategori', 'Qty', 'Harga', 'Diskon', 'Total Penjualan', 'Status'];
    const rows = filtered.map(s => [
      s.transactionNumber,
      s.date,
      entities.find(e => e.id === s.entityId)?.name || s.entityId,
      s.customerName,
      s.productName,
      s.productCategory,
      s.qty,
      s.unitPrice,
      s.discount,
      s.totalSales,
      s.status
    ]);
    downloadCSV('Laporan_Penjualan_TokoCung', headers, rows);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="bg-white border border-slate-200/90 rounded-xl p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Modul Penjualan (Sales)</h1>
          <p className="text-xs text-slate-500 mt-1">
            Data transaksi penjualan konsolidasi anak usaha Toko Cung dengan pembaruan otomatis ke P&L.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExport}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border border-slate-200 hover:bg-slate-50 text-slate-700 transition-colors cursor-pointer"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
            <span>Export Excel</span>
          </button>
          <button
            onClick={() => setShowAddModal(true)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white transition-colors cursor-pointer shadow-2xs"
          >
            <Plus className="w-4 h-4" />
            <span>+ Input Penjualan Baru</span>
          </button>
        </div>
      </div>

      {/* Filter and Stats */}
      <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-xs flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2 flex-1 max-w-sm border border-slate-200 rounded-lg px-2.5 py-1.5 bg-slate-50">
          <Search className="w-3.5 h-3.5 text-slate-400" />
          <input
            type="text"
            placeholder="Cari transaksi, pelanggan, atau nama produk..."
            value={searchTerm}
            onChange={e => {
              setSearchTerm(e.target.value);
              setCurrentPage(1);
            }}
            className="w-full bg-transparent outline-none text-xs text-slate-800 placeholder-slate-400"
          />
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            <span className="text-slate-500 font-medium">Entitas:</span>
            <select
              value={entityFilter}
              onChange={e => {
                setEntityFilter(e.target.value);
                setCurrentPage(1);
              }}
              className="border border-slate-200 rounded-lg px-2 py-1 text-xs text-slate-700 bg-white"
            >
              <option value="ALL">Semua Entitas</option>
              {entities.map(e => (
                <option key={e.id} value={e.id}>{e.name}</option>
              ))}
            </select>
          </div>

          <div className="bg-slate-100 px-3 py-1 rounded-lg font-medium text-slate-700 text-xs tabular-nums">
            Total Nilai: <span className="font-bold text-slate-900">{formatRupiah(totalSalesAmount)}</span>
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                <th className="py-3 px-3">No. Transaksi</th>
                <th className="py-3 px-3">Tanggal</th>
                <th className="py-3 px-3">Entitas</th>
                <th className="py-3 px-3">Pelanggan (Customer)</th>
                <th className="py-3 px-3">Produk & Kategori</th>
                <th className="py-3 px-3 text-right">Qty</th>
                <th className="py-3 px-3 text-right">Harga Satuan</th>
                <th className="py-3 px-3 text-right">Total Penjualan</th>
                <th className="py-3 px-3 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {paginated.map(s => (
                <tr
                  key={s.id}
                  onClick={() => setSelectedSales(s)}
                  className="hover:bg-slate-50/90 transition-colors cursor-pointer group"
                >
                  <td className="py-2.5 px-3 font-semibold text-slate-900 font-mono">
                    <div className="flex items-center gap-1.5 group-hover:text-blue-700">
                      <span>{s.transactionNumber}</span>
                      <Eye className="w-3.5 h-3.5 text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                  </td>
                  <td className="py-2.5 px-3 text-slate-600">{formatDate(s.date)}</td>
                  <td className="py-2.5 px-3 font-medium text-slate-700">
                    {entities.find(e => e.id === s.entityId)?.code || s.entityId}
                  </td>
                  <td className="py-2.5 px-3 font-medium text-slate-900">{s.customerName}</td>
                  <td className="py-2.5 px-3">
                    <div className="font-semibold text-slate-800">{s.productName}</div>
                    <div className="text-[10px] text-slate-500">{s.productCategory}</div>
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-700">{s.qty}</td>
                  <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-600">
                    {formatRupiah(s.unitPrice)}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono font-bold tabular-nums text-slate-900">
                    {formatRupiah(s.totalSales)}
                  </td>
                  <td className="py-2.5 px-3 text-center">
                    <span className="px-2 py-0.5 rounded text-[11px] font-medium bg-emerald-50 text-emerald-700 border border-emerald-200/50">
                      {s.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination controls */}
        <div className="px-4 py-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
          <span>Menampilkan {(currentPage - 1) * itemsPerPage + 1} - {Math.min(currentPage * itemsPerPage, filtered.length)} dari {filtered.length} transaksi</span>
          <div className="flex items-center gap-1">
            <button
              onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="p-1.5 rounded hover:bg-slate-100 disabled:opacity-40 cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="px-2 font-medium text-slate-700">Hal {currentPage} / {totalPages}</span>
            <button
              onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="p-1.5 rounded hover:bg-slate-100 disabled:opacity-40 cursor-pointer"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* SALES INVOICE / RECEIPT DETAIL MODAL */}
      {selectedSales && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 animate-in fade-in">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-lg w-full flex flex-col text-xs overflow-hidden animate-in zoom-in-95">
            {/* Header */}
            <div className="p-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
              <div>
                <span className="font-mono text-base font-bold text-slate-900">{selectedSales.transactionNumber}</span>
                <div className="text-[11px] text-slate-500">Faktur Penjualan Toko Cung · {formatDate(selectedSales.date)}</div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={printReport}
                  className="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-100 text-slate-600"
                  title="Cetak Faktur"
                >
                  <Printer className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setSelectedSales(null)}
                  className="w-8 h-8 rounded-lg border border-slate-200 flex items-center justify-center text-slate-400 hover:text-slate-800 hover:bg-slate-100"
                >
                  ✕
                </button>
              </div>
            </div>

            {/* Content */}
            <div className="p-5 space-y-4">
              <div className="grid grid-cols-2 gap-3 p-3 bg-slate-50 border border-slate-200 rounded-xl">
                <div>
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Entitas Penjual</span>
                  <span className="font-semibold text-slate-800 text-xs">
                    {entities.find(e => e.id === selectedSales.entityId)?.name || selectedSales.entityId}
                  </span>
                </div>
                <div>
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Pelanggan</span>
                  <span className="font-semibold text-slate-900 text-xs">{selectedSales.customerName}</span>
                </div>
              </div>

              {/* Item Details */}
              <div className="border border-slate-200 rounded-xl overflow-hidden">
                <div className="bg-slate-100/70 p-2.5 font-bold text-slate-900 border-b border-slate-200 flex justify-between">
                  <span>Rincian Barang</span>
                  <span className="font-normal text-slate-500 text-[11px]">{selectedSales.productCategory}</span>
                </div>
                <div className="p-3.5 space-y-2">
                  <div className="flex justify-between text-sm font-semibold text-slate-900">
                    <span>{selectedSales.productName}</span>
                    <span className="font-mono">{selectedSales.qty} Unit</span>
                  </div>
                  <div className="flex justify-between text-slate-600 text-xs">
                    <span>Harga Satuan:</span>
                    <span className="font-mono">{formatRupiah(selectedSales.unitPrice)}</span>
                  </div>
                  {selectedSales.discount > 0 && (
                    <div className="flex justify-between text-rose-600 text-xs">
                      <span>Potongan Diskon:</span>
                      <span className="font-mono">-{formatRupiah(selectedSales.discount)}</span>
                    </div>
                  )}
                  <div className="pt-2 border-t border-slate-200 flex justify-between font-bold text-slate-950 text-sm">
                    <span>Total Penjualan Bersih:</span>
                    <span className="font-mono text-emerald-700">{formatRupiah(selectedSales.totalSales)}</span>
                  </div>
                </div>
              </div>

              <div className="p-3 bg-emerald-50 border border-emerald-200/60 rounded-xl flex items-center justify-between">
                <span className="text-emerald-900 font-medium">Status Pembayaran:</span>
                <span className="font-bold text-emerald-800 flex items-center gap-1">
                  <CheckCircle2 className="w-4 h-4" /> {selectedSales.status}
                </span>
              </div>
            </div>

            <div className="p-3.5 border-t border-slate-200 bg-slate-50 flex justify-end">
              <button
                onClick={() => setSelectedSales(null)}
                className="px-4 py-1.5 rounded-lg bg-slate-900 text-white font-semibold hover:bg-slate-800"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}


      {/* Modal Add Sales */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-md w-full p-6 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h3 className="text-sm font-bold text-slate-900">Input Transaksi Penjualan Baru</h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-600">✕</button>
            </div>

            <form onSubmit={handleCreate} className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Tanggal</label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={e => setDate(e.target.value)}
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Entitas</label>
                  <select
                    value={entityId}
                    onChange={e => setEntityId(e.target.value)}
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                  >
                    {entities.map(e => (
                      <option key={e.id} value={e.id}>{e.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-600 font-medium mb-1">Pelanggan (Customer)</label>
                <select
                  value={customerName}
                  onChange={e => setCustomerName(e.target.value)}
                  className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                >
                  {customers.map(c => (
                    <option key={c.id} value={c.name}>{c.name} ({c.category})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-600 font-medium mb-1">Pilih Produk</label>
                <select
                  value={selectedProduct}
                  onChange={e => setSelectedProduct(e.target.value)}
                  className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                >
                  {products.map(p => (
                    <option key={p.id} value={p.id}>
                      {p.name} - {formatRupiah(p.sellingPrice)}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Kuantitas (Qty)</label>
                  <input
                    type="number"
                    min={1}
                    required
                    value={qty}
                    onChange={e => setQty(Number(e.target.value))}
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Diskon (Rp)</label>
                  <input
                    type="number"
                    min={0}
                    value={discount}
                    onChange={e => setDiscount(Number(e.target.value))}
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs font-mono"
                  />
                </div>
              </div>

              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg flex justify-between font-bold text-slate-900">
                <span>Total Penjualan:</span>
                <span className="font-mono text-emerald-700">{formatRupiah(calculatedSales)}</span>
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-600"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-semibold"
                >
                  Simpan Penjualan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
