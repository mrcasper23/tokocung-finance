import React, { useState } from 'react';
import { useFinance } from '../../context/FinanceContext';
import { formatRupiah, formatDate, downloadCSV, printReport } from '../../utils/formatters';
import { Plus, Receipt, Settings, CheckCircle2, Clock, FileSpreadsheet, Eye, Printer, X, ShieldCheck } from 'lucide-react';
import { TaxTransaction } from '../../types/finance';

export const PajakModule: React.FC = () => {
  const { taxes, addTax, settings, updateSettings, currentMonthPnl, globalFilter } = useFinance();
  const [showAddModal, setShowAddModal] = useState(false);
  const [showTaxRateModal, setShowTaxRateModal] = useState(false);
  const [selectedTax, setSelectedTax] = useState<TaxTransaction | null>(null);

  // New Tax Form state
  const [taxPeriod, setTaxPeriod] = useState('2026-04');
  const [taxBase, setTaxBase] = useState(currentMonthPnl.ebt > 0 ? Math.round(currentMonthPnl.ebt) : 50000000);
  const [taxRate, setTaxRate] = useState(settings.taxRatePercent);
  const [status, setStatus] = useState<'Dihitung' | 'Disetor' | 'Tertunda'>('Dihitung');
  const [notes, setNotes] = useState('Estimasi PPh Badan Masa');
  const [tempTaxRate, setTempTaxRate] = useState(settings.taxRatePercent);

  const calculatedTaxAmount = Math.round(taxBase * (taxRate / 100));

  const totalTaxDeposited = taxes
    .filter(t => t.status === 'Disetor')
    .reduce((sum, t) => sum + t.taxAmount, 0);

  const totalTaxPending = taxes
    .filter(t => t.status !== 'Disetor')
    .reduce((sum, t) => sum + t.taxAmount, 0);

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    addTax({
      taxPeriod,
      taxBase,
      taxRate,
      taxAmount: calculatedTaxAmount,
      status,
      notes,
      paymentDate: status === 'Disetor' ? '2026-04-15' : undefined,
      isDemo: false,
    });
    setShowAddModal(false);
  };

  const handleSaveRate = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings({ taxRatePercent: tempTaxRate });
    setTaxRate(tempTaxRate);
    setShowTaxRateModal(false);
  };

  const handleExport = () => {
    const headers = ['Masa Pajak', 'Dasar Pengenaan Pajak (Tax Base)', 'Tarif Pajak (%)', 'Jumlah Pajak (PPh Badan)', 'Status', 'Tgl Setor', 'Keterangan'];
    const rows = taxes.map(t => [
      t.taxPeriod,
      t.taxBase,
      `${t.taxRate}%`,
      t.taxAmount,
      t.status,
      t.paymentDate || '-',
      t.notes || '-'
    ]);
    downloadCSV(`Laporan_Pajak_PPh_TokoCung_${globalFilter.year}`, headers, rows);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="bg-white border border-slate-200/90 rounded-xl p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Modul Perpajakan (Income Tax PPh Badan)</h1>
          <p className="text-xs text-slate-500 mt-1">
            Penghitungan dan penyetoran Pajak Penghasilan Badan berdasarkan laba sebelum pajak (EBT).
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowTaxRateModal(true)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border border-slate-200 hover:bg-slate-50 text-slate-700 transition-colors cursor-pointer"
          >
            <Settings className="w-3.5 h-3.5 text-slate-500" />
            <span>Atur Tarif ({settings.taxRatePercent}%)</span>
          </button>
          <button
            onClick={handleExport}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border border-slate-200 hover:bg-slate-50 text-slate-700 transition-colors cursor-pointer"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={() => setShowAddModal(true)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white transition-colors cursor-pointer shadow-2xs"
          >
            <Plus className="w-4 h-4" />
            <span>+ Catat Pajak Masa</span>
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <span className="text-slate-500 font-medium block">Tarif PPh Badan Efektif</span>
          <span className="text-lg font-bold text-slate-900 font-mono tabular-nums">{settings.taxRatePercent}%</span>
          <span className="text-[10px] text-slate-400 mt-0.5 block">Dapat diubah via Pengaturan</span>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <span className="text-slate-500 font-medium block">Total Pajak Telah Disetor</span>
          <span className="text-lg font-bold text-emerald-600 font-mono tabular-nums">{formatRupiah(totalTaxDeposited)}</span>
          <span className="text-[10px] text-slate-400 mt-0.5 block">Bukti setor NTPN terkonfirmasi</span>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <span className="text-slate-500 font-medium block">Kewajiban Pajak Dihitung / Tertunda</span>
          <span className="text-lg font-bold text-amber-600 font-mono tabular-nums">{formatRupiah(totalTaxPending)}</span>
          <span className="text-[10px] text-slate-400 mt-0.5 block">Akan disetor ke kas negara</span>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                <th className="py-3 px-3">Masa Pajak</th>
                <th className="py-3 px-3 text-right">Dasar Pengenaan Pajak (Tax Base)</th>
                <th className="py-3 px-3 text-center">Tarif Pajak</th>
                <th className="py-3 px-3 text-right">Nilai Pajak (Tax Amount)</th>
                <th className="py-3 px-3 text-center">Status</th>
                <th className="py-3 px-3">Tgl Setor</th>
                <th className="py-3 px-3">Keterangan</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {taxes.map(t => (
                <tr
                  key={t.id}
                  onClick={() => setSelectedTax(t)}
                  className="hover:bg-slate-50/90 transition-colors cursor-pointer group"
                >
                  <td className="py-2.5 px-3 font-semibold text-slate-900 font-mono">
                    <div className="flex items-center gap-1.5 group-hover:text-blue-700">
                      <span>Masa {t.taxPeriod}</span>
                      <Eye className="w-3.5 h-3.5 text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-700">
                    {formatRupiah(t.taxBase)}
                  </td>
                  <td className="py-2.5 px-3 text-center font-mono font-medium text-slate-800">
                    {t.taxRate}%
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono font-bold tabular-nums text-slate-900">
                    {formatRupiah(t.taxAmount)}
                  </td>
                  <td className="py-2.5 px-3 text-center">
                    <span className={`px-2 py-0.5 rounded text-[11px] font-medium ${
                      t.status === 'Disetor'
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200/50'
                        : 'bg-amber-50 text-amber-700 border border-amber-200/50'
                    }`}>
                      {t.status}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-slate-600">
                    {t.paymentDate ? formatDate(t.paymentDate) : '-'}
                  </td>
                  <td className="py-2.5 px-3 text-slate-600">{t.notes || '-'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Tax Detail Modal */}
      {selectedTax && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 animate-in fade-in">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-lg w-full flex flex-col text-xs overflow-hidden animate-in zoom-in-95">
            <div className="p-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Receipt className="w-4 h-4 text-slate-700" />
                <span className="font-bold text-slate-900 text-sm">Surat Setoran Pajak (SSP Masa {selectedTax.taxPeriod})</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={printReport}
                  className="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-100 text-slate-600 cursor-pointer"
                  title="Cetak Bukti Pajak"
                >
                  <Printer className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setSelectedTax(null)}
                  className="w-8 h-8 rounded-lg border border-slate-200 flex items-center justify-center text-slate-400 hover:text-slate-800 hover:bg-slate-100 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="p-5 space-y-4">
              <div className="p-4 rounded-xl bg-slate-900 text-white flex justify-between items-center">
                <div>
                  <span className="text-[10px] text-slate-400 block uppercase">Jumlah Pajak Disetor (PPh 25/29)</span>
                  <span className="text-xl font-bold font-mono text-white">{formatRupiah(selectedTax.taxAmount)}</span>
                </div>
                <span className={`px-2.5 py-1 rounded-full text-xs font-semibold ${
                  selectedTax.status === 'Disetor' ? 'bg-emerald-600 text-white' : 'bg-amber-600 text-white'
                }`}>
                  {selectedTax.status}
                </span>
              </div>

              <div className="border border-slate-200 rounded-xl p-3.5 space-y-2 bg-slate-50">
                <div className="font-bold text-slate-900 text-xs">Rincian Perhitungan Pajak:</div>
                <div className="space-y-1.5 text-[11px]">
                  <div className="flex justify-between py-1 border-b border-slate-100">
                    <span className="text-slate-600">Dasar Pengenaan Pajak (DPP):</span>
                    <span className="font-mono font-semibold text-slate-900">{formatRupiah(selectedTax.taxBase)}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-100">
                    <span className="text-slate-600">Tarif Pajak Efektif:</span>
                    <span className="font-mono font-semibold text-slate-900">{selectedTax.taxRate}%</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-100">
                    <span className="text-slate-600">Tanggal Penyetoran NTPN:</span>
                    <span className="font-medium text-slate-800">{selectedTax.paymentDate ? formatDate(selectedTax.paymentDate) : 'Menunggu Jadwal Setor'}</span>
                  </div>
                  <div className="flex justify-between py-1">
                    <span className="text-slate-600">Keterangan:</span>
                    <span className="font-medium text-slate-900">{selectedTax.notes || 'Estimasi Pajak Masa'}</span>
                  </div>
                </div>
              </div>

              <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3 flex items-center gap-2.5 text-emerald-900 text-[11px]">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <div>
                  <span className="font-semibold">Sinkronisasi P&L:</span> Beban pajak penghasilan ini mengurangi laba sebelum pajak (EBT) menjadi laba bersih akhir (Net Profit) tahun buku berjalan.
                </div>
              </div>
            </div>

            <div className="p-3 border-t border-slate-200 bg-slate-50 flex justify-end">
              <button
                onClick={() => setSelectedTax(null)}
                className="px-4 py-1.5 rounded-lg text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white cursor-pointer"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Configure Tax Rate */}
      {showTaxRateModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-sm w-full p-6 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h3 className="text-sm font-bold text-slate-900">Konfigurasi Tarif Pajak Penghasilan</h3>
              <button onClick={() => setShowTaxRateModal(false)} className="text-slate-400 hover:text-slate-600">✕</button>
            </div>

            <form onSubmit={handleSaveRate} className="space-y-4">
              <div>
                <label className="block text-slate-600 font-medium mb-1">Tarif PPh Badan (%)</label>
                <div className="relative">
                  <input
                    type="number"
                    step={0.5}
                    min={0}
                    max={100}
                    required
                    value={tempTaxRate}
                    onChange={e => setTempTaxRate(Number(e.target.value))}
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs font-mono pr-8"
                  />
                  <span className="absolute right-3 top-2 text-slate-400 font-mono">%</span>
                </div>
                <p className="text-[11px] text-slate-500 mt-1">
                  Tarif standar PPh Badan Indonesia saat ini adalah 22%. Mengubah nilai ini akan secara otomatis memperbarui formula perhitungan P&L.
                </p>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowTaxRateModal(false)}
                  className="px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-600"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-semibold"
                >
                  Simpan Tarif
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal Add Tax Transaction */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-md w-full p-6 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h3 className="text-sm font-bold text-slate-900">Catat Pajak Penghasilan Masa</h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-600">✕</button>
            </div>

            <form onSubmit={handleCreate} className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Masa Pajak (YYYY-MM)</label>
                  <input
                    type="month"
                    required
                    value={taxPeriod}
                    onChange={e => setTaxPeriod(e.target.value)}
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Status</label>
                  <select
                    value={status}
                    onChange={e => setStatus(e.target.value as any)}
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                  >
                    <option value="Dihitung">Dihitung (Calculated)</option>
                    <option value="Disetor">Disetor (Paid)</option>
                    <option value="Tertunda">Tertunda</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-600 font-medium mb-1">Dasar Pengenaan Pajak (Tax Base / EBT) (Rp)</label>
                <input
                  type="number"
                  step={1000000}
                  required
                  value={taxBase}
                  onChange={e => setTaxBase(Number(e.target.value))}
                  className="w-full border border-slate-200 rounded-lg p-2 text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-slate-600 font-medium mb-1">Keterangan</label>
                <input
                  type="text"
                  value={notes}
                  onChange={e => setNotes(e.target.value)}
                  placeholder="Catatan perpajakan..."
                  className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                />
              </div>

              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg flex justify-between font-bold text-slate-900">
                <span>Nilai Pajak ({taxRate}%):</span>
                <span className="font-mono text-rose-700">{formatRupiah(calculatedTaxAmount)}</span>
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-600"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-semibold"
                >
                  Simpan Pajak
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
