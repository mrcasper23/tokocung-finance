import React, { useState } from 'react';
import { useFinance } from '../../context/FinanceContext';
import { formatRupiah, downloadCSV } from '../../utils/formatters';
import { Plus, Users, FileSpreadsheet, CheckCircle2 } from 'lucide-react';

export const PayrollModule: React.FC = () => {
  const { payrolls, addPayroll } = useFinance();
  const [showAddModal, setShowAddModal] = useState(false);

  // Form state
  const [employeeName, setEmployeeName] = useState('');
  const [department, setDepartment] = useState('Operasional Toko');
  const [baseSalary, setBaseSalary] = useState(6500000);
  const [allowances, setAllowances] = useState(1000000);
  const [deductions, setDeductions] = useState(375000); // BPJS + PPh21
  const [period, setPeriod] = useState('2026-03');

  const calculatedNet = baseSalary + allowances - deductions;
  const totalPayroll = payrolls.reduce((sum, p) => sum + p.netSalary, 0);

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    addPayroll({
      period,
      employeeName,
      department,
      baseSalary,
      allowances,
      deductions,
      netSalary: calculatedNet,
      status: 'Dibayar',
      paymentDate: '2026-03-25',
      isDemo: false,
    });
    setShowAddModal(false);
    setEmployeeName('');
  };

  const handleExport = () => {
    const headers = ['Periode', 'Nama Karyawan', 'Departemen', 'Gaji Pokok', 'Tunjangan', 'Potongan (BPJS/PPh)', 'Gaji Bersih', 'Status'];
    const rows = payrolls.map(p => [
      p.period,
      p.employeeName,
      p.department,
      p.baseSalary,
      p.allowances,
      p.deductions,
      p.netSalary,
      p.status
    ]);
    downloadCSV('Laporan_Payroll_TokoCung', headers, rows);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="bg-white border border-slate-200/90 rounded-xl p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Payroll & Upah Karyawan</h1>
          <p className="text-xs text-slate-500 mt-1">
            Pengelolaan slip gaji karyawan, tunjangan operasional, dan potongan pajak PPh 21 / BPJS.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExport}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border border-slate-200 hover:bg-slate-50 text-slate-700 transition-colors cursor-pointer"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={() => setShowAddModal(true)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white transition-colors cursor-pointer shadow-2xs"
          >
            <Plus className="w-4 h-4" />
            <span>+ Input Data Gaji</span>
          </button>
        </div>
      </div>

      {/* Summary Card */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <span className="text-slate-500 font-medium block">Total Beban Gaji Bersih</span>
          <span className="text-lg font-bold text-slate-900 font-mono tabular-nums">{formatRupiah(totalPayroll)}</span>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <span className="text-slate-500 font-medium block">Jumlah Tenaga Kerja Aktif</span>
          <span className="text-lg font-bold text-slate-900 font-mono tabular-nums">{payrolls.length} Karyawan</span>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <span className="text-slate-500 font-medium block">Rata-rata Upah Take Home Pay</span>
          <span className="text-lg font-bold text-indigo-700 font-mono tabular-nums">
            {formatRupiah(payrolls.length > 0 ? totalPayroll / payrolls.length : 0)}
          </span>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                <th className="py-3 px-3">Periode</th>
                <th className="py-3 px-3">Nama Karyawan</th>
                <th className="py-3 px-3">Departemen / Posisi</th>
                <th className="py-3 px-3 text-right">Gaji Pokok</th>
                <th className="py-3 px-3 text-right">Tunjangan</th>
                <th className="py-3 px-3 text-right">Potongan (BPJS/PPh)</th>
                <th className="py-3 px-3 text-right">Gaji Bersih (Net)</th>
                <th className="py-3 px-3 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {payrolls.map(p => (
                <tr key={p.id} className="hover:bg-slate-50/70 transition-colors">
                  <td className="py-2.5 px-3 font-mono font-medium text-slate-700">{p.period}</td>
                  <td className="py-2.5 px-3 font-semibold text-slate-900">{p.employeeName}</td>
                  <td className="py-2.5 px-3 text-slate-600">{p.department}</td>
                  <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-700">{formatRupiah(p.baseSalary)}</td>
                  <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-700">+{formatRupiah(p.allowances)}</td>
                  <td className="py-2.5 px-3 text-right font-mono tabular-nums text-rose-600">-{formatRupiah(p.deductions)}</td>
                  <td className="py-2.5 px-3 text-right font-mono font-bold tabular-nums text-slate-900">{formatRupiah(p.netSalary)}</td>
                  <td className="py-2.5 px-3 text-center">
                    <span className="px-2 py-0.5 rounded text-[11px] font-medium bg-emerald-50 text-emerald-700 border border-emerald-200/50">
                      {p.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Add Payroll */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-md w-full p-6 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h3 className="text-sm font-bold text-slate-900">Input Data Penggajian Karyawan</h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-600">✕</button>
            </div>

            <form onSubmit={handleCreate} className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Periode</label>
                  <input
                    type="month"
                    required
                    value={period}
                    onChange={e => setPeriod(e.target.value)}
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Departemen</label>
                  <input
                    type="text"
                    required
                    value={department}
                    onChange={e => setDepartment(e.target.value)}
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-600 font-medium mb-1">Nama Karyawan</label>
                <input
                  type="text"
                  required
                  placeholder="Nama lengkap..."
                  value={employeeName}
                  onChange={e => setEmployeeName(e.target.value)}
                  className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                />
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Gaji Pokok</label>
                  <input
                    type="number"
                    step={100000}
                    required
                    value={baseSalary}
                    onChange={e => setBaseSalary(Number(e.target.value))}
                    className="w-full border border-slate-200 rounded p-1.5 text-xs font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Tunjangan</label>
                  <input
                    type="number"
                    step={50000}
                    value={allowances}
                    onChange={e => setAllowances(Number(e.target.value))}
                    className="w-full border border-slate-200 rounded p-1.5 text-xs font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Potongan</label>
                  <input
                    type="number"
                    step={25000}
                    value={deductions}
                    onChange={e => setDeductions(Number(e.target.value))}
                    className="w-full border border-slate-200 rounded p-1.5 text-xs font-mono"
                  />
                </div>
              </div>

              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg flex justify-between font-bold text-slate-900">
                <span>Total Gaji Bersih (Net):</span>
                <span className="font-mono text-emerald-700">{formatRupiah(calculatedNet)}</span>
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-600"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-semibold"
                >
                  Simpan Slip
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
