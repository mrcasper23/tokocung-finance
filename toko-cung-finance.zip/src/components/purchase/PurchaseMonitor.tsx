import React from 'react';
import { useFinance } from '../../context/FinanceContext';
import { formatRupiah, formatCompactRupiah, formatDate } from '../../utils/formatters';
import { StatCard } from '../common/StatCard';
import { ShoppingCart, ClipboardList, SlidersHorizontal, CheckCircle2 } from 'lucide-react';

export const PurchaseMonitor: React.FC = () => {
  const { purchaseOrders, priceAdjustments } = useFinance();

  const totalPoValue = purchaseOrders.reduce((sum, po) => sum + po.totalCost, 0);
  const activePriceAdjustments = priceAdjustments.filter(pa => pa.status === 'Aktif').length;

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="bg-white border border-slate-200/90 rounded-xl p-5 shadow-xs">
        <h1 className="text-xl font-bold text-slate-900 tracking-tight">Purchase Monitoring & Supply Chain</h1>
        <p className="text-xs text-slate-500 mt-1">
          Pengawasan pesanan pembelian (Purchase Orders) dari principal serta pengendalian riwayat penyesuaian harga beli.
        </p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <StatCard
          title="Total Pembelian PO"
          value={formatCompactRupiah(totalPoValue)}
          subtitle={formatRupiah(totalPoValue)}
          indicatorText={`${purchaseOrders.length} Purchase Order`}
          icon={<ShoppingCart className="w-4 h-4" />}
        />
        <StatCard
          title="Pesanan Diterima Lengkap"
          value={`${purchaseOrders.filter(po => po.status === 'Diterima Lengkap').length} PO`}
          subtitle="Stok Gudang Bertambah"
          indicatorText="Verifikasi Penerimaan"
          icon={<CheckCircle2 className="w-4 h-4 text-emerald-600" />}
        />
        <StatCard
          title="Penyesuaian Harga Aktif"
          value={`${activePriceAdjustments} Item Produk`}
          subtitle="Berdasarkan Perubahan Pasar"
          indicatorText="HPP Terupdate Otomatis"
          icon={<SlidersHorizontal className="w-4 h-4 text-indigo-600" />}
        />
      </div>

      {/* Table: Riwayat Purchase Orders Terkini */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
        <div className="px-5 py-3.5 border-b border-slate-100 flex items-center justify-between">
          <h2 className="text-sm font-bold text-slate-900">Purchase Orders Terakhir</h2>
          <span className="text-xs text-slate-500">{purchaseOrders.length} PO Aktif</span>
        </div>

        <div className="overflow-x-auto text-xs">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                <th className="py-2.5 px-3">No. PO</th>
                <th className="py-2.5 px-3">Tanggal Pesan</th>
                <th className="py-2.5 px-3">Supplier Principal</th>
                <th className="py-2.5 px-3 text-right">Total Unit/Item</th>
                <th className="py-2.5 px-3 text-right">Total Nilai Tagihan</th>
                <th className="py-2.5 px-3 text-center">Status Barang</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {purchaseOrders.map(po => (
                <tr key={po.id} className="hover:bg-slate-50">
                  <td className="py-2.5 px-3 font-semibold text-slate-900 font-mono">{po.poNumber}</td>
                  <td className="py-2.5 px-3 text-slate-600">{formatDate(po.date)}</td>
                  <td className="py-2.5 px-3 font-medium text-slate-800">{po.supplierName}</td>
                  <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-700">{po.totalItems}</td>
                  <td className="py-2.5 px-3 text-right font-mono font-bold tabular-nums text-slate-900">{formatRupiah(po.totalCost)}</td>
                  <td className="py-2.5 px-3 text-center">
                    <span className="px-2 py-0.5 rounded text-[11px] font-medium bg-slate-100 text-slate-800">
                      {po.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
