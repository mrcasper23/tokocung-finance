import React, { useState } from 'react';
import { useFinance } from '../../context/FinanceContext';
import { formatRupiah, formatDate, downloadCSV } from '../../utils/formatters';
import { Plus, Search, FileSpreadsheet, Eye } from 'lucide-react';
import { PoDetailModal } from '../modals/PoDetailModal';
import { PurchaseOrder } from '../../types/finance';

export const PurchaseOrders: React.FC = () => {
  const { purchaseOrders, addPurchaseOrder, vendors } = useFinance();
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedPo, setSelectedPo] = useState<PurchaseOrder | null>(null);

  // Form state
  const [supplierName, setSupplierName] = useState(vendors[0]?.name || 'PT Indofood');
  const [date, setDate] = useState('2026-03-26');
  const [totalItems, setTotalItems] = useState(500);
  const [totalCost, setTotalCost] = useState(45000000);
  const [status, setStatus] = useState<any>('Dipesan');

  const filtered = purchaseOrders.filter(po =>
    po.poNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
    po.supplierName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    const poNum = `PO-2026-${Date.now().toString().slice(-4)}`;
    addPurchaseOrder({
      poNumber: poNum,
      date,
      supplierName,
      totalItems,
      totalCost,
      status,
      isDemo: false,
    });
    setShowAddModal(false);
  };

  const handleExport = () => {
    const headers = ['No. PO', 'Tanggal', 'Supplier', 'Total Items', 'Total Nilai Tagihan', 'Status'];
    const rows = filtered.map(po => [
      po.poNumber,
      po.date,
      po.supplierName,
      po.totalItems,
      po.totalCost,
      po.status
    ]);
    downloadCSV('Daftar_Purchase_Orders_TokoCung', headers, rows);
  };

  return (
    <div className="space-y-6 pb-12">
      <div className="bg-white border border-slate-200/90 rounded-xl p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Purchase Orders (Pesanan Pembelian)</h1>
          <p className="text-xs text-slate-500 mt-1">
            Pencatatan surat pesanan pengadaan persediaan barang sembako & retail ke supplier rekanan.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExport}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border border-slate-200 hover:bg-slate-50 text-slate-700 transition-colors cursor-pointer"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={() => setShowAddModal(true)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white transition-colors cursor-pointer shadow-2xs"
          >
            <Plus className="w-4 h-4" />
            <span>+ Buat PO Baru</span>
          </button>
        </div>
      </div>

      {/* Filter and Search */}
      <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-xs flex items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2 flex-1 max-w-sm border border-slate-200 rounded-lg px-2.5 py-1.5 bg-slate-50">
          <Search className="w-3.5 h-3.5 text-slate-400" />
          <input
            type="text"
            placeholder="Cari nomor PO atau supplier..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full bg-transparent outline-none text-xs text-slate-800 placeholder-slate-400"
          />
        </div>
      </div>

      {/* Table */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                <th className="py-3 px-3">No. PO</th>
                <th className="py-3 px-3">Tanggal Pesan</th>
                <th className="py-3 px-3">Supplier Principal</th>
                <th className="py-3 px-3 text-right">Kuantitas Unit</th>
                <th className="py-3 px-3 text-right">Total Biaya PO</th>
                <th className="py-3 px-3 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map(po => (
                <tr
                  key={po.id}
                  onClick={() => setSelectedPo(po)}
                  className="hover:bg-slate-50/90 transition-colors cursor-pointer group"
                >
                  <td className="py-2.5 px-3 font-semibold text-slate-900 font-mono">
                    <div className="flex items-center gap-1.5 group-hover:text-blue-700">
                      <span>{po.poNumber}</span>
                      <Eye className="w-3.5 h-3.5 text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                  </td>
                  <td className="py-2.5 px-3 text-slate-600">{formatDate(po.date)}</td>
                  <td className="py-2.5 px-3 font-medium text-slate-800">{po.supplierName}</td>
                  <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-700">{po.totalItems}</td>
                  <td className="py-2.5 px-3 text-right font-mono font-bold tabular-nums text-slate-900">{formatRupiah(po.totalCost)}</td>
                  <td className="py-2.5 px-3 text-center">
                    <span className="px-2 py-0.5 rounded text-[11px] font-medium bg-slate-100 text-slate-700 border border-slate-200">
                      {po.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Detail Modal */}
      {selectedPo && (
        <PoDetailModal
          po={selectedPo}
          onClose={() => setSelectedPo(null)}
        />
      )}

      {/* Modal Add PO */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-md w-full p-6 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h3 className="text-sm font-bold text-slate-900">Buat Purchase Order Baru</h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-600">✕</button>
            </div>

            <form onSubmit={handleCreate} className="space-y-3">
              <div>
                <label className="block text-slate-600 font-medium mb-1">Tanggal PO</label>
                <input
                  type="date"
                  required
                  value={date}
                  onChange={e => setDate(e.target.value)}
                  className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                />
              </div>

              <div>
                <label className="block text-slate-600 font-medium mb-1">Supplier Principal</label>
                <select
                  value={supplierName}
                  onChange={e => setSupplierName(e.target.value)}
                  className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                >
                  {vendors.map(v => (
                    <option key={v.id} value={v.name}>{v.name}</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Jumlah Unit Barang</label>
                  <input
                    type="number"
                    min={1}
                    required
                    value={totalItems}
                    onChange={e => setTotalItems(Number(e.target.value))}
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Total Nilai Tagihan (Rp)</label>
                  <input
                    type="number"
                    step={100000}
                    required
                    value={totalCost}
                    onChange={e => setTotalCost(Number(e.target.value))}
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs font-mono"
                  />
                </div>
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-600"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-semibold"
                >
                  Terbitkan PO
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
