import React, { useState } from 'react';
import { useFinance } from '../../context/FinanceContext';
import { formatRupiah, formatDate, downloadCSV } from '../../utils/formatters';
import { Plus, SlidersHorizontal, ArrowRight, FileSpreadsheet } from 'lucide-react';

export const PriceAdjustments: React.FC = () => {
  const { priceAdjustments, addPriceAdjustment, products } = useFinance();
  const [showAddModal, setShowAddModal] = useState(false);

  // Form state
  const [selectedProductId, setSelectedProductId] = useState(products[0]?.id || 'p1');
  const [newPrice, setNewPrice] = useState(80000);
  const [effectiveDate, setEffectiveDate] = useState('2026-04-01');
  const [reason, setReason] = useState('Penyesuaian kenaikan harga komoditas global');

  const prod = products.find(p => p.id === selectedProductId) || products[0];

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    addPriceAdjustment({
      sku: prod.sku,
      productName: prod.name,
      oldPrice: prod.sellingPrice,
      newPrice,
      effectiveDate,
      reason,
      status: 'Aktif',
      isDemo: false,
    });
    setShowAddModal(false);
  };

  const handleExport = () => {
    const headers = ['SKU', 'Nama Produk', 'Harga Lama', 'Harga Baru Penyesuaian', 'Tanggal Berlaku', 'Alasan Penyesuaian', 'Status'];
    const rows = priceAdjustments.map(pa => [
      pa.sku,
      pa.productName,
      pa.oldPrice,
      pa.newPrice,
      pa.effectiveDate,
      pa.reason,
      pa.status
    ]);
    downloadCSV('Riwayat_Penyesuaian_Harga_TokoCung', headers, rows);
  };

  return (
    <div className="space-y-6 pb-12">
      <div className="bg-white border border-slate-200/90 rounded-xl p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Price Adjustments (Penyesuaian Harga Produk)</h1>
          <p className="text-xs text-slate-500 mt-1">
            Riwayat eskalasi atau penyesuaian harga jual & beli berdasarkan fluktuasi biaya pokok rantai pasok.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExport}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border border-slate-200 hover:bg-slate-50 text-slate-700 transition-colors cursor-pointer"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={() => setShowAddModal(true)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white transition-colors cursor-pointer shadow-2xs"
          >
            <Plus className="w-4 h-4" />
            <span>+ Buat Penyesuaian Harga</span>
          </button>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                <th className="py-3 px-3">SKU</th>
                <th className="py-3 px-3">Nama Produk</th>
                <th className="py-3 px-3 text-right">Harga Lama</th>
                <th className="py-3 px-3 text-center">Perubahan</th>
                <th className="py-3 px-3 text-right">Harga Baru</th>
                <th className="py-3 px-3">Tanggal Berlaku</th>
                <th className="py-3 px-3">Alasan Penyesuaian</th>
                <th className="py-3 px-3 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {priceAdjustments.map(pa => {
                const diff = pa.newPrice - pa.oldPrice;
                const pct = pa.oldPrice > 0 ? (diff / pa.oldPrice) * 100 : 0;

                return (
                  <tr key={pa.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-2.5 px-3 font-semibold text-slate-900 font-mono">{pa.sku}</td>
                    <td className="py-2.5 px-3 font-medium text-slate-800">{pa.productName}</td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-500">{formatRupiah(pa.oldPrice)}</td>
                    <td className="py-2.5 px-3 text-center">
                      <span className={`font-mono text-[11px] font-semibold ${diff >= 0 ? 'text-emerald-700' : 'text-rose-600'}`}>
                        {diff >= 0 ? `+${pct.toFixed(1)}%` : `${pct.toFixed(1)}%`}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono font-bold tabular-nums text-slate-900">{formatRupiah(pa.newPrice)}</td>
                    <td className="py-2.5 px-3 text-slate-600">{formatDate(pa.effectiveDate)}</td>
                    <td className="py-2.5 px-3 text-slate-600 max-w-[240px] truncate" title={pa.reason}>{pa.reason}</td>
                    <td className="py-2.5 px-3 text-center">
                      <span className="px-2 py-0.5 rounded text-[11px] font-medium bg-emerald-50 text-emerald-700 border border-emerald-200/50">
                        {pa.status}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Add Price Adjustment */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-md w-full p-6 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h3 className="text-sm font-bold text-slate-900">Penyesuaian Harga Baru</h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-600">✕</button>
            </div>

            <form onSubmit={handleCreate} className="space-y-3">
              <div>
                <label className="block text-slate-600 font-medium mb-1">Pilih Produk</label>
                <select
                  value={selectedProductId}
                  onChange={e => setSelectedProductId(e.target.value)}
                  className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                >
                  {products.map(p => (
                    <option key={p.id} value={p.id}>
                      {p.sku} - {p.name} (Harga Saat Ini: {formatRupiah(p.sellingPrice)})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Harga Baru (Rp)</label>
                  <input
                    type="number"
                    step={500}
                    required
                    value={newPrice}
                    onChange={e => setNewPrice(Number(e.target.value))}
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Tanggal Berlaku</label>
                  <input
                    type="date"
                    required
                    value={effectiveDate}
                    onChange={e => setEffectiveDate(e.target.value)}
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-600 font-medium mb-1">Alasan Penyesuaian</label>
                <input
                  type="text"
                  required
                  value={reason}
                  onChange={e => setReason(e.target.value)}
                  placeholder="Kenaikan HPP supplier / tarif pajak / promo..."
                  className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                />
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-600"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-semibold"
                >
                  Terapkan Penyesuaian
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
