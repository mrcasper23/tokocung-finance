import React from 'react';
import { useFinance } from '../../context/FinanceContext';
import { Shield, Check, X } from 'lucide-react';
import { UserRole } from '../../types/finance';

const ROLE_DEFINITIONS: {
  role: UserRole;
  title: string;
  scope: string;
  permissions: { module: string; access: 'Full' | 'Approval' | 'Input' | 'Read Only' | 'None' }[];
}[] = [
  {
    role: 'Director',
    title: 'Direksi Eksekutif',
    scope: 'Semua Dashboard, approval final OPEX & CAPEX, audit laporan, likuiditas, dan profitabilitas.',
    permissions: [
      { module: 'Executive Dashboard & P&L', access: 'Full' },
      { module: 'Persetujuan Approval OPEX & CAPEX', access: 'Approval' },
      { module: 'Laporan Keuangan & Neraca', access: 'Full' },
      { module: 'Arus Kas & Saldo Rekening', access: 'Full' },
      { module: 'Audit Log & Konfigurasi Sistem', access: 'Full' },
    ],
  },
  {
    role: 'Finance',
    title: 'Manajer Keuangan & Treasury',
    scope: 'Payment Request, verifikasi OPEX, pencairan CAPEX, pendaftaran aset tetap, depresiasi, dan arus kas.',
    permissions: [
      { module: 'Payment Request & Pembayaran', access: 'Full' },
      { module: 'Buku Kas & Mutasi Bank', access: 'Full' },
      { module: 'Asset Register & Depresiasi', access: 'Full' },
      { module: 'Arus Kas & Kasbon Karyawan', access: 'Full' },
      { module: 'Executive Dashboard', access: 'Full' },
    ],
  },
  {
    role: 'Operations',
    title: 'Operasional & Rantai Pasok',
    scope: 'Pengadaan barang dagangan (PO), pengajuan Payment Request operasional, pengajuan belanja modal (CAPEX).',
    permissions: [
      { module: 'Purchase Orders & Supplier', access: 'Full' },
      { module: 'Pengajuan Payment Request (OPEX)', access: 'Input' },
      { module: 'Pengajuan CAPEX Fasilitas', access: 'Input' },
      { module: 'Price Adjustments', access: 'Input' },
      { module: 'Laporan Keuangan Eksekutif', access: 'Read Only' },
    ],
  },
  {
    role: 'Accounting',
    title: 'Akuntansi & Perpajakan',
    scope: 'Laporan P&L, jurnal HPP, penyusutan aset, perhitungan PPh Badan, transaksi non-operasional, dan rekonsiliasi.',
    permissions: [
      { module: 'Monthly Income Statement (P&L)', access: 'Full' },
      { module: 'HPP & COGS', access: 'Full' },
      { module: 'Pajak Penghasilan (Income Tax)', access: 'Full' },
      { module: 'Non-Operating Income/Expense', access: 'Full' },
      { module: 'Neraca & Laporan Keuangan', access: 'Full' },
    ],
  },
  {
    role: 'Viewer',
    title: 'Auditor & Pengamat',
    scope: 'Akses baca (read-only) untuk seluruh dashboard eksekutif dan laporan keuangan tanpa hak modifikasi.',
    permissions: [
      { module: 'Executive Dashboard', access: 'Read Only' },
      { module: 'Monthly Income Statement', access: 'Read Only' },
      { module: 'Laporan Arus Kas', access: 'Read Only' },
      { module: 'Input & Edit Transaksi', access: 'None' },
      { module: 'Approval Alur Kerja', access: 'None' },
    ],
  },
];

export const RolesPermissionsModule: React.FC = () => {
  const { currentUser } = useFinance();

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="bg-white border border-slate-200/90 rounded-xl p-5 shadow-xs">
        <h1 className="text-xl font-bold text-slate-900 tracking-tight">Roles & Permissions (Hak Akses RBAC)</h1>
        <p className="text-xs text-slate-500 mt-1">
          Struktur wewenang peran berbasis tugas: Director, Finance, Operations, Accounting, dan Viewer.
        </p>
      </div>

      <div className="space-y-4">
        {ROLE_DEFINITIONS.map(r => {
          const isActive = currentUser.role === r.role;

          return (
            <div
              key={r.role}
              className={`bg-white border rounded-xl p-5 shadow-xs transition-colors ${
                isActive ? 'border-slate-800 ring-1 ring-slate-800' : 'border-slate-200'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-100 gap-2 mb-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-base text-slate-900">{r.role}</span>
                    <span className="text-xs text-slate-500 font-medium">({r.title})</span>
                    {isActive && (
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-900 text-white">
                        Peran Anda Saat Ini
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-600 mt-1">{r.scope}</p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-2.5 text-xs">
                {r.permissions.map((p, idx) => {
                  let badgeBg = 'bg-slate-100 text-slate-700';
                  if (p.access === 'Full') badgeBg = 'bg-emerald-50 text-emerald-800 border border-emerald-200';
                  if (p.access === 'Approval') badgeBg = 'bg-purple-50 text-purple-800 border border-purple-200';
                  if (p.access === 'Input') badgeBg = 'bg-blue-50 text-blue-800 border border-blue-200';
                  if (p.access === 'None') badgeBg = 'bg-rose-50 text-rose-700 border border-rose-200';

                  return (
                    <div key={idx} className="p-2.5 rounded-lg border border-slate-100 bg-slate-50/60 flex flex-col justify-between">
                      <span className="font-medium text-slate-700 text-[11px] mb-2">{p.module}</span>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold w-fit ${badgeBg}`}>
                        {p.access}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
