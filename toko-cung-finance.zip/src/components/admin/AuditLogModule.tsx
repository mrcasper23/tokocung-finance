import React, { useState } from 'react';
import { useFinance } from '../../context/FinanceContext';
import { History, Search, FileSpreadsheet, ShieldCheck } from 'lucide-react';
import { downloadCSV } from '../../utils/formatters';

export const AuditLogModule: React.FC = () => {
  const { auditLogs } = useFinance();
  const [searchTerm, setSearchTerm] = useState('');
  const [actionFilter, setActionFilter] = useState('ALL');

  const filtered = auditLogs.filter(log => {
    const matchSearch =
      log.module.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.recordId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.details.toLowerCase().includes(searchTerm.toLowerCase());
    const matchAction = actionFilter === 'ALL' || log.action === actionFilter;
    return matchSearch && matchAction;
  });

  const handleExport = () => {
    const headers = ['Waktu (Timestamp)', 'Aksi (Action)', 'Modul', 'ID Transaksi', 'User', 'Role', 'Detail'];
    const rows = filtered.map(l => [
      l.timestamp,
      l.action,
      l.module,
      l.recordId,
      l.userName,
      l.userRole,
      l.details
    ]);
    downloadCSV('Audit_Trail_Log_TokoCung', headers, rows);
  };

  const getActionBadge = (action: string) => {
    switch (action) {
      case 'Created':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-50 text-blue-700">Created</span>;
      case 'Approved':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-700">Approved</span>;
      case 'Paid':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-50 text-amber-800">Paid</span>;
      case 'Submitted':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-50 text-purple-700">Submitted</span>;
      case 'Edited':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-700">Edited</span>;
      case 'Rejected':
      case 'Cancelled':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-50 text-rose-700">{action}</span>;
      default:
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-700">{action}</span>;
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="bg-white border border-slate-200/90 rounded-xl p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Audit Trail & Jejak Aktivitas (Audit Log)</h1>
          <p className="text-xs text-slate-500 mt-1">
            Rekam jejak setiap pembuatan transaksi, revisi, persetujuan direktur, dan pencairan kas.
          </p>
        </div>

        <button
          onClick={handleExport}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white transition-colors cursor-pointer shadow-2xs shrink-0"
        >
          <FileSpreadsheet className="w-3.5 h-3.5" />
          <span>Export Log CSV</span>
        </button>
      </div>

      {/* Filter and Search */}
      <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-xs flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2 flex-1 max-w-sm border border-slate-200 rounded-lg px-2.5 py-1.5 bg-slate-50">
          <Search className="w-3.5 h-3.5 text-slate-400" />
          <input
            type="text"
            placeholder="Cari user, modul, atau no transaksi..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full bg-transparent outline-none text-xs text-slate-800 placeholder-slate-400"
          />
        </div>

        <div className="flex items-center gap-2">
          <span className="text-slate-500 font-medium">Filter Aksi:</span>
          <select
            value={actionFilter}
            onChange={e => setActionFilter(e.target.value)}
            className="border border-slate-200 rounded-lg px-2 py-1 text-xs text-slate-700 bg-white"
          >
            <option value="ALL">Semua Aksi</option>
            <option value="Created">Created</option>
            <option value="Submitted">Submitted</option>
            <option value="Approved">Approved</option>
            <option value="Paid">Paid</option>
            <option value="Edited">Edited</option>
          </select>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto text-xs">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                <th className="py-3 px-3">Waktu (WIB)</th>
                <th className="py-3 px-3">Aksi</th>
                <th className="py-3 px-3">Modul</th>
                <th className="py-3 px-3">No. ID Transaksi</th>
                <th className="py-3 px-3">Pengguna & Peran</th>
                <th className="py-3 px-3">Keterangan Aktivitas</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map(log => (
                <tr key={log.id} className="hover:bg-slate-50">
                  <td className="py-2.5 px-3 font-mono text-slate-500 text-[11px] whitespace-nowrap">
                    {log.timestamp}
                  </td>
                  <td className="py-2.5 px-3">{getActionBadge(log.action)}</td>
                  <td className="py-2.5 px-3 font-medium text-slate-800">{log.module}</td>
                  <td className="py-2.5 px-3 font-mono font-semibold text-slate-900">{log.recordId}</td>
                  <td className="py-2.5 px-3">
                    <span className="font-semibold text-slate-800">{log.userName}</span>
                    <span className="text-slate-400 text-[10px] ml-1.5">({log.userRole})</span>
                  </td>
                  <td className="py-2.5 px-3 text-slate-600 max-w-[320px] truncate" title={log.details}>
                    {log.details}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
