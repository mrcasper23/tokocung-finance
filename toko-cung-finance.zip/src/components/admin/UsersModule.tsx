import React from 'react';
import { useFinance } from '../../context/FinanceContext';
import { Users, Shield, CheckCircle2, UserCheck } from 'lucide-react';

export const UsersModule: React.FC = () => {
  const { users, currentUser, setCurrentUser } = useFinance();

  return (
    <div className="space-y-6 pb-12">
      <div className="bg-white border border-slate-200/90 rounded-xl p-5 shadow-xs">
        <h1 className="text-xl font-bold text-slate-900 tracking-tight">Manajemen Pengguna (Users)</h1>
        <p className="text-xs text-slate-500 mt-1">
          Daftar akun pengguna internal Toko Cung Finance dan penetapan jabatan organisasi.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
        {users.map(u => {
          const isCurrent = currentUser.id === u.id;

          return (
            <div
              key={u.id}
              className={`bg-white border rounded-xl p-5 shadow-xs flex flex-col justify-between transition-colors ${
                isCurrent ? 'border-slate-800 ring-1 ring-slate-800' : 'border-slate-200'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="w-10 h-10 rounded-full bg-slate-900 text-white font-bold flex items-center justify-center text-sm">
                    {u.name.charAt(0)}
                  </div>
                  {isCurrent ? (
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-900 text-white flex items-center gap-1">
                      <UserCheck className="w-3 h-3" /> Sedang Aktif
                    </span>
                  ) : (
                    <button
                      onClick={() => setCurrentUser(u)}
                      className="text-[11px] font-medium text-slate-600 hover:text-slate-900 underline cursor-pointer"
                    >
                      Beralih ke Akun Ini
                    </button>
                  )}
                </div>

                <div className="font-bold text-sm text-slate-900">{u.name}</div>
                <div className="text-slate-500 font-mono text-[11px] mt-0.5">{u.email}</div>
                <div className="mt-2.5 inline-block text-[11px] font-semibold px-2 py-0.5 rounded bg-slate-100 text-slate-800">
                  {u.role}
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-slate-500 text-[11px]">
                <span>Departemen:</span>
                <span className="font-medium text-slate-800">{u.department}</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
