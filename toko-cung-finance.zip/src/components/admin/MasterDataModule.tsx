import React, { useState } from 'react';
import { useFinance } from '../../context/FinanceContext';
import { formatRupiah } from '../../utils/formatters';
import { Building2, Package, Users, Truck } from 'lucide-react';

export const MasterDataModule: React.FC = () => {
  const { entities, products, customers, vendors } = useFinance();
  const [activeTab, setActiveTab] = useState<'entities' | 'products' | 'customers' | 'vendors'>('products');

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="bg-white border border-slate-200/90 rounded-xl p-5 shadow-xs">
        <h1 className="text-xl font-bold text-slate-900 tracking-tight">Master Data Perusahaan</h1>
        <p className="text-xs text-slate-500 mt-1">
          Katalog entitas hukum, basis data produk dagangan, daftar rekanan supplier, dan basis pelanggan Toko Cung.
        </p>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1.5 p-1 bg-slate-200/70 rounded-xl w-fit text-xs">
        <button
          onClick={() => setActiveTab('products')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer ${
            activeTab === 'products' ? 'bg-white text-slate-900 shadow-2xs font-semibold' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Package className="w-3.5 h-3.5" />
          <span>Produk ({products.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('entities')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer ${
            activeTab === 'entities' ? 'bg-white text-slate-900 shadow-2xs font-semibold' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Building2 className="w-3.5 h-3.5" />
          <span>Entitas Perusahaan ({entities.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('customers')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer ${
            activeTab === 'customers' ? 'bg-white text-slate-900 shadow-2xs font-semibold' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Users className="w-3.5 h-3.5" />
          <span>Pelanggan ({customers.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('vendors')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer ${
            activeTab === 'vendors' ? 'bg-white text-slate-900 shadow-2xs font-semibold' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Truck className="w-3.5 h-3.5" />
          <span>Supplier / Vendor ({vendors.length})</span>
        </button>
      </div>

      {/* Tab 1: Products */}
      {activeTab === 'products' && (
        <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
          <div className="overflow-x-auto text-xs">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                  <th className="py-3 px-3">SKU</th>
                  <th className="py-3 px-3">Nama Produk</th>
                  <th className="py-3 px-3">Kategori</th>
                  <th className="py-3 px-3">Satuan</th>
                  <th className="py-3 px-3 text-right">Harga Pokok (HPP)</th>
                  <th className="py-3 px-3 text-right">Harga Jual (Sales)</th>
                  <th className="py-3 px-3 text-right">Gross Margin %</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {products.map(p => {
                  const gm = p.sellingPrice > 0 ? ((p.sellingPrice - p.costPrice) / p.sellingPrice) * 100 : 0;
                  return (
                    <tr key={p.id} className="hover:bg-slate-50">
                      <td className="py-2.5 px-3 font-semibold text-slate-900 font-mono">{p.sku}</td>
                      <td className="py-2.5 px-3 font-medium text-slate-800">{p.name}</td>
                      <td className="py-2.5 px-3 text-slate-600">{p.category}</td>
                      <td className="py-2.5 px-3 text-slate-500">{p.unit}</td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-700">{formatRupiah(p.costPrice)}</td>
                      <td className="py-2.5 px-3 text-right font-mono font-bold tabular-nums text-slate-900">{formatRupiah(p.sellingPrice)}</td>
                      <td className="py-2.5 px-3 text-right font-mono font-semibold tabular-nums text-emerald-700">
                        {gm.toFixed(1)}%
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 2: Entities */}
      {activeTab === 'entities' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          {entities.map(e => (
            <div key={e.id} className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-sm text-slate-900">{e.name}</span>
                <span className="font-mono text-xs font-bold bg-slate-100 px-2 py-0.5 rounded text-slate-800">{e.code}</span>
              </div>
              <div className="text-slate-600">{e.type}</div>
              <div className="text-slate-400 text-[11px] pt-2 border-t border-slate-100">Lokasi: {e.location}</div>
            </div>
          ))}
        </div>
      )}

      {/* Tab 3: Customers */}
      {activeTab === 'customers' && (
        <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
          <div className="overflow-x-auto text-xs">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                  <th className="py-3 px-3">Nama Pelanggan</th>
                  <th className="py-3 px-3">Kategori</th>
                  <th className="py-3 px-3">Telepon</th>
                  <th className="py-3 px-3">Email</th>
                  <th className="py-3 px-3">Alamat</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {customers.map(c => (
                  <tr key={c.id} className="hover:bg-slate-50">
                    <td className="py-2.5 px-3 font-semibold text-slate-900">{c.name}</td>
                    <td className="py-2.5 px-3">
                      <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 text-[11px] font-medium">{c.category}</span>
                    </td>
                    <td className="py-2.5 px-3 text-slate-600">{c.phone}</td>
                    <td className="py-2.5 px-3 text-slate-600 font-mono text-[11px]">{c.email}</td>
                    <td className="py-2.5 px-3 text-slate-500">{c.address}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 4: Vendors */}
      {activeTab === 'vendors' && (
        <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
          <div className="overflow-x-auto text-xs">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                  <th className="py-3 px-3">Nama Supplier / Vendor</th>
                  <th className="py-3 px-3">Kategori Barang/Jasa</th>
                  <th className="py-3 px-3">Kontak Telepon</th>
                  <th className="py-3 px-3">Rekening Pembayaran Bank</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {vendors.map(v => (
                  <tr key={v.id} className="hover:bg-slate-50">
                    <td className="py-2.5 px-3 font-semibold text-slate-900">{v.name}</td>
                    <td className="py-2.5 px-3 text-slate-600">{v.category}</td>
                    <td className="py-2.5 px-3 text-slate-600">{v.phone}</td>
                    <td className="py-2.5 px-3 font-mono font-medium text-slate-800">{v.bankAccount}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
