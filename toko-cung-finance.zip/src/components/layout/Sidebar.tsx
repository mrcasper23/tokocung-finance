import React, { useState } from 'react';
import {
  LayoutDashboard,
  TrendingUp,
  FileSpreadsheet,
  Wallet,
  Users,
  ArrowLeftRight,
  CheckCircle2,
  ShoppingCart,
  ClipboardList,
  SlidersHorizontal,
  PieChart,
  Tag,
  CreditCard,
  Building,
  HardDrive,
  CalendarDays,
  FileText,
  DollarSign,
  Package,
  Landmark,
  Receipt,
  CircleDollarSign,
  Briefcase,
  ShieldAlert,
  Database,
  History,
  Settings,
  ChevronDown,
  ChevronRight,
  Menu,
  X
} from 'lucide-react';

export type NavModuleId =
  | 'executive-dashboard'
  | 'financial-summary'
  | 'monthly-pnl'
  | 'cash-dashboard'
  | 'kasbon-debitur'
  | 'mutasi-kas'
  | 'kasbon-pelunasan'
  | 'purchase-monitor'
  | 'purchase-orders'
  | 'price-adjustments'
  | 'opex-dashboard'
  | 'expense-categories'
  | 'payment-requests'
  | 'capex-dashboard'
  | 'capex-payment-requests'
  | 'asset-register'
  | 'depreciation-schedule'
  | 'capex-report'
  | 'sales'
  | 'hpp'
  | 'non-operating'
  | 'pajak'
  | 'payroll'
  | 'arus-kas'
  | 'laporan-keuangan'
  | 'users'
  | 'roles-permissions'
  | 'master-data'
  | 'audit-log'
  | 'pengaturan';

interface NavGroup {
  name: string;
  items: {
    id: NavModuleId;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: string;
  }[];
}

const NAV_GROUPS: NavGroup[] = [
  {
    name: 'Executive',
    items: [
      { id: 'executive-dashboard', label: 'Dashboard Eksekutif', icon: LayoutDashboard },
      { id: 'financial-summary', label: 'Ringkasan Keuangan', icon: TrendingUp },
      { id: 'monthly-pnl', label: 'Monthly Income Statement', icon: FileSpreadsheet },
    ],
  },
  {
    name: 'Kasbon / Cash',
    items: [
      { id: 'cash-dashboard', label: 'Dashboard Kas', icon: Wallet },
      { id: 'kasbon-debitur', label: 'Debitur Kasbon', icon: Users },
      { id: 'mutasi-kas', label: 'Mutasi Kas & Bank', icon: ArrowLeftRight },
      { id: 'kasbon-pelunasan', label: 'Pelunasan Kasbon', icon: CheckCircle2 },
    ],
  },
  {
    name: 'Purchase Monitoring',
    items: [
      { id: 'purchase-monitor', label: 'Purchase Monitor', icon: ShoppingCart },
      { id: 'purchase-orders', label: 'Purchase Orders', icon: ClipboardList },
      { id: 'price-adjustments', label: 'Price Adjustments', icon: SlidersHorizontal },
    ],
  },
  {
    name: 'Expenses',
    items: [
      { id: 'opex-dashboard', label: 'OPEX Dashboard', icon: PieChart },
      { id: 'expense-categories', label: 'Expense Categories', icon: Tag },
      { id: 'payment-requests', label: 'Payment Request', icon: CreditCard, badge: 'Workflow' },
      { id: 'capex-dashboard', label: 'CAPEX Dashboard', icon: Building },
      { id: 'capex-payment-requests', label: 'CAPEX Payment Request', icon: CreditCard },
      { id: 'asset-register', label: 'Asset Register', icon: HardDrive },
      { id: 'depreciation-schedule', label: 'Depreciation Schedule', icon: CalendarDays },
      { id: 'capex-report', label: 'CAPEX Report', icon: FileText },
    ],
  },
  {
    name: 'Accounting',
    items: [
      { id: 'sales', label: 'Sales (Penjualan)', icon: DollarSign },
      { id: 'hpp', label: 'HPP (Harga Pokok)', icon: Package },
      { id: 'non-operating', label: 'Non Operating', icon: Landmark },
      { id: 'pajak', label: 'Pajak (Income Tax)', icon: Receipt },
      { id: 'payroll', label: 'Payroll & Upah', icon: CircleDollarSign },
      { id: 'arus-kas', label: 'Arus Kas (Cash Flow)', icon: ArrowLeftRight },
      { id: 'laporan-keuangan', label: 'Laporan Keuangan', icon: Briefcase },
    ],
  },
  {
    name: 'Administration',
    items: [
      { id: 'users', label: 'Users', icon: Users },
      { id: 'roles-permissions', label: 'Roles & Permissions', icon: ShieldAlert },
      { id: 'master-data', label: 'Master Data', icon: Database },
      { id: 'audit-log', label: 'Audit Log', icon: History },
      { id: 'pengaturan', label: 'Pengaturan', icon: Settings },
    ],
  },
];

interface SidebarProps {
  activeModule: NavModuleId;
  onSelectModule: (id: NavModuleId) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeModule, onSelectModule }) => {
  const [collapsedGroups, setCollapsedGroups] = useState<Record<string, boolean>>({});
  const [mobileOpen, setMobileOpen] = useState(false);

  const toggleGroup = (groupName: string) => {
    setCollapsedGroups(prev => ({
      ...prev,
      [groupName]: !prev[groupName],
    }));
  };

  const handleSelect = (id: NavModuleId) => {
    onSelectModule(id);
    setMobileOpen(false);
  };

  const sidebarContent = (
    <div className="flex flex-col h-full bg-slate-900 text-slate-200 w-64 select-none">
      {/* Brand & Subtitle */}
      <div className="p-4 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-emerald-500 text-slate-950 font-extrabold flex items-center justify-center text-sm shadow-md">
            TC
          </div>
          <div>
            <div className="font-bold text-sm tracking-wide text-white leading-tight">TOKO CUNG</div>
            <div className="text-[10px] text-slate-400 font-medium">Internal Finance & Accounting</div>
          </div>
        </div>
        <button
          onClick={() => setMobileOpen(false)}
          className="lg:hidden text-slate-400 hover:text-white p-1"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Navigation Groups */}
      <div className="flex-1 overflow-y-auto px-3 py-3 space-y-4 text-xs scrollbar-thin scrollbar-thumb-slate-800">
        {NAV_GROUPS.map(group => {
          const isCollapsed = collapsedGroups[group.name];
          const hasActiveItem = group.items.some(it => it.id === activeModule);

          return (
            <div key={group.name} className="space-y-1">
              <button
                onClick={() => toggleGroup(group.name)}
                className="w-full flex items-center justify-between px-2 py-1 text-[11px] font-semibold text-slate-400 uppercase tracking-wider hover:text-slate-200 transition-colors cursor-pointer"
              >
                <span>{group.name}</span>
                {isCollapsed ? (
                  <ChevronRight className="w-3.5 h-3.5 text-slate-500" />
                ) : (
                  <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
                )}
              </button>

              {!isCollapsed && (
                <div className="space-y-0.5">
                  {group.items.map(item => {
                    const Icon = item.icon;
                    const isActive = activeModule === item.id;

                    return (
                      <button
                        key={item.id}
                        onClick={() => handleSelect(item.id)}
                        className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-left transition-colors cursor-pointer text-xs font-medium ${
                          isActive
                            ? 'bg-slate-800 text-white font-semibold shadow-xs'
                            : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
                        }`}
                      >
                        <div className="flex items-center gap-2.5 truncate">
                          <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-emerald-400' : 'text-slate-400'}`} />
                          <span className="truncate">{item.label}</span>
                        </div>
                        {item.badge && (
                          <span className="text-[9px] px-1.5 py-0.2 rounded bg-slate-700/80 text-slate-300">
                            {item.badge}
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Footer System Status */}
      <div className="p-3 border-t border-slate-800 text-[11px] text-slate-400 flex items-center justify-between bg-slate-950/40">
        <div className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-emerald-500" />
          <span className="text-slate-300 font-medium">Sistem Terintegrasi</span>
        </div>
        <span className="font-mono text-[10px] text-slate-500">v2.6-PRO</span>
      </div>
    </div>
  );

  return (
    <>
      {/* Mobile Toggle Button */}
      <div className="lg:hidden fixed bottom-4 right-4 z-50">
        <button
          onClick={() => setMobileOpen(true)}
          className="w-12 h-12 rounded-full bg-slate-900 text-white shadow-xl flex items-center justify-center hover:bg-slate-800 focus:outline-none"
        >
          <Menu className="w-5 h-5" />
        </button>
      </div>

      {/* Mobile Backdrop */}
      {mobileOpen && (
        <div
          className="lg:hidden fixed inset-0 z-40 bg-black/60 backdrop-blur-xs transition-opacity"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Mobile Sidebar */}
      <aside
        className={`lg:hidden fixed inset-y-0 left-0 z-50 transform transition-transform duration-200 ease-in-out ${
          mobileOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {sidebarContent}
      </aside>

      {/* Desktop Persistent Sidebar */}
      <aside className="hidden lg:block shrink-0 sticky top-0 h-screen">
        {sidebarContent}
      </aside>
    </>
  );
};
