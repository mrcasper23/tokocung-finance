import React, { useState } from 'react';
import { useFinance } from '../../context/FinanceContext';
import { MONTH_SHORT_ID, downloadCSV, printReport } from '../../utils/formatters';
import {
  RotateCcw,
  FileSpreadsheet,
  Printer,
  ChevronDown,
  UserCheck,
  Building2,
  Calendar,
  Layers,
  Search,
  Bell,
  Sparkles,
  Info
} from 'lucide-react';
import { UserRole, GlobalFilter } from '../../types/finance';

interface HeaderProps {
  currentModuleTitle: string;
  onOpenSearch?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ currentModuleTitle }) => {
  const {
    entities,
    users,
    currentUser,
    setCurrentUser,
    globalFilter,
    setGlobalFilter,
    resetFilter,
    resetToDemoData,
    monthlyPnlTable,
    sales,
    currentMonthPnl
  } = useFinance();

  const [showRoleMenu, setShowRoleMenu] = useState(false);
  const [showDemoInfo, setShowDemoInfo] = useState(false);
  const [notificationOpen, setNotificationOpen] = useState(false);

  const handleExportExcel = () => {
    // Export Monthly PnL
    const headers = ['Komponen Laporan', ...MONTH_SHORT_ID, 'YTD 2026'];
    const rows = monthlyPnlTable.map(row => [
      row.label,
      ...row.values.map(v => (row.isPercentage ? `${v.toFixed(1)}%` : Math.round(v))),
      row.isPercentage ? `${row.ytd.toFixed(1)}%` : Math.round(row.ytd)
    ]);
    downloadCSV(`Laporan_Laba_Rugi_TokoCung_${globalFilter.year}`, headers, rows);
  };

  const handleExportSales = () => {
    const headers = ['No Transaksi', 'Tanggal', 'Entitas', 'Customer', 'Produk', 'Qty', 'Harga', 'Total Sales', 'Status'];
    const rows = sales.map(s => [
      s.transactionNumber,
      s.date,
      s.entityId,
      s.customerName,
      s.productName,
      s.qty,
      s.unitPrice,
      s.totalSales,
      s.status
    ]);
    downloadCSV(`Transaksi_Penjualan_TokoCung_${globalFilter.year}`, headers, rows);
  };

  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200">
      {/* Upper Navigation Row */}
      <div className="flex items-center justify-between px-4 sm:px-6 py-2.5 gap-4">
        {/* Left: Brand title & breadcrumb */}
        <div className="flex items-center gap-3 min-w-0">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-slate-900 text-white font-bold flex items-center justify-center text-sm shadow-xs">
              TC
            </div>
            <div className="leading-tight">
              <span className="font-bold text-slate-900 tracking-tight text-sm sm:text-base">TOKO CUNG</span>
              <span className="ml-1.5 text-xs text-slate-500 font-medium tracking-wide uppercase">FINANCE</span>
            </div>
          </div>
          <span className="text-slate-300 hidden sm:inline" aria-hidden="true">/</span>
          <span className="text-xs sm:text-sm font-semibold text-slate-700 truncate hidden sm:inline">
            {currentModuleTitle}
          </span>
        </div>

        {/* Right side: Demo badge, quick actions, role switcher */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {/* Demo Data Tag with reset */}
          <div className="relative">
            <button
              onClick={() => setShowDemoInfo(!showDemoInfo)}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded-md bg-amber-50 text-amber-800 border border-amber-200/80 hover:bg-amber-100 transition-colors cursor-pointer"
              title="Informasi Data Demo 2026"
            >
              <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
              <span>DATA DEMO 2026</span>
              <Info className="w-3.5 h-3.5 text-amber-600" />
            </button>

            {showDemoInfo && (
              <div className="absolute right-0 mt-2 w-72 bg-white rounded-xl shadow-xl border border-slate-200 p-3.5 z-40 text-xs">
                <div className="flex items-start justify-between">
                  <span className="font-bold text-slate-900">Data Demo Terintegrasi</span>
                  <span className="text-[10px] text-amber-700 font-semibold bg-amber-100 px-1.5 py-0.5 rounded">12 Bulan</span>
                </div>
                <p className="text-slate-600 mt-1.5 leading-relaxed">
                  Semua angka transaksi Sales, HPP, OPEX, CAPEX, dan Pajak untuk tahun 2026 telah terisi secara konsisten. Anda dapat menambah transaksi baru atau mereset sewaktu-waktu.
                </p>
                <div className="mt-3 pt-2.5 border-t border-slate-100 flex justify-between items-center">
                  <button
                    onClick={() => {
                      resetToDemoData();
                      setShowDemoInfo(false);
                    }}
                    className="text-xs font-semibold text-rose-600 hover:text-rose-700 flex items-center gap-1 cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    Reset Data Demo
                  </button>
                  <button
                    onClick={() => setShowDemoInfo(false)}
                    className="text-xs text-slate-500 hover:text-slate-800 cursor-pointer"
                  >
                    Tutup
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Export Buttons */}
          <div className="hidden lg:flex items-center gap-1.5 border-l border-slate-200 pl-3">
            <button
              onClick={handleExportExcel}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors cursor-pointer"
              title="Export Laporan ke Excel (.csv)"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
              <span>Export Excel</span>
            </button>
            <button
              onClick={printReport}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors cursor-pointer"
              title="Cetak Laporan / PDF"
            >
              <Printer className="w-3.5 h-3.5 text-slate-600" />
              <span>Print / PDF</span>
            </button>
          </div>

          {/* Role Switcher */}
          <div className="relative border-l border-slate-200 pl-2 sm:pl-3">
            <button
              onClick={() => setShowRoleMenu(!showRoleMenu)}
              className="flex items-center gap-2 px-2 py-1 rounded-lg hover:bg-slate-100 transition-colors text-left cursor-pointer"
            >
              <div className="w-7 h-7 rounded-full bg-slate-800 text-white font-medium text-xs flex items-center justify-center">
                {currentUser.name.charAt(0)}
              </div>
              <div className="hidden md:block leading-tight text-left">
                <div className="text-xs font-semibold text-slate-900 truncate max-w-[120px]">{currentUser.name}</div>
                <div className="text-[10px] text-slate-500 font-medium">{currentUser.role}</div>
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </button>

            {showRoleMenu && (
              <div className="absolute right-0 mt-2 w-64 bg-white rounded-xl shadow-xl border border-slate-200 p-2 z-40 text-xs">
                <div className="px-2 py-1.5 border-b border-slate-100 mb-1">
                  <div className="font-semibold text-slate-900">Ganti Peran Pengguna (RBAC)</div>
                  <div className="text-[11px] text-slate-500">Uji hak akses modul sesuai perannya</div>
                </div>
                {users.map(u => (
                  <button
                    key={u.id}
                    onClick={() => {
                      setCurrentUser(u);
                      setShowRoleMenu(false);
                    }}
                    className={`w-full flex items-center justify-between px-2.5 py-2 rounded-lg text-left transition-colors cursor-pointer ${
                      currentUser.id === u.id ? 'bg-slate-900 text-white' : 'hover:bg-slate-50 text-slate-800'
                    }`}
                  >
                    <div>
                      <div className="font-medium text-xs">{u.name}</div>
                      <div className={`text-[10px] ${currentUser.id === u.id ? 'text-slate-300' : 'text-slate-500'}`}>
                        {u.role} · {u.department}
                      </div>
                    </div>
                    {currentUser.id === u.id && <UserCheck className="w-4 h-4 text-emerald-400" />}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Global Filter Bar (Entitas, Periode, Bulan, Tahun, Reset) */}
      <div className="bg-slate-50/90 border-t border-slate-200/80 px-4 sm:px-6 py-2 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex flex-wrap items-center gap-2 sm:gap-3">
          {/* Entitas */}
          <div className="flex items-center gap-1.5 bg-white px-2.5 py-1 rounded-md border border-slate-200 shadow-2xs">
            <Building2 className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-[11px] text-slate-500 font-medium">Entitas:</span>
            <select
              value={globalFilter.entityId}
              onChange={e => setGlobalFilter(prev => ({ ...prev, entityId: e.target.value }))}
              className="bg-transparent font-medium text-slate-800 text-xs outline-none cursor-pointer"
            >
              <option value="ALL">Semua Entitas (Konsolidasi)</option>
              {entities.map(ent => (
                <option key={ent.id} value={ent.id}>
                  {ent.name}
                </option>
              ))}
            </select>
          </div>

          {/* Periode */}
          <div className="flex items-center gap-1.5 bg-white px-2.5 py-1 rounded-md border border-slate-200 shadow-2xs">
            <Layers className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-[11px] text-slate-500 font-medium">Periode:</span>
            <select
              value={globalFilter.period}
              onChange={e =>
                setGlobalFilter(prev => ({
                  ...prev,
                  period: e.target.value as GlobalFilter['period']
                }))
              }
              className="bg-transparent font-medium text-slate-800 text-xs outline-none cursor-pointer"
            >
              <option value="Bulanan">Bulanan</option>
              <option value="YTD">YTD (Tahun Berjalan)</option>
              <option value="Q1">Kuartal 1 (Jan - Mar)</option>
              <option value="Q2">Kuartal 2 (Apr - Jun)</option>
              <option value="Q3">Kuartal 3 (Jul - Sep)</option>
              <option value="Q4">Kuartal 4 (Okt - Des)</option>
            </select>
          </div>

          {/* Bulan (if Bulanan is selected) */}
          {globalFilter.period === 'Bulanan' && (
            <div className="flex items-center gap-1.5 bg-white px-2.5 py-1 rounded-md border border-slate-200 shadow-2xs">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              <span className="text-[11px] text-slate-500 font-medium">Bulan:</span>
              <select
                value={globalFilter.month}
                onChange={e => setGlobalFilter(prev => ({ ...prev, month: Number(e.target.value) }))}
                className="bg-transparent font-medium text-slate-800 text-xs outline-none cursor-pointer"
              >
                {MONTH_SHORT_ID.map((mName, idx) => (
                  <option key={idx} value={idx + 1}>
                    {mName}
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Tahun */}
          <div className="flex items-center gap-1.5 bg-white px-2.5 py-1 rounded-md border border-slate-200 shadow-2xs">
            <span className="text-[11px] text-slate-500 font-medium">Tahun:</span>
            <select
              value={globalFilter.year}
              onChange={e => setGlobalFilter(prev => ({ ...prev, year: Number(e.target.value) }))}
              className="bg-transparent font-medium text-slate-800 text-xs outline-none cursor-pointer"
            >
              <option value={2026}>2026</option>
              <option value={2025}>2025</option>
            </select>
          </div>

          {/* Reset Filter Button */}
          <button
            onClick={resetFilter}
            className="flex items-center gap-1 px-2 py-1 text-slate-500 hover:text-slate-800 text-[11px] font-medium transition-colors cursor-pointer"
            title="Reset ke default"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Reset Filter</span>
          </button>
        </div>

        {/* Global Active Filter Summary Badge */}
        <div className="text-[11px] text-slate-500 hidden md:flex items-center gap-2">
          <span>Menampilkan:</span>
          <span className="font-semibold text-slate-700 bg-white px-2 py-0.5 rounded border border-slate-200/60 tabular-nums">
            {globalFilter.entityId === 'ALL' ? 'Konsolidasi Semua' : entities.find(e => e.id === globalFilter.entityId)?.code}
            {' · '}
            {globalFilter.period === 'Bulanan' ? `${MONTH_SHORT_ID[globalFilter.month - 1]} ${globalFilter.year}` : `${globalFilter.period} ${globalFilter.year}`}
          </span>
        </div>
      </div>
    </header>
  );
};
