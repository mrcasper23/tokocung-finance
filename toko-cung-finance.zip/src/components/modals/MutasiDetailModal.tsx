import React from 'react';
import { CashMutation } from '../../types/finance';
import { formatRupiah, formatDate, printReport } from '../../utils/formatters';
import { X, Printer, ArrowLeftRight, CheckCircle2, ShieldCheck, ArrowDownLeft, ArrowUpRight } from 'lucide-react';

interface MutasiDetailModalProps {
  mutation: CashMutation;
  onClose: () => void;
}

export const MutasiDetailModal: React.FC<MutasiDetailModalProps> = ({ mutation, onClose }) => {
  const isMasuk = mutation.type === 'Masuk';

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 animate-in fade-in">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-lg w-full flex flex-col text-xs overflow-hidden animate-in zoom-in-95">
        {/* Header */}
        <div className="p-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className={`p-2 rounded-lg text-white ${isMasuk ? 'bg-emerald-600' : 'bg-rose-600'}`}>
              {isMasuk ? <ArrowDownLeft className="w-4 h-4" /> : <ArrowUpRight className="w-4 h-4" />}
            </div>
            <div>
              <span className="font-mono text-base font-bold text-slate-900">{mutation.referenceNumber}</span>
              <div className="text-[11px] text-slate-500">Voucher Mutasi Kas & Bank · {formatDate(mutation.date)}</div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={printReport}
              className="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-100 text-slate-600 cursor-pointer"
              title="Cetak Bukti Mutasi"
            >
              <Printer className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-lg border border-slate-200 flex items-center justify-center text-slate-400 hover:text-slate-800 hover:bg-slate-100 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4 overflow-y-auto max-h-[80vh]">
          {/* Main cost banner */}
          <div className={`p-4 rounded-xl flex items-center justify-between text-white ${isMasuk ? 'bg-emerald-900' : 'bg-slate-900'}`}>
            <div>
              <span className="text-[10px] text-slate-300 font-semibold uppercase block">
                {isMasuk ? 'Penerimaan Kas (Masuk)' : 'Pengeluaran Kas (Keluar)'}
              </span>
              <span className="text-xl font-bold font-mono tabular-nums">
                {formatRupiah(mutation.amount)}
              </span>
            </div>
            <span className={`px-2.5 py-1 rounded-full text-xs font-bold ${isMasuk ? 'bg-emerald-500 text-white' : 'bg-rose-500 text-white'}`}>
              {mutation.type}
            </span>
          </div>

          {/* Details breakdown */}
          <div className="border border-slate-200 rounded-xl p-3.5 space-y-2 bg-slate-50/50">
            <div className="font-bold text-slate-900 text-xs">Informasi Rekening & Rekonsiliasi:</div>
            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <div>
                <span className="text-slate-500 block">Akun Kas / Bank:</span>
                <span className="font-semibold text-slate-800">{mutation.account}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Kategori Transaksi:</span>
                <span className="font-medium text-slate-800">{mutation.category}</span>
              </div>
              <div className="col-span-2">
                <span className="text-slate-500 block">Keterangan / Berita Acara:</span>
                <span className="font-medium text-slate-900">{mutation.description}</span>
              </div>
            </div>
          </div>

          {/* Verification stamp */}
          <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3 flex items-center gap-2.5 text-emerald-900 text-[11px]">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <div>
              <span className="font-semibold">Rekonsiliasi Bank Otomatis:</span> Mutasi ini telah disinkronkan dengan rekening koran internal dan laporan arus kas (Cash Flow Statement).
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-slate-200 bg-slate-50 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white cursor-pointer"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
