import React from 'react';
import { HppRecord } from '../../types/finance';
import { formatRupiah, formatDate, printReport } from '../../utils/formatters';
import { X, Printer, Package, ShieldCheck, Tag, Building2, Calendar, FileText, CheckCircle2 } from 'lucide-react';

interface HppDetailModalProps {
  hpp: HppRecord;
  onClose: () => void;
}

export const HppDetailModal: React.FC<HppDetailModalProps> = ({ hpp, onClose }) => {
  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 animate-in fade-in">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-lg w-full flex flex-col text-xs overflow-hidden animate-in zoom-in-95">
        {/* Header */}
        <div className="p-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-slate-900 text-white">
              <Package className="w-4 h-4" />
            </div>
            <div>
              <span className="font-mono text-base font-bold text-slate-900">{hpp.sku}</span>
              <div className="text-[11px] text-slate-500">Bukti Beban Pokok Penjualan · {formatDate(hpp.date)}</div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={printReport}
              className="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-100 text-slate-600 cursor-pointer"
              title="Cetak Bukti HPP"
            >
              <Printer className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-lg border border-slate-200 flex items-center justify-center text-slate-400 hover:text-slate-800 hover:bg-slate-100 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4 overflow-y-auto max-h-[80vh]">
          {/* Main cost banner */}
          <div className="bg-slate-900 text-white p-4 rounded-xl flex items-center justify-between">
            <div>
              <span className="text-[10px] text-slate-400 font-semibold uppercase block">Total Nilai HPP (COGS)</span>
              <span className="text-xl font-bold font-mono text-white tabular-nums">
                {formatRupiah(hpp.totalHpp)}
              </span>
            </div>
            <div className="text-right">
              <span className="text-[10px] text-slate-400 block">Kuantitas</span>
              <span className="text-sm font-bold font-mono text-emerald-400">{hpp.qty} Unit</span>
            </div>
          </div>

          {/* Product information */}
          <div className="border border-slate-200 rounded-xl p-3.5 space-y-2 bg-slate-50/50">
            <div className="font-bold text-slate-900 text-xs">Informasi Komoditas Produk:</div>
            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <div>
                <span className="text-slate-500 block">Nama Produk:</span>
                <span className="font-semibold text-slate-800">{hpp.productName}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Nomor SKU:</span>
                <span className="font-mono font-semibold text-slate-800">{hpp.sku}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Supplier Rekanan:</span>
                <span className="font-medium text-slate-800">{hpp.supplierName}</span>
              </div>
              <div>
                <span className="text-slate-500 block">No. Purchase Order:</span>
                <span className="font-mono font-medium text-blue-700">{hpp.purchaseOrderNumber || 'PO-2026-REG'}</span>
              </div>
            </div>
          </div>

          {/* Calculation breakdown */}
          <div className="border border-slate-200 rounded-xl p-3.5 space-y-2">
            <div className="font-bold text-slate-900 text-xs">Rincian Perhitungan Biaya:</div>
            <div className="space-y-1.5 text-[11px]">
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-600">Harga Pokok per Unit:</span>
                <span className="font-mono font-semibold text-slate-800">{formatRupiah(hpp.unitCost)}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-600">Jumlah Unit Terjual/Dikeluarkan:</span>
                <span className="font-mono font-semibold text-slate-800">{hpp.qty} pcs</span>
              </div>
              <div className="flex justify-between py-1.5 font-bold text-slate-900 bg-slate-50 px-2 rounded">
                <span>Total Beban Pokok (HPP):</span>
                <span className="font-mono">{formatRupiah(hpp.totalHpp)}</span>
              </div>
            </div>
          </div>

          {/* Verification stamp */}
          <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3 flex items-center gap-2.5 text-emerald-900 text-[11px]">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <div>
              <span className="font-semibold">Validasi Buku Besar Otomatis:</span> Beban HPP tercatat otomatis pada Laporan Laba Rugi dan mengurangi saldo persediaan aset lancar.
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-slate-200 bg-slate-50 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white cursor-pointer"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
