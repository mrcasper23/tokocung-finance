import React, { useMemo } from 'react';
import { useFinance } from '../../context/FinanceContext';
import {
  formatRupiah,
  formatPercent,
  formatDate,
  downloadCSV,
  printReport,
  MONTH_NAMES_ID
} from '../../utils/formatters';
import {
  X,
  Printer,
  FileSpreadsheet,
  Calendar,
  Building2,
  DollarSign,
  TrendingUp,
  Tag,
  ArrowRight,
  ShieldCheck,
  CheckCircle2
} from 'lucide-react';

interface MonthDetailModalProps {
  monthIndex: number; // 0 for Jan, 11 for Dec
  year?: number;
  onClose: () => void;
  onNavigateModule?: (moduleId: string) => void;
}

export const MonthDetailModal: React.FC<MonthDetailModalProps> = ({
  monthIndex,
  year = 2026,
  onClose,
  onNavigateModule,
}) => {
  const { twelveMonthsPnl, sales, opex, capexRequests, entities } = useFinance();

  const monthNum = monthIndex + 1;
  const monthName = MONTH_NAMES_ID[monthIndex] || `Bulan ${monthNum}`;
  const pnl = twelveMonthsPnl[monthIndex] || twelveMonthsPnl[0];

  // Transactions belonging to this month
  const monthSales = useMemo(() => {
    return sales.filter(s => {
      const [y, m] = s.date.split('-').map(Number);
      return y === year && m === monthNum;
    });
  }, [sales, year, monthNum]);

  const monthOpex = useMemo(() => {
    return opex.filter(o => {
      const [y, m] = o.date.split('-').map(Number);
      return y === year && m === monthNum;
    });
  }, [opex, year, monthNum]);

  const monthCapex = useMemo(() => {
    return capexRequests.filter(c => {
      if (!c.acquisitionDate) return false;
      const [y, m] = c.acquisitionDate.split('-').map(Number);
      return y === year && m === monthNum;
    });
  }, [capexRequests, year, monthNum]);

  const handleExport = () => {
    const headers = ['Pos Laba Rugi', 'Nilai (Rp)'];
    const rows = [
      ['Total Penjualan (Sales)', pnl.sales],
      ['Beban Pokok Penjualan (HPP)', -pnl.hpp],
      ['Laba Kotor (Gross Profit)', pnl.grossProfit],
      ['Margin Laba Kotor', `${pnl.grossMarginPct.toFixed(1)}%`],
      ['Total Beban Operasional (OPEX)', -pnl.totalOpex],
      ['EBITDA', pnl.ebitda],
      ['Margin EBITDA', `${pnl.ebitdaMarginPct.toFixed(1)}%`],
      ['Beban Depresiasi', -pnl.totalDepreciation],
      ['EBIT / Management Profit', pnl.ebit],
      ['Net Non-Operasional', pnl.netNonOperating],
      ['Laba Sebelum Pajak (EBT)', pnl.ebt],
      ['Pajak Penghasilan', -pnl.taxExpense],
      ['Laba Bersih (Net Profit)', pnl.netProfit],
      ['Net Margin %', `${pnl.netProfitMarginPct.toFixed(1)}%`],
    ];
    downloadCSV(`Detail_Finansial_${monthName}_${year}`, headers, rows);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 animate-in fade-in">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-4xl w-full max-h-[92vh] flex flex-col text-xs overflow-hidden animate-in zoom-in-95">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 bg-slate-50 flex items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-slate-900 text-white shadow-2xs">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight">
                  Kinerja Finansial Bulanan: {monthName} {year}
                </h2>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-100 text-blue-800">
                  Bulan #{monthNum}
                </span>
              </div>
              <p className="text-slate-500 text-[11px] mt-0.5">
                Rincian pembukuan realisasi pendapatan, beban operasional, dan laba rugi lengkap.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={handleExport}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-100 text-slate-700 transition-colors cursor-pointer"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
              <span className="hidden sm:inline">Export</span>
            </button>
            <button
              onClick={printReport}
              className="p-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-100 text-slate-700 transition-colors cursor-pointer"
              title="Cetak"
            >
              <Printer className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-lg border border-slate-200 flex items-center justify-center text-slate-400 hover:text-slate-800 hover:bg-slate-200 transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Accounting Flow Strip */}
        <div className="px-5 py-2.5 bg-slate-900 text-slate-200 flex flex-wrap items-center justify-between gap-2 text-[11px]">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="font-medium text-slate-300">
              Sales ({formatRupiah(pnl.sales)}) → Gross Profit ({formatRupiah(pnl.grossProfit)}) → EBITDA ({formatRupiah(pnl.ebitda)}) → Net Profit ({formatRupiah(pnl.netProfit)})
            </span>
          </div>
          <div className="text-emerald-400 font-semibold tabular-nums">
            Net Margin: {formatPercent(pnl.netProfitMarginPct)}
          </div>
        </div>

        {/* Body Container */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {/* Key Metric Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3">
              <span className="text-[10px] text-slate-500 font-semibold uppercase block">Penjualan (Sales)</span>
              <span className="text-base font-bold text-slate-900 font-mono tabular-nums block mt-0.5">
                {formatRupiah(pnl.sales)}
              </span>
              <span className="text-[10px] text-slate-400">100% basis omzet</span>
            </div>

            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3">
              <span className="text-[10px] text-slate-500 font-semibold uppercase block">Laba Kotor (GP)</span>
              <span className="text-base font-bold text-blue-700 font-mono tabular-nums block mt-0.5">
                {formatRupiah(pnl.grossProfit)}
              </span>
              <span className="text-[10px] text-blue-600 font-medium">Margin: {formatPercent(pnl.grossMarginPct)}</span>
            </div>

            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3">
              <span className="text-[10px] text-slate-500 font-semibold uppercase block">EBITDA</span>
              <span className="text-base font-bold text-indigo-700 font-mono tabular-nums block mt-0.5">
                {formatRupiah(pnl.ebitda)}
              </span>
              <span className="text-[10px] text-indigo-600 font-medium">Margin: {formatPercent(pnl.ebitdaMarginPct)}</span>
            </div>

            <div className="bg-emerald-50/60 border border-emerald-200 rounded-xl p-3">
              <span className="text-[10px] text-emerald-800 font-semibold uppercase block">Laba Bersih (Net)</span>
              <span className="text-base font-bold text-emerald-950 font-mono tabular-nums block mt-0.5">
                {formatRupiah(pnl.netProfit)}
              </span>
              <span className="text-[10px] text-emerald-700 font-medium">Margin: {formatPercent(pnl.netProfitMarginPct)}</span>
            </div>
          </div>

          {/* Full Monthly Statement Breakdown */}
          <div className="border border-slate-200 rounded-xl overflow-hidden shadow-xs">
            <div className="bg-slate-100 px-4 py-2.5 font-bold text-slate-900 border-b border-slate-200 flex justify-between items-center">
              <span>Laporan Laba Rugi {monthName} {year}</span>
              <span className="text-xs font-normal text-slate-500">Standar Akuntansi Internal</span>
            </div>

            <table className="w-full text-left border-collapse text-xs">
              <tbody className="divide-y divide-slate-100">
                <tr className="bg-slate-50/50 font-semibold">
                  <td className="py-2.5 px-4 text-slate-900">Total Penjualan (Sales)</td>
                  <td className="py-2.5 px-4 text-right font-mono text-slate-900 font-bold">{formatRupiah(pnl.sales)}</td>
                  <td className="py-2.5 px-4 text-right text-slate-500 w-24">100.0%</td>
                </tr>
                <tr>
                  <td className="py-2 px-4 pl-8 text-rose-700">- Beban Pokok Penjualan (HPP / COGS)</td>
                  <td className="py-2 px-4 text-right font-mono text-rose-700 font-semibold">-{formatRupiah(pnl.hpp)}</td>
                  <td className="py-2 px-4 text-right text-slate-500 w-24">{((pnl.hpp / pnl.sales) * 100).toFixed(1)}%</td>
                </tr>
                <tr className="bg-slate-100/70 font-semibold">
                  <td className="py-2.5 px-4 text-slate-950">= Laba Kotor (Gross Profit)</td>
                  <td className="py-2.5 px-4 text-right font-mono text-slate-950 font-bold">{formatRupiah(pnl.grossProfit)}</td>
                  <td className="py-2.5 px-4 text-right text-blue-700 font-semibold w-24">{pnl.grossMarginPct.toFixed(1)}%</td>
                </tr>
                <tr>
                  <td className="py-2 px-4 pl-8 text-amber-800">- Beban Operasional (OPEX)</td>
                  <td className="py-2 px-4 text-right font-mono text-amber-800 font-semibold">-{formatRupiah(pnl.totalOpex)}</td>
                  <td className="py-2 px-4 text-right text-slate-500 w-24">{((pnl.totalOpex / pnl.sales) * 100).toFixed(1)}%</td>
                </tr>
                <tr className="bg-slate-100/70 font-semibold">
                  <td className="py-2.5 px-4 text-slate-950">= EBITDA</td>
                  <td className="py-2.5 px-4 text-right font-mono text-indigo-900 font-bold">{formatRupiah(pnl.ebitda)}</td>
                  <td className="py-2.5 px-4 text-right text-indigo-700 font-semibold w-24">{pnl.ebitdaMarginPct.toFixed(1)}%</td>
                </tr>
                <tr>
                  <td className="py-2 px-4 pl-8 text-slate-600">- Beban Penyusutan (Depresiasi)</td>
                  <td className="py-2 px-4 text-right font-mono text-slate-700">-{formatRupiah(pnl.totalDepreciation)}</td>
                  <td className="py-2 px-4 text-right text-slate-500 w-24">{((pnl.totalDepreciation / pnl.sales) * 100).toFixed(1)}%</td>
                </tr>
                <tr className="bg-slate-100/70 font-semibold">
                  <td className="py-2.5 px-4 text-slate-950">= EBIT / Management Profit</td>
                  <td className="py-2.5 px-4 text-right font-mono text-slate-950 font-bold">{formatRupiah(pnl.ebit)}</td>
                  <td className="py-2.5 px-4 text-right text-slate-700 font-semibold w-24">{pnl.ebitMarginPct.toFixed(1)}%</td>
                </tr>
                <tr>
                  <td className="py-2 px-4 pl-8 text-slate-600">+/- Pos Non-Operasional Bersih</td>
                  <td className="py-2 px-4 text-right font-mono text-slate-700">{formatRupiah(pnl.netNonOperating)}</td>
                  <td className="py-2 px-4 text-right text-slate-500 w-24">-</td>
                </tr>
                <tr className="bg-slate-100/70 font-semibold">
                  <td className="py-2.5 px-4 text-slate-950">= Laba Sebelum Pajak (EBT)</td>
                  <td className="py-2.5 px-4 text-right font-mono text-slate-950 font-bold">{formatRupiah(pnl.ebt)}</td>
                  <td className="py-2.5 px-4 text-right text-slate-700 font-semibold w-24">-</td>
                </tr>
                <tr>
                  <td className="py-2 px-4 pl-8 text-rose-700">- Beban Pajak Penghasilan Badan</td>
                  <td className="py-2 px-4 text-right font-mono text-rose-700 font-semibold">-{formatRupiah(pnl.taxExpense)}</td>
                  <td className="py-2 px-4 text-right text-slate-500 w-24">22.0% EBT</td>
                </tr>
                <tr className="bg-emerald-100/60 font-bold border-t-2 border-emerald-400">
                  <td className="py-3 px-4 text-emerald-950">= LABA BERSIH (NET PROFIT)</td>
                  <td className="py-3 px-4 text-right font-mono text-emerald-950 text-sm">{formatRupiah(pnl.netProfit)}</td>
                  <td className="py-3 px-4 text-right text-emerald-900 font-bold w-24">{pnl.netProfitMarginPct.toFixed(1)}%</td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Month Sample Transactions */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="border border-slate-200 rounded-xl p-4 bg-white">
              <div className="font-bold text-slate-900 mb-2 flex items-center justify-between">
                <span>Contoh Penjualan {monthName}</span>
                <span className="text-[11px] font-normal text-slate-500">{monthSales.length} Transaksi</span>
              </div>
              <div className="space-y-2">
                {monthSales.slice(0, 4).map(s => (
                  <div key={s.id} className="p-2 rounded-lg bg-slate-50 flex justify-between items-center text-xs">
                    <div>
                      <div className="font-semibold text-slate-900">{s.customerName}</div>
                      <div className="text-[10px] text-slate-500">{s.productName} · {s.transactionNumber}</div>
                    </div>
                    <span className="font-mono font-bold text-slate-900">{formatRupiah(s.totalSales)}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="border border-slate-200 rounded-xl p-4 bg-white">
              <div className="font-bold text-slate-900 mb-2 flex items-center justify-between">
                <span>Contoh OPEX {monthName}</span>
                <span className="text-[11px] font-normal text-slate-500">{monthOpex.length} Transaksi</span>
              </div>
              <div className="space-y-2">
                {monthOpex.slice(0, 4).map(o => (
                  <div key={o.id} className="p-2 rounded-lg bg-slate-50 flex justify-between items-center text-xs">
                    <div>
                      <div className="font-semibold text-slate-900">{o.category}</div>
                      <div className="text-[10px] text-slate-500">{o.vendorName} · {o.opexNumber}</div>
                    </div>
                    <span className="font-mono font-bold text-slate-900">{formatRupiah(o.total)}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3.5 sm:p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between gap-3">
          <span className="text-[11px] text-slate-500 hidden sm:inline">
            Toko Cung Financial Reporting Engine
          </span>
          <div className="flex items-center gap-2 ml-auto">
            {onNavigateModule && (
              <button
                onClick={() => {
                  onClose();
                  onNavigateModule('monthly-pnl');
                }}
                className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white transition-colors cursor-pointer"
              >
                <span>Buka Lembar Kerja P&L</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
            <button
              onClick={onClose}
              className="px-3 py-1.5 rounded-lg text-xs font-medium border border-slate-200 bg-white hover:bg-slate-100 text-slate-700 transition-colors cursor-pointer"
            >
              Tutup
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
