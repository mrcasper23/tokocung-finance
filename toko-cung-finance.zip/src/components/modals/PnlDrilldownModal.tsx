import React, { useState, useMemo } from 'react';
import { useFinance } from '../../context/FinanceContext';
import {
  formatRupiah,
  formatPercent,
  formatDate,
  downloadCSV,
  printReport,
  MONTH_NAMES_ID
} from '../../utils/formatters';
import {
  X,
  Printer,
  FileSpreadsheet,
  Search,
  Building2,
  Calendar,
  Layers,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  FileText
} from 'lucide-react';

interface PnlDrilldownModalProps {
  rowLabel: string;
  rowLevel?: string;
  monthIndex?: number | null; // null for YTD
  value: number;
  year?: number;
  onClose: () => void;
}

export const PnlDrilldownModal: React.FC<PnlDrilldownModalProps> = ({
  rowLabel,
  rowLevel,
  monthIndex,
  value,
  year = 2026,
  onClose,
}) => {
  const { sales, hpp, opex, assets, nonOperating, taxes, entities, settings, currentMonthPnl } = useFinance();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedEntityId, setSelectedEntityId] = useState('ALL');

  const isYtd = monthIndex === null || monthIndex === undefined;
  const monthNum = isYtd ? null : (monthIndex as number) + 1;
  const periodTitle = isYtd ? `Konsolidasi Seluruh Tahun (YTD ${year})` : `${MONTH_NAMES_ID[monthIndex as number]} ${year}`;

  // Determine line item category
  const lowerLabel = rowLabel.toLowerCase();
  const isSalesLine = lowerLabel.includes('penjualan') || lowerLabel.includes('sales');
  const isHppLine = lowerLabel.includes('hpp') || lowerLabel.includes('pokok');
  const isDeprLine = lowerLabel.includes('depresiasi') || lowerLabel.includes('penyusutan');
  const isNonOpLine = lowerLabel.includes('non-operasional') || lowerLabel.includes('bunga');
  const isTaxLine = lowerLabel.includes('pajak') || lowerLabel.includes('tax');
  const isGrossProfit = lowerLabel.includes('kotor') || lowerLabel.includes('gross');
  const isEbitda = lowerLabel.includes('ebitda');
  const isEbit = lowerLabel.includes('ebit') || lowerLabel.includes('mgmt');
  const isEbt = lowerLabel.includes('sblm pajak') || lowerLabel.includes('ebt');
  const isNetProfit = lowerLabel.includes('bersih') || lowerLabel.includes('net');

  // Transactions filter
  const filteredSales = useMemo(() => {
    if (!isSalesLine) return [];
    return sales.filter(s => {
      const [y, m] = s.date.split('-').map(Number);
      const matchPeriod = isYtd ? y === year : (y === year && m === monthNum);
      const matchEntity = selectedEntityId === 'ALL' || s.entityId === selectedEntityId;
      const matchSearch =
        s.transactionNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
        s.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        s.productName.toLowerCase().includes(searchTerm.toLowerCase());
      return matchPeriod && matchEntity && matchSearch;
    });
  }, [sales, isSalesLine, isYtd, year, monthNum, selectedEntityId, searchTerm]);

  const filteredHpp = useMemo(() => {
    if (!isHppLine) return [];
    return hpp.filter(h => {
      const [y, m] = h.date.split('-').map(Number);
      const matchPeriod = isYtd ? y === year : (y === year && m === monthNum);
      const matchSearch =
        h.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
        h.productName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        h.supplierName.toLowerCase().includes(searchTerm.toLowerCase());
      return matchPeriod && matchSearch;
    });
  }, [hpp, isHppLine, isYtd, year, monthNum, searchTerm]);

  const filteredOpex = useMemo(() => {
    if (isSalesLine || isHppLine || isDeprLine || isNonOpLine || isTaxLine) return [];
    // Could be a specific OPEX category (e.g. Gaji, Utilities, ATK, etc.) or General OPEX
    return opex.filter(o => {
      const [y, m] = o.date.split('-').map(Number);
      const matchPeriod = isYtd ? y === year : (y === year && m === monthNum);
      const matchEntity = selectedEntityId === 'ALL' || o.entityId === selectedEntityId;
      const matchCategory =
        rowLabel.includes('OPEX') || rowLabel.includes('Operasional')
          ? true
          : o.category.toLowerCase().includes(rowLabel.toLowerCase()) || rowLabel.toLowerCase().includes(o.category.toLowerCase());
      const matchSearch =
        o.opexNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
        o.vendorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        o.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        o.category.toLowerCase().includes(searchTerm.toLowerCase());
      return matchPeriod && matchEntity && matchCategory && matchSearch;
    });
  }, [opex, isSalesLine, isHppLine, isDeprLine, isNonOpLine, isTaxLine, isYtd, year, monthNum, selectedEntityId, rowLabel, searchTerm]);

  const handleExport = () => {
    let headers: string[] = [];
    let rows: any[] = [];

    if (isSalesLine) {
      headers = ['No Transaksi', 'Tanggal', 'Entitas', 'Pelanggan', 'Produk', 'Qty', 'Total'];
      rows = filteredSales.map(s => [
        s.transactionNumber,
        s.date,
        entities.find(e => e.id === s.entityId)?.name || s.entityId,
        s.customerName,
        s.productName,
        s.qty,
        s.totalSales,
      ]);
    } else if (isHppLine) {
      headers = ['Tanggal', 'SKU', 'Produk', 'Supplier', 'Qty', 'Harga Satuan', 'Total HPP'];
      rows = filteredHpp.map(h => [h.date, h.sku, h.productName, h.supplierName, h.qty, h.unitCost, h.totalHpp]);
    } else if (filteredOpex.length > 0) {
      headers = ['No OPEX', 'Tanggal', 'Kategori', 'Vendor', 'Keterangan', 'Total'];
      rows = filteredOpex.map(o => [o.opexNumber, o.date, o.category, o.vendorName, o.description, o.total]);
    } else {
      printReport();
      return;
    }

    downloadCSV(`Rincian_${rowLabel}_${periodTitle}`, headers, rows);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 animate-in fade-in">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-4xl w-full max-h-[92vh] flex flex-col text-xs overflow-hidden animate-in zoom-in-95">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 bg-slate-50 flex items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-blue-900 text-white shadow-2xs">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight">
                  Rincian Transaksi: {rowLabel}
                </h2>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-white">
                  {periodTitle}
                </span>
              </div>
              <p className="text-slate-500 text-[11px] mt-0.5">
                Drill-down data transaksi asli yang membentuk saldo pos laporan keuangan ini.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={handleExport}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-100 text-slate-700 transition-colors cursor-pointer"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
              <span className="hidden sm:inline">Export</span>
            </button>
            <button
              onClick={printReport}
              className="p-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-100 text-slate-700 transition-colors cursor-pointer"
              title="Cetak Rincian"
            >
              <Printer className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-lg border border-slate-200 flex items-center justify-center text-slate-400 hover:text-slate-800 hover:bg-slate-200 transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Subheader Metric Banner */}
        <div className="px-5 py-3 bg-slate-900 text-white flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span className="text-slate-300 font-medium">Nilai Pos Pembukuan:</span>
            <span className="text-base font-bold font-mono text-white tabular-nums">
              {formatRupiah(value)}
            </span>
          </div>
          <div className="text-slate-400 text-[11px]">
            Sistem Pencatatan Akrual · Terhubung ke Buku Besar Toko Cung
          </div>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5">
          {/* If it's a summary formula row */}
          {(isGrossProfit || isEbitda || isEbit || isEbt || isNetProfit) && (
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-3">
              <div className="font-bold text-slate-900 text-sm">Formula & Alur Rekonsiliasi:</div>
              <div className="p-3 bg-white rounded-lg border border-slate-200 font-mono text-xs text-slate-700">
                {isGrossProfit && 'Laba Kotor = Penjualan (Sales) - Beban Pokok Penjualan (HPP)'}
                {isEbitda && 'EBITDA = Laba Kotor (Gross Profit) - Total Beban Operasional (OPEX)'}
                {isEbit && 'EBIT = EBITDA - Total Beban Penyusutan (Depresiasi Aset)'}
                {isEbt && 'EBT = EBIT + Pendapatan Bunga - Beban Bunga & Non-Operasional'}
                {isNetProfit && `Laba Bersih = EBT - Beban Pajak Penghasilan (${settings.taxRatePercent}%)`}
              </div>
              <p className="text-[11px] text-slate-500">
                Angka ringkasan ini dihitung secara real-time dari konsolidasi transaksi operasional masing-masing cabang.
              </p>
            </div>
          )}

          {/* Sales drilldown table */}
          {isSalesLine && (
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-2 flex-1 max-w-sm border border-slate-200 rounded-lg px-2.5 py-1.5 bg-slate-50">
                  <Search className="w-3.5 h-3.5 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Cari transaksi, customer, produk..."
                    value={searchTerm}
                    onChange={e => setSearchTerm(e.target.value)}
                    className="w-full bg-transparent outline-none text-xs text-slate-800 placeholder-slate-400"
                  />
                </div>
                <select
                  value={selectedEntityId}
                  onChange={e => setSelectedEntityId(e.target.value)}
                  className="border border-slate-200 rounded-lg px-2 py-1 text-xs bg-white text-slate-700"
                >
                  <option value="ALL">Semua Entitas ({filteredSales.length})</option>
                  {entities.map(ent => (
                    <option key={ent.id} value={ent.id}>{ent.name}</option>
                  ))}
                </select>
              </div>

              <div className="border border-slate-200 rounded-xl overflow-hidden">
                <div className="max-h-[360px] overflow-y-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead className="bg-slate-100 text-slate-700 sticky top-0 border-b border-slate-200 font-semibold">
                      <tr>
                        <th className="py-2.5 px-3">No. Faktur</th>
                        <th className="py-2.5 px-3">Tanggal</th>
                        <th className="py-2.5 px-3">Pelanggan</th>
                        <th className="py-2.5 px-3">Produk</th>
                        <th className="py-2.5 px-3 text-right">Qty</th>
                        <th className="py-2.5 px-3 text-right">Harga Satuan</th>
                        <th className="py-2.5 px-3 text-right">Total Penjualan</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {filteredSales.map(s => (
                        <tr key={s.id} className="hover:bg-slate-50">
                          <td className="py-2 px-3 font-mono font-semibold text-slate-900">{s.transactionNumber}</td>
                          <td className="py-2 px-3 text-slate-600">{formatDate(s.date)}</td>
                          <td className="py-2 px-3 text-slate-900 font-medium">{s.customerName}</td>
                          <td className="py-2 px-3 text-slate-800">{s.productName}</td>
                          <td className="py-2 px-3 text-right font-mono tabular-nums text-slate-700">{s.qty}</td>
                          <td className="py-2 px-3 text-right font-mono tabular-nums text-slate-600">
                            {formatRupiah(s.unitPrice)}
                          </td>
                          <td className="py-2 px-3 text-right font-mono font-bold tabular-nums text-slate-950">
                            {formatRupiah(s.totalSales)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* HPP drilldown table */}
          {isHppLine && (
            <div className="space-y-3">
              <div className="border border-slate-200 rounded-xl overflow-hidden">
                <div className="max-h-[360px] overflow-y-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead className="bg-slate-100 text-slate-700 sticky top-0 border-b border-slate-200 font-semibold">
                      <tr>
                        <th className="py-2.5 px-3">Tanggal</th>
                        <th className="py-2.5 px-3">SKU</th>
                        <th className="py-2.5 px-3">Produk</th>
                        <th className="py-2.5 px-3">Supplier Principal</th>
                        <th className="py-2.5 px-3 text-right">Qty</th>
                        <th className="py-2.5 px-3 text-right">Harga Pokok (Unit)</th>
                        <th className="py-2.5 px-3 text-right">Total HPP</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {filteredHpp.map(h => (
                        <tr key={h.id} className="hover:bg-slate-50">
                          <td className="py-2 px-3 text-slate-600">{formatDate(h.date)}</td>
                          <td className="py-2 px-3 font-mono font-semibold text-slate-900">{h.sku}</td>
                          <td className="py-2 px-3 font-medium text-slate-800">{h.productName}</td>
                          <td className="py-2 px-3 text-slate-700">{h.supplierName}</td>
                          <td className="py-2 px-3 text-right font-mono tabular-nums text-slate-700">{h.qty}</td>
                          <td className="py-2 px-3 text-right font-mono tabular-nums text-slate-600">
                            {formatRupiah(h.unitCost)}
                          </td>
                          <td className="py-2 px-3 text-right font-mono font-bold tabular-nums text-slate-900">
                            {formatRupiah(h.totalHpp)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* Depresiasi drilldown table */}
          {isDeprLine && (
            <div className="space-y-3">
              <div className="border border-slate-200 rounded-xl overflow-hidden">
                <div className="bg-slate-100 px-3 py-2 border-b border-slate-200 font-semibold text-slate-800">
                  Daftar Aset yang Disusutkan (Amortisasi Bulanan)
                </div>
                <div className="max-h-[360px] overflow-y-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead className="bg-slate-50 text-slate-700 sticky top-0 border-b border-slate-200">
                      <tr>
                        <th className="py-2 px-3">Kode Aset</th>
                        <th className="py-2 px-3">Nama Aset</th>
                        <th className="py-2 px-3">Kategori</th>
                        <th className="py-2 px-3 text-right">Nilai Perolehan</th>
                        <th className="py-2 px-3 text-right">Masa Manfaat</th>
                        <th className="py-2 px-3 text-right">Beban Susut / Bulan</th>
                        <th className="py-2 px-3 text-right">Nilai Buku</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {assets.map(a => (
                        <tr key={a.id} className="hover:bg-slate-50">
                          <td className="py-2 px-3 font-mono font-semibold text-slate-900">{a.assetCode}</td>
                          <td className="py-2 px-3 font-medium text-slate-800">{a.assetName}</td>
                          <td className="py-2 px-3 text-slate-600">{a.category}</td>
                          <td className="py-2 px-3 text-right font-mono tabular-nums text-slate-700">
                            {formatRupiah(a.acquisitionCost)}
                          </td>
                          <td className="py-2 px-3 text-right font-mono tabular-nums text-slate-600">
                            {a.usefulLifeMonths} bln
                          </td>
                          <td className="py-2 px-3 text-right font-mono font-bold tabular-nums text-indigo-700">
                            {formatRupiah(a.monthlyDepreciation)}
                          </td>
                          <td className="py-2 px-3 text-right font-mono tabular-nums text-slate-900">
                            {formatRupiah(a.bookValue)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* OPEX drilldown table */}
          {!isSalesLine && !isHppLine && !isDeprLine && filteredOpex.length > 0 && (
            <div className="space-y-3">
              <div className="border border-slate-200 rounded-xl overflow-hidden">
                <div className="max-h-[360px] overflow-y-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead className="bg-slate-100 text-slate-700 sticky top-0 border-b border-slate-200 font-semibold">
                      <tr>
                        <th className="py-2.5 px-3">No. OPEX</th>
                        <th className="py-2.5 px-3">Tanggal</th>
                        <th className="py-2.5 px-3">Kategori</th>
                        <th className="py-2.5 px-3">Vendor / Rekanan</th>
                        <th className="py-2.5 px-3">Keterangan</th>
                        <th className="py-2.5 px-3 text-right">Nominal Beban</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {filteredOpex.map(o => (
                        <tr key={o.id} className="hover:bg-slate-50">
                          <td className="py-2 px-3 font-mono font-semibold text-slate-900">{o.opexNumber}</td>
                          <td className="py-2 px-3 text-slate-600">{formatDate(o.date)}</td>
                          <td className="py-2 px-3">
                            <span className="px-2 py-0.5 rounded text-[10px] bg-slate-100 font-medium text-slate-800">
                              {o.category}
                            </span>
                          </td>
                          <td className="py-2 px-3 text-slate-700 font-medium">{o.vendorName}</td>
                          <td className="py-2 px-3 text-slate-600 max-w-[200px] truncate">{o.description}</td>
                          <td className="py-2 px-3 text-right font-mono font-bold tabular-nums text-slate-900">
                            {formatRupiah(o.total)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* Non operating breakdown */}
          {isNonOpLine && (
            <div className="border border-slate-200 rounded-xl p-4 space-y-2">
              <div className="font-bold text-slate-900 mb-2">Daftar Transaksi Non-Operasional:</div>
              {nonOperating.map(no => (
                <div key={no.id} className="flex justify-between items-center py-2 border-b border-slate-100">
                  <div>
                    <div className="font-semibold text-slate-900">{no.description}</div>
                    <div className="text-[11px] text-slate-500">{no.category} · {formatDate(no.date)}</div>
                  </div>
                  <span className={`font-mono font-bold ${no.type === 'Income' ? 'text-emerald-700' : 'text-rose-700'}`}>
                    {no.type === 'Income' ? '+' : '-'}{formatRupiah(no.nominal)}
                  </span>
                </div>
              ))}
            </div>
          )}

          {/* Pajak breakdown */}
          {isTaxLine && (
            <div className="border border-slate-200 rounded-xl p-4 space-y-3">
              <div className="font-bold text-slate-900">Penghitungan Estimasi Beban Pajak Badan:</div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
                  <span className="text-slate-500 block">Dasar Pengenaan Pajak (DPP / EBT)</span>
                  <span className="text-base font-bold text-slate-900 font-mono mt-0.5">{formatRupiah(currentMonthPnl.ebt)}</span>
                </div>
                <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
                  <span className="text-slate-500 block">Tarif Pajak Berlaku</span>
                  <span className="text-base font-bold text-blue-700 font-mono mt-0.5">{settings.taxRatePercent}%</span>
                </div>
                <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
                  <span className="text-slate-500 block">Total Beban Pajak</span>
                  <span className="text-base font-bold text-rose-700 font-mono mt-0.5">{formatRupiah(currentMonthPnl.taxExpense)}</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3.5 sm:p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between gap-3">
          <span className="text-[11px] text-slate-500 hidden sm:inline">
            Klik di luar atau tombol Tutup untuk kembali ke spreadsheet P&L
          </span>
          <button
            onClick={onClose}
            className="ml-auto px-4 py-1.5 rounded-lg text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white transition-colors cursor-pointer"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
