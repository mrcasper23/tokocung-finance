import React, { useState, useMemo } from 'react';
import { useFinance } from '../../context/FinanceContext';
import {
  formatRupiah,
  formatPercent,
  formatDate,
  downloadCSV,
  printReport,
  MONTH_NAMES_ID
} from '../../utils/formatters';
import {
  X,
  Printer,
  FileSpreadsheet,
  Search,
  DollarSign,
  TrendingUp,
  Percent,
  Coins,
  Scale,
  Building2,
  Calendar,
  Tag,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  Info
} from 'lucide-react';

export type KpiMetricType =
  | 'sales'
  | 'gross_profit'
  | 'ebitda'
  | 'ebit'
  | 'ebt'
  | 'net_profit'
  | 'cash_bank'
  | 'capex'
  | 'opex';

interface KpiDetailModalProps {
  metric: KpiMetricType;
  onClose: () => void;
  onNavigateModule?: (moduleId: string) => void;
}

export const KpiDetailModal: React.FC<KpiDetailModalProps> = ({
  metric,
  onClose,
  onNavigateModule,
}) => {
  const {
    currentMonthPnl,
    yearlyPnlSummary,
    twelveMonthsPnl,
    sales,
    hpp,
    opex,
    assets,
    capexRequests,
    nonOperating,
    taxes,
    cashMutations,
    entities,
    globalFilter,
    settings,
  } = useFinance();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedEntityId, setSelectedEntityId] = useState<string>('ALL');

  const isYtd = globalFilter.period === 'YTD';
  const pnl = isYtd ? yearlyPnlSummary : currentMonthPnl;
  const currentMonthName = MONTH_NAMES_ID[globalFilter.month - 1];
  const periodLabel = isYtd ? `YTD ${globalFilter.year}` : `${currentMonthName} ${globalFilter.year}`;

  // Filter transactions by period & entity
  const filteredSales = useMemo(() => {
    return sales.filter(s => {
      const [y, m] = s.date.split('-').map(Number);
      const matchPeriod = isYtd ? y === globalFilter.year : (y === globalFilter.year && m === globalFilter.month);
      const matchEntity = selectedEntityId === 'ALL' || s.entityId === selectedEntityId;
      const matchSearch =
        s.transactionNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
        s.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        s.productName.toLowerCase().includes(searchTerm.toLowerCase());
      return matchPeriod && matchEntity && matchSearch;
    });
  }, [sales, isYtd, globalFilter, selectedEntityId, searchTerm]);

  const filteredHpp = useMemo(() => {
    return hpp.filter(h => {
      const [y, m] = h.date.split('-').map(Number);
      const matchPeriod = isYtd ? y === globalFilter.year : (y === globalFilter.year && m === globalFilter.month);
      const matchSearch =
        h.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
        h.productName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        h.supplierName.toLowerCase().includes(searchTerm.toLowerCase());
      return matchPeriod && matchSearch;
    });
  }, [hpp, isYtd, globalFilter, searchTerm]);

  const filteredOpex = useMemo(() => {
    return opex.filter(o => {
      const [y, m] = o.date.split('-').map(Number);
      const matchPeriod = isYtd ? y === globalFilter.year : (y === globalFilter.year && m === globalFilter.month);
      const matchEntity = selectedEntityId === 'ALL' || o.entityId === selectedEntityId;
      const matchSearch =
        o.opexNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
        o.vendorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        o.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        o.category.toLowerCase().includes(searchTerm.toLowerCase());
      return matchPeriod && matchEntity && matchSearch;
    });
  }, [opex, isYtd, globalFilter, selectedEntityId, searchTerm]);

  // Content configuration per KPI metric
  const meta = useMemo(() => {
    switch (metric) {
      case 'sales':
        return {
          title: 'Rincian Penjualan (Sales)',
          subtitle: `Total pendapatan kotor dari penjualan barang & jasa periode ${periodLabel}`,
          amount: pnl.sales,
          formula: 'Sales = ∑ (Qty × Harga Satuan - Diskon)',
          badgeColor: 'bg-slate-900 text-white',
          icon: <DollarSign className="w-5 h-5 text-blue-500" />,
        };
      case 'gross_profit':
        return {
          title: 'Rincian Laba Kotor (Gross Profit)',
          subtitle: `Penjualan dikurangi Beban Pokok Penjualan (HPP) · Margin ${formatPercent(pnl.grossMarginPct)}`,
          amount: pnl.grossProfit,
          formula: 'Gross Profit = Sales - HPP / COGS',
          badgeColor: 'bg-blue-600 text-white',
          icon: <Coins className="w-5 h-5 text-amber-500" />,
        };
      case 'ebitda':
        return {
          title: 'Rincian EBITDA',
          subtitle: `Laba operasional sebelum beban depresiasi · Margin ${formatPercent(pnl.ebitdaMarginPct)}`,
          amount: pnl.ebitda,
          formula: 'EBITDA = Gross Profit - Total Beban Operasional (OPEX)',
          badgeColor: 'bg-indigo-600 text-white',
          icon: <TrendingUp className="w-5 h-5 text-indigo-500" />,
        };
      case 'ebit':
        return {
          title: 'Rincian EBIT / Management Profit',
          subtitle: `Laba operasional bersih setelah beban penyusutan aset tetap`,
          amount: pnl.ebit,
          formula: 'EBIT = EBITDA - Total Beban Penyusutan (Depreciation)',
          badgeColor: 'bg-purple-600 text-white',
          icon: <Scale className="w-5 h-5 text-purple-500" />,
        };
      case 'ebt':
        return {
          title: 'Rincian Laba Sebelum Pajak (EBT)',
          subtitle: `Laba operasional (EBIT) disesuaikan dengan pos pendapatan & beban non-operasional`,
          amount: pnl.ebt,
          formula: 'EBT = EBIT + Pendapatan Bunga - Biaya Bunga & Admin Non-Op',
          badgeColor: 'bg-amber-600 text-white',
          icon: <Scale className="w-5 h-5 text-amber-500" />,
        };
      case 'net_profit':
        return {
          title: 'Rincian Laba Bersih (Net Profit)',
          subtitle: `Keuntungan bersih akhir setelah kewajiban Pajak Penghasilan Badan (PPh)`,
          amount: pnl.netProfit,
          formula: `Net Profit = EBT - Estimasi Beban Pajak Badan (${settings.taxRatePercent}%)`,
          badgeColor: 'bg-emerald-600 text-white',
          icon: <Percent className="w-5 h-5 text-emerald-500" />,
        };
      case 'opex':
        return {
          title: 'Rincian Beban Operasional (OPEX)',
          subtitle: `Total pengeluaran operasional toko dan kantor pusat periode ${periodLabel}`,
          amount: pnl.totalOpex,
          formula: 'Total OPEX = ∑ 14 Pos Beban Operasional',
          badgeColor: 'bg-rose-600 text-white',
          icon: <Tag className="w-5 h-5 text-rose-500" />,
        };
      case 'capex':
        return {
          title: 'Rincian Belanja Modal (CAPEX)',
          subtitle: `Investasi pengadaan aset tetap (dikapitalisasi, tidak memotong laba berjalan)`,
          amount: capexRequests.reduce((sum, c) => sum + c.acquisitionCost, 0),
          formula: 'CAPEX = Arus Kas Keluar Investasi (Masuk ke Asset Register)',
          badgeColor: 'bg-amber-700 text-white',
          icon: <Building2 className="w-5 h-5 text-amber-500" />,
        };
      case 'cash_bank':
        return {
          title: 'Rincian Saldo Kas & Bank',
          subtitle: `Posisi likuiditas kas operasional, rekening bank mandiri, dan petty cash`,
          amount: 285_400_000,
          formula: 'Saldo Akhir = Saldo Awal + Kas Masuk - Kas Keluar',
          badgeColor: 'bg-teal-600 text-white',
          icon: <DollarSign className="w-5 h-5 text-teal-500" />,
        };
    }
  }, [metric, pnl, periodLabel, settings.taxRatePercent, capexRequests]);

  const handleExport = () => {
    if (metric === 'sales') {
      const headers = ['No Transaksi', 'Tanggal', 'Entitas', 'Customer', 'Produk', 'Qty', 'Total'];
      const rows = filteredSales.map(s => [
        s.transactionNumber,
        s.date,
        entities.find(e => e.id === s.entityId)?.name || s.entityId,
        s.customerName,
        s.productName,
        s.qty,
        s.totalSales,
      ]);
      downloadCSV(`Detail_Penjualan_${periodLabel}`, headers, rows);
    } else if (metric === 'opex') {
      const headers = ['No OPEX', 'Tanggal', 'Kategori', 'Vendor', 'Keterangan', 'Total'];
      const rows = filteredOpex.map(o => [
        o.opexNumber,
        o.date,
        o.category,
        o.vendorName,
        o.description,
        o.total,
      ]);
      downloadCSV(`Detail_OPEX_${periodLabel}`, headers, rows);
    } else {
      printReport();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 animate-in fade-in">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-4xl w-full max-h-[92vh] flex flex-col text-xs overflow-hidden animate-in zoom-in-95">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 bg-slate-50 flex items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-white border border-slate-200 shadow-2xs">
              {meta.icon}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight">
                  {meta.title}
                </h2>
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${meta.badgeColor}`}>
                  {periodLabel}
                </span>
              </div>
              <p className="text-slate-500 text-[11px] mt-0.5">{meta.subtitle}</p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={handleExport}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-100 text-slate-700 transition-colors cursor-pointer"
              title="Unduh Data"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
              <span className="hidden sm:inline">Export</span>
            </button>
            <button
              onClick={printReport}
              className="p-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-100 text-slate-700 transition-colors cursor-pointer"
              title="Cetak Ringkasan"
            >
              <Printer className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-lg border border-slate-200 flex items-center justify-center text-slate-400 hover:text-slate-800 hover:bg-slate-200 transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Accounting Rule Ribbon */}
        <div className="px-5 py-2.5 bg-slate-900 text-slate-200 flex flex-wrap items-center justify-between gap-2 text-[11px]">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="font-mono text-slate-300 font-medium">{meta.formula}</span>
          </div>
          <div className="text-slate-400 tabular-nums">
            Nominal Total: <strong className="text-white font-mono text-xs ml-1">{formatRupiah(meta.amount)}</strong>
          </div>
        </div>

        {/* Modal Body Container */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5">
          {/* Top KPI Breakdown Stat Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-slate-50 border border-slate-200/90 rounded-xl p-3">
              <span className="text-[10px] font-semibold text-slate-500 uppercase block">Total Nilai</span>
              <span className="text-base sm:text-lg font-bold text-slate-900 font-mono tabular-nums block mt-0.5">
                {formatRupiah(meta.amount)}
              </span>
              <span className="text-[10px] text-slate-400">Periode terpilih</span>
            </div>

            <div className="bg-slate-50 border border-slate-200/90 rounded-xl p-3">
              <span className="text-[10px] font-semibold text-slate-500 uppercase block">% Terhadap Sales</span>
              <span className="text-base sm:text-lg font-bold text-blue-700 font-mono tabular-nums block mt-0.5">
                {pnl.sales > 0 ? `${((meta.amount / pnl.sales) * 100).toFixed(1)}%` : '100%'}
              </span>
              <span className="text-[10px] text-slate-400">Basis sales neto</span>
            </div>

            <div className="bg-slate-50 border border-slate-200/90 rounded-xl p-3">
              <span className="text-[10px] font-semibold text-slate-500 uppercase block">Total Sales</span>
              <span className="text-base sm:text-lg font-bold text-slate-800 font-mono tabular-nums block mt-0.5">
                {formatRupiah(pnl.sales)}
              </span>
              <span className="text-[10px] text-slate-400">Rujukan P&L</span>
            </div>

            <div className="bg-slate-50 border border-slate-200/90 rounded-xl p-3">
              <span className="text-[10px] font-semibold text-slate-500 uppercase block">Status Audit</span>
              <div className="flex items-center gap-1.5 mt-1 text-emerald-700 font-semibold text-xs">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Terverifikasi</span>
              </div>
              <span className="text-[10px] text-slate-400">Tersinkronisasi otomatis</span>
            </div>
          </div>

          {/* Conditional Detail Tables depending on metric */}
          {metric === 'sales' && (
            <div className="space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2 flex-1 max-w-sm border border-slate-200 rounded-lg px-2.5 py-1.5 bg-slate-50">
                  <Search className="w-3.5 h-3.5 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Cari transaksi, customer, produk..."
                    value={searchTerm}
                    onChange={e => setSearchTerm(e.target.value)}
                    className="w-full bg-transparent outline-none text-xs text-slate-800 placeholder-slate-400"
                  />
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-slate-500 text-[11px]">Entitas:</span>
                  <select
                    value={selectedEntityId}
                    onChange={e => setSelectedEntityId(e.target.value)}
                    className="border border-slate-200 rounded-lg px-2 py-1 text-xs bg-white text-slate-700"
                  >
                    <option value="ALL">Semua Entitas ({sales.length})</option>
                    {entities.map(ent => (
                      <option key={ent.id} value={ent.id}>
                        {ent.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="border border-slate-200 rounded-xl overflow-hidden">
                <div className="max-h-[360px] overflow-y-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead className="bg-slate-100 text-slate-700 sticky top-0 z-10 border-b border-slate-200 font-semibold">
                      <tr>
                        <th className="py-2.5 px-3">No. Faktur</th>
                        <th className="py-2.5 px-3">Tanggal</th>
                        <th className="py-2.5 px-3">Entitas</th>
                        <th className="py-2.5 px-3">Pelanggan</th>
                        <th className="py-2.5 px-3">Produk</th>
                        <th className="py-2.5 px-3 text-right">Qty</th>
                        <th className="py-2.5 px-3 text-right">Harga Satuan</th>
                        <th className="py-2.5 px-3 text-right">Total Penjualan</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {filteredSales.map(s => (
                        <tr key={s.id} className="hover:bg-slate-50">
                          <td className="py-2 px-3 font-mono font-semibold text-slate-900">{s.transactionNumber}</td>
                          <td className="py-2 px-3 text-slate-600">{formatDate(s.date)}</td>
                          <td className="py-2 px-3 text-slate-700 font-medium">
                            {entities.find(e => e.id === s.entityId)?.code || s.entityId}
                          </td>
                          <td className="py-2 px-3 text-slate-900 font-medium">{s.customerName}</td>
                          <td className="py-2 px-3 text-slate-800">{s.productName}</td>
                          <td className="py-2 px-3 text-right font-mono tabular-nums text-slate-700">{s.qty}</td>
                          <td className="py-2 px-3 text-right font-mono tabular-nums text-slate-600">
                            {formatRupiah(s.unitPrice)}
                          </td>
                          <td className="py-2 px-3 text-right font-mono font-bold tabular-nums text-slate-950">
                            {formatRupiah(s.totalSales)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {metric === 'gross_profit' && (
            <div className="space-y-4">
              <div className="p-4 bg-blue-50/60 border border-blue-200/80 rounded-xl space-y-2">
                <div className="font-semibold text-blue-950">Komposisi Perhitungan Laba Kotor:</div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div className="bg-white p-3 rounded-lg border border-blue-100">
                    <span className="text-slate-500 block">Total Penjualan</span>
                    <span className="text-base font-bold text-slate-900 font-mono">{formatRupiah(pnl.sales)}</span>
                  </div>
                  <div className="bg-white p-3 rounded-lg border border-rose-100">
                    <span className="text-rose-600 block">Beban Pokok Penjualan (HPP)</span>
                    <span className="text-base font-bold text-rose-700 font-mono">-{formatRupiah(pnl.hpp)}</span>
                  </div>
                  <div className="bg-white p-3 rounded-lg border border-emerald-100">
                    <span className="text-emerald-700 block">Laba Kotor (Gross Profit)</span>
                    <span className="text-base font-bold text-emerald-800 font-mono">{formatRupiah(pnl.grossProfit)}</span>
                  </div>
                </div>
              </div>

              <div className="border border-slate-200 rounded-xl overflow-hidden">
                <div className="bg-slate-100 px-3 py-2 border-b border-slate-200 font-semibold text-slate-800 flex justify-between">
                  <span>Daftar Transaksi Beban Pokok Penjualan (HPP / COGS)</span>
                  <span className="font-mono text-slate-600">Total HPP: {formatRupiah(pnl.hpp)}</span>
                </div>
                <div className="max-h-[300px] overflow-y-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead className="bg-slate-50 text-slate-600 sticky top-0 border-b border-slate-200">
                      <tr>
                        <th className="py-2 px-3">Tanggal</th>
                        <th className="py-2 px-3">SKU</th>
                        <th className="py-2 px-3">Produk</th>
                        <th className="py-2 px-3">Supplier Principal</th>
                        <th className="py-2 px-3 text-right">Qty</th>
                        <th className="py-2 px-3 text-right">Harga Pokok (Unit)</th>
                        <th className="py-2 px-3 text-right">Total HPP</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {filteredHpp.map(h => (
                        <tr key={h.id} className="hover:bg-slate-50">
                          <td className="py-2 px-3 text-slate-600">{formatDate(h.date)}</td>
                          <td className="py-2 px-3 font-mono font-semibold text-slate-900">{h.sku}</td>
                          <td className="py-2 px-3 font-medium text-slate-800">{h.productName}</td>
                          <td className="py-2 px-3 text-slate-700">{h.supplierName}</td>
                          <td className="py-2 px-3 text-right font-mono tabular-nums text-slate-700">{h.qty}</td>
                          <td className="py-2 px-3 text-right font-mono tabular-nums text-slate-600">
                            {formatRupiah(h.unitCost)}
                          </td>
                          <td className="py-2 px-3 text-right font-mono font-bold tabular-nums text-slate-900">
                            {formatRupiah(h.totalHpp)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {(metric === 'ebitda' || metric === 'opex') && (
            <div className="space-y-4">
              <div className="p-4 bg-indigo-50/60 border border-indigo-200/80 rounded-xl space-y-2">
                <div className="font-semibold text-indigo-950">Rincian EBITDA & Pengurang Operasional:</div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div className="bg-white p-3 rounded-lg border border-indigo-100">
                    <span className="text-slate-500 block">Laba Kotor (Gross Profit)</span>
                    <span className="text-base font-bold text-slate-900 font-mono">{formatRupiah(pnl.grossProfit)}</span>
                  </div>
                  <div className="bg-white p-3 rounded-lg border border-rose-100">
                    <span className="text-rose-600 block">Total Beban OPEX</span>
                    <span className="text-base font-bold text-rose-700 font-mono">-{formatRupiah(pnl.totalOpex)}</span>
                  </div>
                  <div className="bg-white p-3 rounded-lg border border-emerald-100">
                    <span className="text-emerald-700 block">EBITDA ({formatPercent(pnl.ebitdaMarginPct)})</span>
                    <span className="text-base font-bold text-emerald-800 font-mono">{formatRupiah(pnl.ebitda)}</span>
                  </div>
                </div>
              </div>

              <div className="border border-slate-200 rounded-xl overflow-hidden">
                <div className="bg-slate-100 px-3 py-2 border-b border-slate-200 font-semibold text-slate-800 flex justify-between">
                  <span>Daftar Beban Operasional Terjadwal (OPEX)</span>
                  <span className="font-mono text-slate-600">{filteredOpex.length} Transaksi</span>
                </div>
                <div className="max-h-[300px] overflow-y-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead className="bg-slate-50 text-slate-600 sticky top-0 border-b border-slate-200">
                      <tr>
                        <th className="py-2 px-3">No. OPEX</th>
                        <th className="py-2 px-3">Tanggal</th>
                        <th className="py-2 px-3">Kategori</th>
                        <th className="py-2 px-3">Vendor Rekanan</th>
                        <th className="py-2 px-3">Keterangan</th>
                        <th className="py-2 px-3 text-right">Nominal Beban</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {filteredOpex.map(o => (
                        <tr key={o.id} className="hover:bg-slate-50">
                          <td className="py-2 px-3 font-mono font-semibold text-slate-900">{o.opexNumber}</td>
                          <td className="py-2 px-3 text-slate-600">{formatDate(o.date)}</td>
                          <td className="py-2 px-3">
                            <span className="px-2 py-0.5 rounded text-[10px] bg-slate-100 font-medium text-slate-800">
                              {o.category}
                            </span>
                          </td>
                          <td className="py-2 px-3 text-slate-700 font-medium">{o.vendorName}</td>
                          <td className="py-2 px-3 text-slate-600 max-w-[200px] truncate">{o.description}</td>
                          <td className="py-2 px-3 text-right font-mono font-bold tabular-nums text-slate-900">
                            {formatRupiah(o.total)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {metric === 'ebit' && (
            <div className="space-y-4">
              <div className="p-4 bg-purple-50/60 border border-purple-200/80 rounded-xl space-y-2">
                <div className="font-semibold text-purple-950">Formula EBIT (Operating Profit):</div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div className="bg-white p-3 rounded-lg border border-purple-100">
                    <span className="text-slate-500 block">EBITDA</span>
                    <span className="text-base font-bold text-slate-900 font-mono">{formatRupiah(pnl.ebitda)}</span>
                  </div>
                  <div className="bg-white p-3 rounded-lg border border-rose-100">
                    <span className="text-rose-600 block">Beban Penyusutan (Depresiasi)</span>
                    <span className="text-base font-bold text-rose-700 font-mono">-{formatRupiah(pnl.totalDepreciation)}</span>
                  </div>
                  <div className="bg-white p-3 rounded-lg border border-emerald-100">
                    <span className="text-emerald-700 block">EBIT / Management Profit</span>
                    <span className="text-base font-bold text-emerald-800 font-mono">{formatRupiah(pnl.ebit)}</span>
                  </div>
                </div>
              </div>

              <div className="border border-slate-200 rounded-xl overflow-hidden">
                <div className="bg-slate-100 px-3 py-2 border-b border-slate-200 font-semibold text-slate-800 flex justify-between">
                  <span>Aset Tetap & Alokasi Beban Penyusutan Bulanan</span>
                  <span className="font-mono text-slate-600">Total Susut: {formatRupiah(pnl.totalDepreciation)}/bln</span>
                </div>
                <div className="max-h-[300px] overflow-y-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead className="bg-slate-50 text-slate-600 sticky top-0 border-b border-slate-200">
                      <tr>
                        <th className="py-2 px-3">Kode Aset</th>
                        <th className="py-2 px-3">Nama Aset</th>
                        <th className="py-2 px-3">Kategori</th>
                        <th className="py-2 px-3 text-right">Nilai Perolehan</th>
                        <th className="py-2 px-3 text-right">Masa Manfaat</th>
                        <th className="py-2 px-3 text-right">Beban Susut / Bulan</th>
                        <th className="py-2 px-3 text-right">Nilai Buku</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {assets.map(a => (
                        <tr key={a.id} className="hover:bg-slate-50">
                          <td className="py-2 px-3 font-mono font-semibold text-slate-900">{a.assetCode}</td>
                          <td className="py-2 px-3 font-medium text-slate-800">{a.assetName}</td>
                          <td className="py-2 px-3 text-slate-600">{a.category}</td>
                          <td className="py-2 px-3 text-right font-mono tabular-nums text-slate-700">
                            {formatRupiah(a.acquisitionCost)}
                          </td>
                          <td className="py-2 px-3 text-right font-mono tabular-nums text-slate-600">
                            {a.usefulLifeMonths} bln
                          </td>
                          <td className="py-2 px-3 text-right font-mono font-bold tabular-nums text-indigo-700">
                            {formatRupiah(a.monthlyDepreciation)}
                          </td>
                          <td className="py-2 px-3 text-right font-mono tabular-nums text-slate-900 font-semibold">
                            {formatRupiah(a.bookValue)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {metric === 'ebt' && (
            <div className="space-y-4">
              <div className="p-4 bg-amber-50/60 border border-amber-200/80 rounded-xl space-y-2">
                <div className="font-semibold text-amber-950">Formula Laba Sebelum Pajak (EBT):</div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div className="bg-white p-3 rounded-lg border border-amber-100">
                    <span className="text-slate-500 block">EBIT</span>
                    <span className="text-base font-bold text-slate-900 font-mono">{formatRupiah(pnl.ebit)}</span>
                  </div>
                  <div className="bg-white p-3 rounded-lg border border-amber-100">
                    <span className="text-slate-600 block">Net Non-Operating</span>
                    <span className="text-base font-bold text-slate-800 font-mono">{formatRupiah(pnl.netNonOperating)}</span>
                  </div>
                  <div className="bg-white p-3 rounded-lg border border-emerald-100">
                    <span className="text-emerald-700 block">EBT</span>
                    <span className="text-base font-bold text-emerald-800 font-mono">{formatRupiah(pnl.ebt)}</span>
                  </div>
                </div>
              </div>

              <div className="border border-slate-200 rounded-xl overflow-hidden">
                <div className="bg-slate-100 px-3 py-2 border-b border-slate-200 font-semibold text-slate-800">
                  Pos Pendapatan & Beban Non-Operasional
                </div>
                <div className="p-4 space-y-2 text-xs">
                  {nonOperating.map(no => (
                    <div key={no.id} className="flex justify-between items-center py-1.5 border-b border-slate-100">
                      <div>
                        <div className="font-semibold text-slate-900">{no.description}</div>
                        <div className="text-[11px] text-slate-500">{no.category} · {formatDate(no.date)}</div>
                      </div>
                      <span className={`font-mono font-bold ${no.type === 'Income' ? 'text-emerald-700' : 'text-rose-700'}`}>
                        {no.type === 'Income' ? '+' : '-'}{formatRupiah(no.nominal)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {metric === 'net_profit' && (
            <div className="space-y-4">
              <div className="p-4 bg-emerald-50/70 border border-emerald-300 rounded-xl space-y-2">
                <div className="font-bold text-emerald-950 text-sm">Rekonsiliasi Laba Bersih Akhir (Bottom Line):</div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div className="bg-white p-3 rounded-lg border border-emerald-100">
                    <span className="text-slate-500 block">Laba Sblm Pajak (EBT)</span>
                    <span className="text-base font-bold text-slate-900 font-mono">{formatRupiah(pnl.ebt)}</span>
                  </div>
                  <div className="bg-white p-3 rounded-lg border border-rose-100">
                    <span className="text-rose-600 block">Pajak Penghasilan ({settings.taxRatePercent}%)</span>
                    <span className="text-base font-bold text-rose-700 font-mono">-{formatRupiah(pnl.taxExpense)}</span>
                  </div>
                  <div className="bg-white p-3 rounded-lg border border-emerald-200 shadow-2xs">
                    <span className="text-emerald-800 font-semibold block">Laba Bersih (Net Profit)</span>
                    <span className="text-base font-bold text-emerald-900 font-mono">{formatRupiah(pnl.netProfit)}</span>
                  </div>
                </div>
              </div>

              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2">
                <div className="font-semibold text-slate-900">Performa Margin Bersih (Net Margin %):</div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-600">Net Profit Margin Realisasi:</span>
                  <span className="font-bold text-emerald-700 font-mono text-sm">{formatPercent(pnl.netProfitMarginPct)}</span>
                </div>
                <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-emerald-600 rounded-full"
                    style={{ width: `${Math.min(100, Math.max(0, pnl.netProfitMarginPct * 4))}%` }}
                  />
                </div>
                <p className="text-[11px] text-slate-500">
                  Target kesehatan bisnis ritel: &gt;5%. Rasio saat ini menunjukkan bahwa operasional Toko Cung berjalan efisien dan menguntungkan.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3.5 sm:p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between gap-3">
          <span className="text-[11px] text-slate-500 hidden sm:inline">
            Menampilkan data buku internal resmi Toko Cung
          </span>
          <div className="flex items-center gap-2 ml-auto">
            {onNavigateModule && (
              <button
                onClick={() => {
                  onClose();
                  if (metric === 'sales') onNavigateModule('sales');
                  else if (metric === 'gross_profit') onNavigateModule('hpp');
                  else if (metric === 'ebitda' || metric === 'opex') onNavigateModule('opex-dashboard');
                  else if (metric === 'ebit') onNavigateModule('asset-register');
                  else onNavigateModule('monthly-pnl');
                }}
                className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white transition-colors cursor-pointer"
              >
                <span>Buka Modul Lengkap</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
            <button
              onClick={onClose}
              className="px-3 py-1.5 rounded-lg text-xs font-medium border border-slate-200 bg-white hover:bg-slate-100 text-slate-700 transition-colors cursor-pointer"
            >
              Tutup
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
