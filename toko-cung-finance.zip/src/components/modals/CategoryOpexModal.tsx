import React, { useMemo } from 'react';
import { useFinance } from '../../context/FinanceContext';
import {
  formatRupiah,
  formatPercent,
  formatDate,
  downloadCSV,
  printReport
} from '../../utils/formatters';
import {
  X,
  Printer,
  FileSpreadsheet,
  Tag,
  Building2,
  Calendar,
  DollarSign
} from 'lucide-react';

interface CategoryOpexModalProps {
  category: string;
  onClose: () => void;
}

export const CategoryOpexModal: React.FC<CategoryOpexModalProps> = ({
  category,
  onClose,
}) => {
  const { opex, entities, globalFilter } = useFinance();

  const categoryOpex = useMemo(() => {
    return opex.filter(o => o.category === category);
  }, [opex, category]);

  const totalSpend = useMemo(() => {
    return categoryOpex.reduce((sum, o) => sum + o.total, 0);
  }, [categoryOpex]);

  const avgMonthlySpend = totalSpend / 12;

  const handleExport = () => {
    const headers = ['No OPEX', 'Tanggal', 'Entitas', 'Vendor', 'Keterangan', 'Nominal', 'Pajak', 'Total'];
    const rows = categoryOpex.map(o => [
      o.opexNumber,
      o.date,
      entities.find(e => e.id === o.entityId)?.name || o.entityId,
      o.vendorName,
      o.description,
      o.nominal,
      o.tax,
      o.total,
    ]);
    downloadCSV(`Rincian_OPEX_${category}`, headers, rows);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 animate-in fade-in">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-3xl w-full max-h-[90vh] flex flex-col text-xs overflow-hidden animate-in zoom-in-95">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 bg-slate-50 flex items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-slate-900 text-white shadow-2xs">
              <Tag className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight">
                  Detail Beban OPEX: {category}
                </h2>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-900">
                  {categoryOpex.length} Transaksi
                </span>
              </div>
              <p className="text-slate-500 text-[11px] mt-0.5">
                Rincian transaksi riil pos pengeluaran {category} konsolidasi seluruh cabang Toko Cung.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={handleExport}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-100 text-slate-700 transition-colors cursor-pointer"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
              <span className="hidden sm:inline">Export</span>
            </button>
            <button
              onClick={printReport}
              className="p-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-100 text-slate-700 transition-colors cursor-pointer"
              title="Cetak"
            >
              <Printer className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-lg border border-slate-200 flex items-center justify-center text-slate-400 hover:text-slate-800 hover:bg-slate-200 transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Top Summary Cards */}
        <div className="p-4 bg-slate-100/70 border-b border-slate-200 grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
            <span className="text-[10px] font-semibold text-slate-500 uppercase block">Total Beban 2026</span>
            <span className="text-base sm:text-lg font-bold text-slate-900 font-mono tabular-nums block mt-0.5">
              {formatRupiah(totalSpend)}
            </span>
          </div>

          <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
            <span className="text-[10px] font-semibold text-slate-500 uppercase block">Rata-rata / Bulan</span>
            <span className="text-base sm:text-lg font-bold text-indigo-700 font-mono tabular-nums block mt-0.5">
              {formatRupiah(avgMonthlySpend)}
            </span>
          </div>

          <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
            <span className="text-[10px] font-semibold text-slate-500 uppercase block">Frekuensi Pencatatan</span>
            <span className="text-base sm:text-lg font-bold text-slate-800 font-mono tabular-nums block mt-0.5">
              {categoryOpex.length} Voucher
            </span>
          </div>
        </div>

        {/* Transactions Table */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5">
          <div className="border border-slate-200 rounded-xl overflow-hidden shadow-2xs">
            <table className="w-full text-left border-collapse text-xs">
              <thead className="bg-slate-100 text-slate-700 sticky top-0 border-b border-slate-200 font-semibold">
                <tr>
                  <th className="py-2.5 px-3">No. OPEX</th>
                  <th className="py-2.5 px-3">Tanggal</th>
                  <th className="py-2.5 px-3">Entitas</th>
                  <th className="py-2.5 px-3">Vendor / Pihak Ketiga</th>
                  <th className="py-2.5 px-3">Keterangan</th>
                  <th className="py-2.5 px-3 text-right">Nominal</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {categoryOpex.map(o => (
                  <tr key={o.id} className="hover:bg-slate-50">
                    <td className="py-2.5 px-3 font-mono font-semibold text-slate-900">{o.opexNumber}</td>
                    <td className="py-2.5 px-3 text-slate-600">{formatDate(o.date)}</td>
                    <td className="py-2.5 px-3 text-slate-700 font-medium">
                      {entities.find(e => e.id === o.entityId)?.code || o.entityId}
                    </td>
                    <td className="py-2.5 px-3 text-slate-800 font-medium">{o.vendorName}</td>
                    <td className="py-2.5 px-3 text-slate-600 max-w-[200px] truncate" title={o.description}>
                      {o.description}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono font-bold tabular-nums text-slate-950">
                      {formatRupiah(o.total)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3.5 sm:p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white transition-colors cursor-pointer"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
