import React from 'react';
import { KasbonDebitur as IDebitur } from '../../types/finance';
import { useFinance } from '../../context/FinanceContext';
import { formatRupiah, formatDate, printReport } from '../../utils/formatters';
import { X, Printer, Users, Phone, ShieldCheck, CheckCircle2, History } from 'lucide-react';

interface DebiturDetailModalProps {
  debitur: IDebitur;
  onClose: () => void;
}

export const DebiturDetailModal: React.FC<DebiturDetailModalProps> = ({ debitur, onClose }) => {
  const { kasbonTransactions } = useFinance();

  const userLoans = (kasbonTransactions || []).filter(k => {
    if (k.debiturId && debitur?.id && k.debiturId === debitur.id) return true;
    const loanName = (k.debiturName || (k as any).employeeName || '').toLowerCase().trim();
    const targetName = (debitur?.employeeName || '').toLowerCase().trim();
    return loanName && targetName && loanName === targetName;
  });

  const ceilingLimit = debitur?.ceilingLimit || 0;
  const currentBalance = debitur?.currentBalance || 0;
  const usagePct = ceilingLimit > 0 ? (currentBalance / ceilingLimit) * 100 : 0;
  const sisaPlafon = Math.max(0, ceilingLimit - currentBalance);

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 animate-in fade-in">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-lg w-full flex flex-col text-xs overflow-hidden animate-in zoom-in-95">
        {/* Header */}
        <div className="p-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-full bg-slate-900 text-white font-bold flex items-center justify-center">
              {debitur.employeeName.charAt(0)}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-base font-bold text-slate-900">{debitur.employeeName}</span>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                  {debitur.status}
                </span>
              </div>
              <div className="text-[11px] text-slate-500">
                Departemen: {debitur.department} · {debitur.phone}
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={printReport}
              className="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-100 text-slate-600 cursor-pointer"
              title="Cetak Kartu Debitur"
            >
              <Printer className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-lg border border-slate-200 flex items-center justify-center text-slate-400 hover:text-slate-800 hover:bg-slate-100 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4 overflow-y-auto max-h-[80vh]">
          {/* Credit balance metrics */}
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3">
              <span className="text-[10px] text-slate-500 font-semibold uppercase block">Plafon Maksimal</span>
              <span className="text-base font-bold text-slate-900 font-mono tabular-nums block mt-0.5">
                {formatRupiah(debitur.ceilingLimit)}
              </span>
              <span className="text-[10px] text-slate-400">Batas pinjaman resmi</span>
            </div>

            <div className="bg-amber-50/60 border border-amber-200 rounded-xl p-3">
              <span className="text-[10px] text-amber-800 font-semibold uppercase block">Saldo Kasbon Aktif</span>
              <span className="text-base font-bold text-amber-900 font-mono tabular-nums block mt-0.5">
                {formatRupiah(debitur.currentBalance)}
              </span>
              <span className="text-[10px] text-amber-700 font-medium">Sisa Plafon: {formatRupiah(sisaPlafon)}</span>
            </div>
          </div>

          {/* Progress bar */}
          <div className="space-y-1">
            <div className="flex justify-between text-[11px] text-slate-600">
              <span>Tingkat Pemakaian Plafon:</span>
              <span className="font-bold tabular-nums">{usagePct.toFixed(1)}%</span>
            </div>
            <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
              <div
                className={`h-full rounded-full ${usagePct > 70 ? 'bg-rose-500' : 'bg-slate-800'}`}
                style={{ width: `${Math.min(100, usagePct)}%` }}
              />
            </div>
          </div>

          {/* Loan history */}
          <div className="border border-slate-200 rounded-xl p-3.5 space-y-2">
            <div className="font-bold text-slate-900 text-xs flex items-center gap-1.5">
              <History className="w-3.5 h-3.5 text-slate-500" />
              <span>Riwayat Pinjaman & Angsuran:</span>
            </div>
            <div className="space-y-2 text-[11px]">
              {userLoans.length > 0 ? (
                userLoans.map(loan => (
                  <div key={loan.id} className="p-2.5 rounded-lg bg-slate-50 border border-slate-100 space-y-1">
                    <div className="flex justify-between font-semibold">
                      <span className="text-slate-800">{loan.purpose}</span>
                      <span className="font-mono text-slate-900">{formatRupiah(loan.amount ?? (loan as any).nominal ?? 0)}</span>
                    </div>
                    <div className="flex justify-between text-[10px] text-slate-500">
                      <span>Tgl: {formatDate(loan.date)}</span>
                      <span className="font-medium text-emerald-700">Dibayar: {formatRupiah(loan.repaidAmount)}</span>
                      <span className="font-bold text-rose-700">Sisa: {formatRupiah(loan.remainingAmount)}</span>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-slate-500 text-center py-3">Tidak ada riwayat pinjaman terbuka.</div>
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-slate-200 bg-slate-50 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white cursor-pointer"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
