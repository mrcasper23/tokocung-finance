import React from 'react';
import { KasbonTransaction } from '../../types/finance';
import { formatRupiah, formatDate, printReport } from '../../utils/formatters';
import { X, Printer, CheckCircle2, Wallet, ArrowDownRight, User } from 'lucide-react';

interface KasbonDetailModalProps {
  transaction: KasbonTransaction;
  onClose: () => void;
  onOpenRepay?: () => void;
}

export const KasbonDetailModal: React.FC<KasbonDetailModalProps> = ({
  transaction,
  onClose,
  onOpenRepay,
}) => {
  const isLunas = transaction.status === 'Lunas';

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 animate-in fade-in">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-lg w-full flex flex-col text-xs overflow-hidden animate-in zoom-in-95">
        {/* Header */}
        <div className="p-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-slate-900 text-white">
              <Wallet className="w-4 h-4" />
            </div>
            <div>
              <span className="font-mono text-base font-bold text-slate-900">{transaction.transactionNumber}</span>
              <div className="text-[11px] text-slate-500">Bukti Pinjaman Kasbon · {formatDate(transaction.date)}</div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={printReport}
              className="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-100 text-slate-600 cursor-pointer"
              title="Cetak Bukti Kasbon"
            >
              <Printer className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-lg border border-slate-200 flex items-center justify-center text-slate-400 hover:text-slate-800 hover:bg-slate-100 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4 overflow-y-auto max-h-[80vh]">
          {/* Main cost banner */}
          <div className="bg-slate-900 text-white p-4 rounded-xl flex items-center justify-between">
            <div>
              <span className="text-[10px] text-slate-400 font-semibold uppercase block">Nominal Pinjaman Pokok</span>
              <span className="text-xl font-bold font-mono text-white tabular-nums">
                {formatRupiah(transaction.amount)}
              </span>
            </div>
            <span className={`px-2.5 py-1 rounded-full text-xs font-bold ${isLunas ? 'bg-emerald-600 text-white' : 'bg-amber-600 text-white'}`}>
              {transaction.status}
            </span>
          </div>

          {/* Debitur profile */}
          <div className="border border-slate-200 rounded-xl p-3.5 space-y-2 bg-slate-50/50">
            <div className="font-bold text-slate-900 text-xs">Penerima Kasbon:</div>
            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <div>
                <span className="text-slate-500 block">Nama Karyawan:</span>
                <span className="font-semibold text-slate-900">{transaction.debiturName}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Keperluan / Alasan:</span>
                <span className="font-medium text-slate-800">{transaction.purpose}</span>
              </div>
            </div>
          </div>

          {/* Repayment Progress */}
          <div className="border border-slate-200 rounded-xl p-3.5 space-y-3">
            <div className="font-bold text-slate-900 text-xs">Status Angsuran & Pelunasan:</div>
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="bg-emerald-50 p-2.5 rounded-lg border border-emerald-200">
                <span className="text-[10px] text-emerald-800 block">Sudah Dilunasi</span>
                <span className="font-bold font-mono text-emerald-900 tabular-nums text-sm">
                  {formatRupiah(transaction.repaidAmount)}
                </span>
              </div>
              <div className="bg-rose-50 p-2.5 rounded-lg border border-rose-200">
                <span className="text-[10px] text-rose-800 block">Sisa Hutang Pokok</span>
                <span className="font-bold font-mono text-rose-900 tabular-nums text-sm">
                  {formatRupiah(transaction.remainingAmount)}
                </span>
              </div>
            </div>

            {/* Repayments log */}
            {transaction.repayments && transaction.repayments.length > 0 && (
              <div className="space-y-1.5 pt-2 border-t border-slate-100">
                <span className="text-[11px] font-semibold text-slate-700 block">Riwayat Setoran Cicilan:</span>
                {transaction.repayments.map((r, i) => (
                  <div key={i} className="flex justify-between items-center text-[11px] py-1 border-b border-slate-50">
                    <span className="text-slate-600">{formatDate(r.date)} ({r.method})</span>
                    <span className="font-mono font-semibold text-emerald-700">+{formatRupiah(r.amount)}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Verification stamp */}
          <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3 flex items-center gap-2.5 text-emerald-900 text-[11px]">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <div>
              <span className="font-semibold">Buku Piutang Terverifikasi:</span> Pelunasan otomatis mengurangi saldo piutang debitur dan menambah kas operasional.
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
          {!isLunas && onOpenRepay && (
            <button
              onClick={() => {
                onClose();
                onOpenRepay();
              }}
              className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs cursor-pointer"
            >
              Bayar Angsuran / Cicil
            </button>
          )}
          <button
            onClick={onClose}
            className="ml-auto px-4 py-1.5 rounded-lg text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white cursor-pointer"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
