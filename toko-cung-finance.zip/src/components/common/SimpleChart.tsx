import React, { useState } from 'react';
import { formatCompactRupiah, formatRupiah } from '../../utils/formatters';

interface BarDataPoint {
  label: string;
  value: number;
  secondaryValue?: number;
  color?: string;
  secondaryColor?: string;
}

interface BarChartProps {
  data: BarDataPoint[];
  title?: string;
  primaryLegend?: string;
  secondaryLegend?: string;
  height?: number;
  formatValue?: (v: number) => string;
  onBarClick?: (item: BarDataPoint, index: number) => void;
}

export const BarChart: React.FC<BarChartProps> = ({
  data,
  title,
  primaryLegend = 'Realisasi',
  secondaryLegend,
  height = 220,
  formatValue = formatCompactRupiah,
  onBarClick,
}) => {
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);

  const maxValue = Math.max(
    1,
    ...data.map(d => Math.max(d.value, d.secondaryValue || 0))
  );

  return (
    <div className="flex flex-col h-full">
      {(title || secondaryLegend) && (
        <div className="flex items-center justify-between mb-3 text-xs">
          {title && <span className="font-semibold text-slate-700">{title}</span>}
          <div className="flex items-center gap-3 ml-auto">
            <span className="flex items-center gap-1.5 text-slate-600">
              <span className="w-2.5 h-2.5 rounded-xs bg-slate-800" />
              <span>{primaryLegend}</span>
            </span>
            {secondaryLegend && (
              <span className="flex items-center gap-1.5 text-slate-600">
                <span className="w-2.5 h-2.5 rounded-xs bg-slate-300" />
                <span>{secondaryLegend}</span>
              </span>
            )}
          </div>
        </div>
      )}

      <div className="relative flex items-end gap-1.5 sm:gap-2.5 pt-6 pb-2" style={{ height: `${height}px` }}>
        {data.map((item, idx) => {
          const primaryHeightPct = Math.max(2, (item.value / maxValue) * 100);
          const secondaryHeightPct = item.secondaryValue
            ? Math.max(2, (item.secondaryValue / maxValue) * 100)
            : 0;

          const isHovered = hoveredIdx === idx;

          return (
            <div
              key={idx}
              className={`flex-1 flex flex-col items-center h-full justify-end group relative cursor-pointer ${
                onBarClick ? 'hover:scale-[1.03] transition-transform' : ''
              }`}
              onMouseEnter={() => setHoveredIdx(idx)}
              onMouseLeave={() => setHoveredIdx(null)}
              onClick={() => onBarClick && onBarClick(item, idx)}
              title={onBarClick ? `Klik untuk detail ${item.label}` : undefined}
            >
              {/* Tooltip */}
              {isHovered && (
                <div className="absolute -top-14 z-20 bg-slate-900 text-white text-[11px] px-2.5 py-1.5 rounded-lg shadow-lg pointer-events-none whitespace-nowrap tabular-nums text-center">
                  <div className="font-bold flex items-center justify-center gap-1">
                    <span>{item.label}</span>
                    {onBarClick && <span className="text-[9px] text-blue-300 font-normal">(Klik detail)</span>}
                  </div>
                  <div>{primaryLegend}: {formatRupiah(item.value)}</div>
                  {item.secondaryValue !== undefined && (
                    <div className="text-slate-300">{secondaryLegend}: {formatRupiah(item.secondaryValue)}</div>
                  )}
                </div>
              )}

              <div className="w-full flex items-end justify-center gap-1 h-full pb-1">
                {/* Secondary bar (e.g. Budget or PY) */}
                {item.secondaryValue !== undefined && (
                  <div
                    className="w-1/2 rounded-t-xs bg-slate-300 transition-all duration-300 group-hover:opacity-80"
                    style={{ height: `${secondaryHeightPct}%` }}
                  />
                )}
                {/* Primary bar */}
                <div
                  className={`rounded-t-xs transition-all duration-300 ${
                    item.color || 'bg-slate-800'
                  } group-hover:bg-blue-600 group-hover:shadow-sm ${item.secondaryValue !== undefined ? 'w-1/2' : 'w-full max-w-[28px]'}`}
                  style={{ height: `${primaryHeightPct}%` }}
                />
              </div>

              <span className="text-[10px] sm:text-[11px] text-slate-500 font-medium truncate w-full text-center mt-1 group-hover:text-blue-700 group-hover:font-bold">
                {item.label}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};

interface LinePoint {
  label: string;
  v1: number; // Revenue
  v2?: number; // Gross Profit
  v3?: number; // EBITDA
  v4?: number; // Net Profit
}

interface MultiLineChartProps {
  data: LinePoint[];
  labels: { key: 'v1' | 'v2' | 'v3' | 'v4'; name: string; color: string }[];
  height?: number;
}

export const MultiLineChart: React.FC<MultiLineChartProps> = ({
  data,
  labels,
  height = 240,
}) => {
  const [activeIdx, setActiveIdx] = useState<number | null>(null);

  if (!data || data.length === 0) return null;

  const allValues = data.flatMap(d => [d.v1, d.v2 ?? 0, d.v3 ?? 0, d.v4 ?? 0]);
  const maxVal = Math.max(1, ...allValues);
  const minVal = Math.min(0, ...allValues);
  const range = maxVal - minVal || 1;

  const width = 600;
  const chartHeight = height - 40;
  const paddingX = 35;
  const paddingY = 15;
  const usableWidth = width - paddingX * 2;
  const usableHeight = chartHeight - paddingY * 2;

  const getCoordinates = (val: number, idx: number) => {
    const x = paddingX + (idx / (data.length - 1)) * usableWidth;
    const y = chartHeight - paddingY - ((val - minVal) / range) * usableHeight;
    return { x, y };
  };

  const getSvgPath = (key: 'v1' | 'v2' | 'v3' | 'v4') => {
    return data
      .map((d, i) => {
        const val = d[key] ?? 0;
        const { x, y } = getCoordinates(val, i);
        return `${i === 0 ? 'M' : 'L'} ${x} ${y}`;
      })
      .join(' ');
  };

  return (
    <div className="flex flex-col">
      <div className="flex flex-wrap items-center justify-end gap-3 text-xs mb-2">
        {labels.map(l => (
          <span key={l.key} className="flex items-center gap-1.5 text-slate-600">
            <span className="w-3 h-0.5" style={{ backgroundColor: l.color }} />
            <span>{l.name}</span>
          </span>
        ))}
      </div>

      <div className="relative" style={{ height: `${height}px` }}>
        <svg viewBox={`0 0 ${width} ${chartHeight}`} className="w-full h-full overflow-visible">
          {/* Subtle grid lines */}
          <line x1={paddingX} y1={paddingY} x2={width - paddingX} y2={paddingY} stroke="#E2E8F0" strokeDasharray="3 3" />
          <line x1={paddingX} y1={chartHeight / 2} x2={width - paddingX} y2={chartHeight / 2} stroke="#E2E8F0" strokeDasharray="3 3" />
          <line x1={paddingX} y1={chartHeight - paddingY} x2={width - paddingX} y2={chartHeight - paddingY} stroke="#E2E8F0" />

          {/* Paths */}
          {labels.map(l => (
            <path
              key={l.key}
              d={getSvgPath(l.key)}
              fill="none"
              stroke={l.color}
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          ))}

          {/* Interactive hover points */}
          {data.map((d, i) => {
            const { x } = getCoordinates(d.v1, i);
            const isHovered = activeIdx === i;

            return (
              <g key={i} className="cursor-pointer" onMouseEnter={() => setActiveIdx(i)} onMouseLeave={() => setActiveIdx(null)}>
                <line
                  x1={x}
                  y1={paddingY}
                  x2={x}
                  y2={chartHeight - paddingY}
                  stroke={isHovered ? '#64748B' : 'transparent'}
                  strokeDasharray="2 2"
                  strokeWidth="1"
                />
                {labels.map(l => {
                  const val = d[l.key] ?? 0;
                  const coords = getCoordinates(val, i);
                  return (
                    <circle
                      key={l.key}
                      cx={coords.x}
                      cy={coords.y}
                      r={isHovered ? 4.5 : 2.5}
                      fill="#FFFFFF"
                      stroke={l.color}
                      strokeWidth="2"
                    />
                  );
                })}
              </g>
            );
          })}
        </svg>

        {/* Floating Tooltip */}
        {activeIdx !== null && (
          <div
            className="absolute top-0 bg-slate-900/95 backdrop-blur-xs text-white p-2.5 rounded-lg shadow-lg text-[11px] z-20 pointer-events-none tabular-nums"
            style={{
              left: `${Math.min(80, Math.max(10, (activeIdx / (data.length - 1)) * 100))}%`,
              transform: 'translateX(-50%)',
            }}
          >
            <div className="font-semibold text-slate-200 border-b border-slate-700 pb-1 mb-1.5">
              Bulan {data[activeIdx].label}
            </div>
            {labels.map(l => {
              const val = data[activeIdx][l.key] ?? 0;
              return (
                <div key={l.key} className="flex items-center justify-between gap-4 py-0.5">
                  <span className="flex items-center gap-1.5 text-slate-300">
                    <span className="w-2 h-2 rounded-full" style={{ backgroundColor: l.color }} />
                    {l.name}:
                  </span>
                  <span className="font-semibold">{formatRupiah(val)}</span>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* X Labels */}
      <div className="flex justify-between px-3 text-[11px] text-slate-500 font-medium pt-1">
        {data.map((d, i) => (
          <span key={i} className="truncate">{d.label}</span>
        ))}
      </div>
    </div>
  );
};

interface DonutSlice {
  label: string;
  value: number;
  color: string;
}

export const DonutChart: React.FC<{
  data: DonutSlice[];
  title?: string;
  onSliceClick?: (slice: DonutSlice, index: number) => void;
}> = ({ data, title, onSliceClick }) => {
  const total = data.reduce((sum, d) => sum + d.value, 0);
  let accumulatedAngle = 0;

  return (
    <div className="flex flex-col h-full">
      {title && <span className="text-xs font-semibold text-slate-700 mb-3">{title}</span>}
      <div className="flex flex-col sm:flex-row items-center justify-center gap-4 my-auto">
        <div className="relative w-36 h-36">
          <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
            {data.map((slice, i) => {
              const slicePercentage = total > 0 ? slice.value / total : 0;
              const strokeDasharray = `${slicePercentage * 282.7} 282.7`;
              const strokeDashoffset = -accumulatedAngle * 282.7;
              accumulatedAngle += slicePercentage;

              return (
                <circle
                  key={i}
                  cx="50"
                  cy="50"
                  r="45"
                  fill="transparent"
                  stroke={slice.color}
                  strokeWidth="10"
                  strokeDasharray={strokeDasharray}
                  strokeDashoffset={strokeDashoffset}
                  onClick={() => onSliceClick && onSliceClick(slice, i)}
                  className={`transition-all duration-300 hover:opacity-90 cursor-pointer ${
                    onSliceClick ? 'hover:stroke-[12px]' : ''
                  }`}
                />
              );
            })}
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
            <span className="text-[10px] text-slate-400 font-medium">TOTAL</span>
            <span className="text-xs font-bold text-slate-800 tabular-nums">
              {formatCompactRupiah(total)}
            </span>
          </div>
        </div>

        <div className="flex flex-col gap-1.5 text-xs w-full max-w-[200px]">
          {data.map((slice, i) => {
            const pct = total > 0 ? (slice.value / total) * 100 : 0;
            return (
              <div
                key={i}
                onClick={() => onSliceClick && onSliceClick(slice, i)}
                className={`flex items-center justify-between text-[11px] p-1 rounded-md transition-colors ${
                  onSliceClick ? 'hover:bg-slate-100 cursor-pointer group' : ''
                }`}
              >
                <div className="flex items-center gap-2 truncate pr-2">
                  <span className="w-2.5 h-2.5 rounded-full shrink-0 group-hover:scale-110 transition-transform" style={{ backgroundColor: slice.color }} />
                  <span className="text-slate-600 group-hover:text-slate-900 group-hover:font-medium truncate">{slice.label}</span>
                </div>
                <span className="font-semibold text-slate-800 tabular-nums shrink-0">
                  {pct.toFixed(1)}%
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
