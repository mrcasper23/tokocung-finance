import React from 'react';
import { ArrowUpRight, ArrowDownRight, Minus } from 'lucide-react';

interface StatCardProps {
  title: string;
  value: string;
  subtitle?: string;
  change?: number; // e.g. +12.4%
  changeLabel?: string;
  isPositiveGood?: boolean; // default true
  indicatorText?: string;
  icon?: React.ReactNode;
  onClick?: () => void;
  clickableHint?: string;
}

export const StatCard: React.FC<StatCardProps> = ({
  title,
  value,
  subtitle,
  change,
  changeLabel = 'vs bln sebelumnya',
  isPositiveGood = true,
  indicatorText,
  icon,
  onClick,
  clickableHint = 'Klik untuk detail',
}) => {
  const hasChange = change !== undefined && !isNaN(change);
  const isUp = hasChange && change > 0;
  const isDown = hasChange && change < 0;
  const isNeutral = hasChange && Math.abs(change) < 0.1;

  let trendColor = 'text-slate-500';
  if (hasChange && !isNeutral) {
    if (isUp) {
      trendColor = isPositiveGood ? 'text-emerald-600' : 'text-rose-600';
    } else {
      trendColor = isPositiveGood ? 'text-rose-600' : 'text-emerald-600';
    }
  }

  return (
    <div
      onClick={onClick}
      role={onClick ? 'button' : undefined}
      tabIndex={onClick ? 0 : undefined}
      onKeyDown={onClick ? (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onClick(); } } : undefined}
      className={`bg-white border border-slate-200/90 rounded-xl p-4 sm:p-5 shadow-xs flex flex-col justify-between transition-all ${
        onClick
          ? 'cursor-pointer hover:border-blue-400 hover:shadow-md hover:-translate-y-0.5 active:translate-y-0 group relative overflow-hidden'
          : 'hover:border-slate-300'
      }`}
    >
      {onClick && (
        <div className="absolute top-0 right-0 w-12 h-12 overflow-hidden pointer-events-none">
          <div className="absolute transform rotate-45 bg-blue-600 text-white text-[9px] font-bold py-0.5 right-[-28px] top-[10px] w-24 text-center opacity-0 group-hover:opacity-100 transition-opacity shadow-xs">
            DETAIL
          </div>
        </div>
      )}

      <div className="flex items-center justify-between gap-2 mb-2">
        <span className="text-xs font-semibold tracking-wider text-slate-500 uppercase flex items-center gap-1.5">
          {title}
          {onClick && (
            <span className="inline-block text-[10px] text-blue-600 font-normal opacity-0 group-hover:opacity-100 transition-opacity">
              (lihat rincian)
            </span>
          )}
        </span>
        {icon && <div className={`p-1.5 rounded-lg transition-colors ${onClick ? 'bg-slate-50 text-slate-500 group-hover:bg-blue-50 group-hover:text-blue-600' : 'bg-slate-50 text-slate-400'}`}>{icon}</div>}
      </div>

      <div className="my-1">
        <div className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900 tabular-nums group-hover:text-blue-900 transition-colors">
          {value}
        </div>
        {subtitle && (
          <div className="text-xs text-slate-500 mt-0.5">{subtitle}</div>
        )}
      </div>

      <div className="mt-2.5 pt-2.5 border-t border-slate-100 flex items-center justify-between text-xs">
        {hasChange ? (
          <div className={`flex items-center gap-1 font-medium ${trendColor}`}>
            {isUp && <ArrowUpRight className="w-3.5 h-3.5 shrink-0" />}
            {isDown && <ArrowDownRight className="w-3.5 h-3.5 shrink-0" />}
            {isNeutral && <Minus className="w-3.5 h-3.5 shrink-0" />}
            <span>{isUp ? `+${change.toFixed(1)}%` : `${change.toFixed(1)}%`}</span>
            <span className="text-slate-400 font-normal ml-0.5">{changeLabel}</span>
          </div>
        ) : indicatorText ? (
          <span className="text-slate-600">{indicatorText}</span>
        ) : (
          <span className="text-slate-400">Data Terkini</span>
        )}

        {onClick && (
          <span className="text-[11px] font-medium text-blue-600 opacity-80 group-hover:opacity-100 group-hover:translate-x-0.5 transition-all flex items-center gap-0.5">
            Detail →
          </span>
        )}
      </div>
    </div>
  );
};
