import React, { useState } from 'react';
import { useFinance } from '../../context/FinanceContext';
import { formatRupiah, formatDate, printReport } from '../../utils/formatters';
import { CapexRequest, CapexStatus } from '../../types/finance';
import { Plus, CheckCircle2, ShieldCheck, HardDrive, ArrowRight, DollarSign, Eye, Printer, Calendar, Building, Clock } from 'lucide-react';

export const CapexPaymentRequests: React.FC = () => {
  const { capexRequests, createCapexRequest, updateCapexStatus, currentUser, vendors } = useFinance();
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedCapex, setSelectedCapex] = useState<CapexRequest | null>(null);

  // Form state
  const [requestor, setRequestor] = useState(currentUser.name);
  const [project, setProject] = useState('Renovasi & Fasilitas Baru');
  const [description, setDescription] = useState('');
  const [vendorName, setVendorName] = useState(vendors[0]?.name || 'PT Vendor Sarana');
  const [assetType, setAssetType] = useState('Peralatan & Mesin Toko');
  const [acquisitionDate, setAcquisitionDate] = useState('2026-04-10');
  const [acquisitionCost, setAcquisitionCost] = useState(50000000);
  const [expectedUsefulLifeMonths, setExpectedUsefulLifeMonths] = useState(48);
  const [residualValue, setResidualValue] = useState(5000000);

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    createCapexRequest({
      requestor,
      project,
      description,
      vendorName,
      assetType,
      acquisitionDate,
      acquisitionCost,
      expectedUsefulLifeMonths,
      residualValue,
      depreciationMethod: 'Straight Line',
      status: 'Reviewed',
    });

    setShowAddModal(false);
    setDescription('');
  };

  const getStatusBadge = (status: CapexStatus) => {
    switch (status) {
      case 'Draft':
        return <span className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded text-[11px] font-medium">Draft</span>;
      case 'Reviewed':
        return <span className="bg-blue-50 text-blue-700 px-2 py-0.5 rounded text-[11px] font-medium">Review Finance</span>;
      case 'Approved':
        return <span className="bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded text-[11px] font-semibold">Disetujui Direktur</span>;
      case 'Paid':
        return <span className="bg-amber-50 text-amber-800 px-2 py-0.5 rounded text-[11px] font-bold">Dibayar (Paid)</span>;
      case 'Asset Created':
        return <span className="bg-purple-100 text-purple-900 px-2 py-0.5 rounded text-[11px] font-bold flex items-center gap-1">
          <HardDrive className="w-3 h-3" /> Aset Terdaftar & Aktif
        </span>;
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="bg-white border border-slate-200/90 rounded-xl p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">CAPEX Payment Request (Belanja Modal)</h1>
          <p className="text-xs text-slate-500 mt-1">
            Pengajuan belanja aktiva tetap: Forklift, Mesin Kasir, Renovasi Bangunan, Kendaraan Operasional.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white transition-colors cursor-pointer shadow-2xs shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>+ Buat CAPEX Request</span>
        </button>
      </div>

      {/* Accounting Rule Callout */}
      <div className="bg-amber-50/80 border border-amber-200 rounded-xl p-4 text-xs text-amber-950 flex items-start gap-3">
        <ShieldCheck className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
        <div className="leading-relaxed">
          <div className="font-semibold text-amber-900">Aturan Akuntansi Wajib (CAPEX Flow):</div>
          <div className="mt-0.5 text-amber-900">
            CAPEX tidak langsung memotong Net Profit! Ketika CAPEX disetujui & dibayar, sistem secara otomatis mendaftarkannya ke <span className="font-semibold underline">Asset Register</span>. Nilai perolehan disusutkan per bulan (<span className="font-semibold">Straight Line Method</span>) dan beban susut tersebut yang masuk ke P&L sebagai <span className="font-semibold">Depresiasi</span>. Pada Arus Kas, belanja CAPEX menjadi pengeluaran investasi (<span className="font-semibold">Investing Cash Outflow</span>).
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                <th className="py-3 px-3">No. CAPEX</th>
                <th className="py-3 px-3">Proyek & Aset</th>
                <th className="py-3 px-3">Vendor Rekanan</th>
                <th className="py-3 px-3">Tgl Perolehan</th>
                <th className="py-3 px-3 text-right">Nilai Perolehan</th>
                <th className="py-3 px-3 text-right">Masa Manfaat</th>
                <th className="py-3 px-3 text-right">Estimasi Depr/Bln</th>
                <th className="py-3 px-3 text-center">Status</th>
                <th className="py-3 px-3 text-right">Aksi Alur Kerja</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {capexRequests.map(cpx => {
                const estMonthlyDepr = Math.round(
                  (cpx.acquisitionCost - cpx.residualValue) / Math.max(1, cpx.expectedUsefulLifeMonths)
                );

                return (
                  <tr
                    key={cpx.id}
                    onClick={() => setSelectedCapex(cpx)}
                    className="hover:bg-slate-50/90 transition-colors cursor-pointer group"
                  >
                    <td className="py-3 px-3 font-semibold text-slate-900 font-mono">
                      <div className="flex items-center gap-1.5 group-hover:text-blue-700">
                        <span>{cpx.capexNumber}</span>
                        <Eye className="w-3.5 h-3.5 text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                      </div>
                    </td>
                    <td className="py-3 px-3">
                      <div className="font-semibold text-slate-900">{cpx.project}</div>
                      <div className="text-[11px] text-slate-600">{cpx.description}</div>
                      <div className="text-[10px] text-slate-400">Tipe: {cpx.assetType}</div>
                    </td>
                    <td className="py-3 px-3 font-medium text-slate-700">{cpx.vendorName}</td>
                    <td className="py-3 px-3 text-slate-600">{formatDate(cpx.acquisitionDate)}</td>
                    <td className="py-3 px-3 text-right font-mono font-bold text-slate-900">
                      {formatRupiah(cpx.acquisitionCost)}
                    </td>
                    <td className="py-3 px-3 text-right font-mono text-slate-600">
                      {cpx.expectedUsefulLifeMonths} bln ({Math.round(cpx.expectedUsefulLifeMonths / 12)} thn)
                    </td>
                    <td className="py-3 px-3 text-right font-mono font-semibold text-indigo-700">
                      {formatRupiah(estMonthlyDepr)}/bln
                    </td>
                    <td className="py-3 px-3 text-center">
                      {getStatusBadge(cpx.status)}
                    </td>
                    <td className="py-3 px-3 text-right" onClick={e => e.stopPropagation()}>
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => setSelectedCapex(cpx)}
                          className="px-2 py-1 rounded bg-slate-100 text-slate-700 hover:bg-slate-200 font-medium text-[11px] cursor-pointer"
                        >
                          Detail
                        </button>
                        {cpx.status === 'Reviewed' && (
                          <button
                            onClick={() => updateCapexStatus(cpx.id, 'Approved')}
                            className="px-2 py-1 rounded bg-emerald-600 text-white font-semibold hover:bg-emerald-700 text-[11px] cursor-pointer"
                          >
                            Setujui Direktur
                          </button>
                        )}
                        {cpx.status === 'Approved' && (
                          <button
                            onClick={() => updateCapexStatus(cpx.id, 'Paid')}
                            className="px-2 py-1 rounded bg-amber-500 text-slate-950 font-bold hover:bg-amber-400 text-[11px] cursor-pointer"
                          >
                            Bayar (Paid)
                          </button>
                        )}
                        {cpx.status === 'Paid' && (
                          <button
                            onClick={() => updateCapexStatus(cpx.id, 'Asset Created')}
                            className="px-2 py-1 rounded bg-purple-700 text-white font-bold hover:bg-purple-800 text-[11px] flex items-center gap-1 cursor-pointer"
                          >
                            <HardDrive className="w-3 h-3" /> Buat Aset
                          </button>
                        )}
                        {cpx.status === 'Asset Created' && (
                          <span className="text-emerald-700 font-medium text-[11px] flex items-center gap-1">
                            <CheckCircle2 className="w-3.5 h-3.5" /> Terdaftar Aktif
                          </span>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* CAPEX DETAIL MODAL */}
      {selectedCapex && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 animate-in fade-in">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-lg w-full flex flex-col text-xs overflow-hidden animate-in zoom-in-95">
            {/* Header */}
            <div className="p-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
              <div>
                <span className="font-mono text-base font-bold text-slate-900">{selectedCapex.capexNumber}</span>
                <div className="text-[11px] text-slate-500">Proposal Belanja Modal (CAPEX) · {selectedCapex.project}</div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={printReport}
                  className="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-100 text-slate-600"
                  title="Cetak Proposal"
                >
                  <Printer className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setSelectedCapex(null)}
                  className="w-8 h-8 rounded-lg border border-slate-200 flex items-center justify-center text-slate-400 hover:text-slate-800 hover:bg-slate-100"
                >
                  ✕
                </button>
              </div>
            </div>

            {/* Content */}
            <div className="p-5 space-y-4">
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
                <div className="text-[10px] uppercase font-bold text-slate-400">Deskripsi Pengadaan Aset</div>
                <div className="text-slate-900 font-semibold text-sm">{selectedCapex.description}</div>
                <div className="text-[11px] text-slate-500">Klasifikasi: {selectedCapex.assetType} · Vendor: {selectedCapex.vendorName}</div>
              </div>

              {/* Financial & Depreciation Matrix */}
              <div className="border border-slate-200 rounded-xl p-3.5 bg-slate-50/70 space-y-2">
                <div className="flex justify-between text-slate-700">
                  <span>Nilai Perolehan Aset (Acquisition Cost):</span>
                  <span className="font-mono font-bold text-slate-950">{formatRupiah(selectedCapex.acquisitionCost)}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Masa Manfaat Ekonomis:</span>
                  <span className="font-mono">{selectedCapex.expectedUsefulLifeMonths} Bulan ({Math.round(selectedCapex.expectedUsefulLifeMonths / 12)} Tahun)</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Estimasi Nilai Residu:</span>
                  <span className="font-mono">{formatRupiah(selectedCapex.residualValue)}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Metode Penyusutan:</span>
                  <span className="font-semibold text-slate-800">Straight Line (Garis Lurus)</span>
                </div>
                <div className="pt-2 border-t border-slate-200 flex justify-between font-bold text-sm">
                  <span className="text-indigo-950">Beban Depresiasi Bulanan (ke P&L):</span>
                  <span className="font-mono text-indigo-700">
                    {formatRupiah(Math.round((selectedCapex.acquisitionCost - selectedCapex.residualValue) / Math.max(1, selectedCapex.expectedUsefulLifeMonths)))} / bln
                  </span>
                </div>
              </div>

              <div className="p-3 bg-amber-50 border border-amber-200/70 rounded-xl text-amber-950 space-y-1 text-[11px]">
                <div className="font-bold flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-amber-600" />
                  <span>Dampak Finansial Akuntansi Toko Cung</span>
                </div>
                <p className="leading-relaxed text-amber-900">
                  Saat berstatus <strong>Asset Created</strong>, aset otomatis masuk ke Asset Register. Nilai Rp {selectedCapex.acquisitionCost.toLocaleString('id-ID')} masuk sebagai arus kas keluar investasi (Investing Cash Flow), bukan beban langsung di Net Profit.
                </p>
              </div>
            </div>

            <div className="p-3.5 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
              <div>
                {getStatusBadge(selectedCapex.status)}
              </div>
              <div className="flex items-center gap-2">
                {selectedCapex.status === 'Reviewed' && (
                  <button
                    onClick={() => {
                      updateCapexStatus(selectedCapex.id, 'Approved');
                      setSelectedCapex({ ...selectedCapex, status: 'Approved' });
                    }}
                    className="px-3 py-1.5 rounded-lg bg-emerald-600 text-white font-semibold hover:bg-emerald-700"
                  >
                    Setujui Direktur
                  </button>
                )}
                {selectedCapex.status === 'Approved' && (
                  <button
                    onClick={() => {
                      updateCapexStatus(selectedCapex.id, 'Paid');
                      setSelectedCapex({ ...selectedCapex, status: 'Paid' });
                    }}
                    className="px-3 py-1.5 rounded-lg bg-amber-500 text-slate-950 font-bold hover:bg-amber-400"
                  >
                    Bayar (Paid)
                  </button>
                )}
                {selectedCapex.status === 'Paid' && (
                  <button
                    onClick={() => {
                      updateCapexStatus(selectedCapex.id, 'Asset Created');
                      setSelectedCapex({ ...selectedCapex, status: 'Asset Created' });
                    }}
                    className="px-3 py-1.5 rounded-lg bg-purple-700 text-white font-bold hover:bg-purple-800"
                  >
                    Buat Aset Aktif
                  </button>
                )}
                <button
                  onClick={() => setSelectedCapex(null)}
                  className="px-4 py-1.5 rounded-lg bg-slate-900 text-white font-semibold hover:bg-slate-800"
                >
                  Tutup
                </button>
              </div>
            </div>
          </div>
        </div>
      )}


      {/* Modal Add CAPEX */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-lg w-full p-6 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h3 className="text-sm font-bold text-slate-900">Pengajuan Belanja Modal (CAPEX) Baru</h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-600">✕</button>
            </div>

            <form onSubmit={handleCreate} className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Nama Proyek</label>
                  <input
                    type="text"
                    required
                    value={project}
                    onChange={e => setProject(e.target.value)}
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                    placeholder="Contoh: Modernisasi POS Toko"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Klasifikasi Aset</label>
                  <select
                    value={assetType}
                    onChange={e => setAssetType(e.target.value)}
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                  >
                    <option value="Peralatan Elektronik Kasir">Peralatan Elektronik Kasir</option>
                    <option value="Kendaraan & Alat Berat">Kendaraan & Alat Berat</option>
                    <option value="Gedung & Bangunan">Gedung & Bangunan</option>
                    <option value="Peralatan & Inventaris Toko">Peralatan & Inventaris Toko</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-600 font-medium mb-1">Deskripsi & Spesifikasi Aset</label>
                <input
                  type="text"
                  required
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                  placeholder="Spesifikasi barang modal yang dibeli..."
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Vendor / Rekanan</label>
                  <input
                    type="text"
                    required
                    value={vendorName}
                    onChange={e => setVendorName(e.target.value)}
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Tanggal Perolehan</label>
                  <input
                    type="date"
                    required
                    value={acquisitionDate}
                    onChange={e => setAcquisitionDate(e.target.value)}
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Nilai Perolehan (Rp)</label>
                  <input
                    type="number"
                    step={1000000}
                    required
                    value={acquisitionCost}
                    onChange={e => setAcquisitionCost(Number(e.target.value))}
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Masa Manfaat (Bulan)</label>
                  <input
                    type="number"
                    min={6}
                    required
                    value={expectedUsefulLifeMonths}
                    onChange={e => setExpectedUsefulLifeMonths(Number(e.target.value))}
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Nilai Residu (Rp)</label>
                  <input
                    type="number"
                    step={500000}
                    value={residualValue}
                    onChange={e => setResidualValue(Number(e.target.value))}
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs font-mono"
                  />
                </div>
              </div>

              {/* Depreciation Preview */}
              <div className="p-3 bg-indigo-50/70 border border-indigo-200 rounded-lg flex justify-between items-center text-xs text-indigo-950 font-medium">
                <span>Simulasi Beban Susut Garis Lurus:</span>
                <span className="font-bold font-mono">
                  {formatRupiah(Math.round((acquisitionCost - residualValue) / Math.max(1, expectedUsefulLifeMonths)))} / Bulan
                </span>
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-600"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-semibold"
                >
                  Ajukan CAPEX
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
