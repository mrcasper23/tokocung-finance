import React from 'react';
import { useFinance } from '../../context/FinanceContext';
import { formatRupiah, formatCompactRupiah, formatDate, downloadCSV, printReport } from '../../utils/formatters';
import { FileSpreadsheet, Printer, ShieldCheck, CheckCircle2 } from 'lucide-react';

export const CapexReport: React.FC = () => {
  const { capexRequests, assets, globalFilter } = useFinance();

  const totalCapexSubmitted = capexRequests.reduce((sum, c) => sum + c.acquisitionCost, 0);
  const totalAssetsCap = assets.reduce((sum, a) => sum + a.acquisitionCost, 0);
  const totalBookVal = assets.reduce((sum, a) => sum + a.bookValue, 0);
  const totalDeprYtd = assets.reduce((sum, a) => sum + a.accumulatedDepreciation, 0);

  const handleExport = () => {
    const headers = ['No CAPEX', 'Proyek', 'Aset', 'Vendor', 'Tgl Perolehan', 'Nilai Belanja', 'Masa Manfaat', 'Status'];
    const rows = capexRequests.map(c => [
      c.capexNumber,
      c.project,
      c.description,
      c.vendorName,
      c.acquisitionDate,
      c.acquisitionCost,
      `${c.expectedUsefulLifeMonths} Bulan`,
      c.status
    ]);
    downloadCSV(`Laporan_Audit_CAPEX_${globalFilter.year}`, headers, rows);
  };

  return (
    <div className="space-y-6 pb-12 print-full-width">
      <div className="bg-white border border-slate-200/90 rounded-xl p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">CAPEX Audit & Execution Report</h1>
          <p className="text-xs text-slate-500 mt-1">
            Laporan pertanggungjawaban realisasi belanja modal, mutasi aktiva tetap, dan jadwal penyusutan.
          </p>
        </div>

        <div className="flex items-center gap-2 no-print">
          <button
            onClick={handleExport}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white transition-colors cursor-pointer shadow-2xs"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={printReport}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Cetak PDF</span>
          </button>
        </div>
      </div>

      {/* Summary Matrix */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 text-xs">
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <span className="text-slate-500 font-medium block">Total CAPEX Disetujui</span>
          <span className="text-lg font-bold text-slate-900 font-mono tabular-nums">{formatRupiah(totalCapexSubmitted)}</span>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <span className="text-slate-500 font-medium block">Aset Dikapitalisasi</span>
          <span className="text-lg font-bold text-slate-900 font-mono tabular-nums">{formatRupiah(totalAssetsCap)}</span>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <span className="text-slate-500 font-medium block">Akumulasi Beban Susut</span>
          <span className="text-lg font-bold text-rose-600 font-mono tabular-nums">-{formatRupiah(totalDeprYtd)}</span>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <span className="text-slate-500 font-medium block">Nilai Buku Bersih (NBV)</span>
          <span className="text-lg font-bold text-emerald-700 font-mono tabular-nums">{formatRupiah(totalBookVal)}</span>
        </div>
      </div>

      {/* Audit Checklist Table */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
          <h2 className="text-sm font-bold text-slate-900">Daftar Audit Realisasi CAPEX & Aset</h2>
          <span className="text-xs text-slate-500">Tahun Buku {globalFilter.year}</span>
        </div>

        <div className="overflow-x-auto text-xs">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                <th className="py-2.5 px-3">No. CAPEX</th>
                <th className="py-2.5 px-3">Proyek & Spesifikasi</th>
                <th className="py-2.5 px-3">Vendor Rekanan</th>
                <th className="py-2.5 px-3">Tgl Perolehan</th>
                <th className="py-2.5 px-3 text-right">Nilai Belanja Modal</th>
                <th className="py-2.5 px-3 text-center">Status Alur</th>
                <th className="py-2.5 px-3 text-center">Registrasi Aset</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {capexRequests.map(c => (
                <tr key={c.id} className="hover:bg-slate-50">
                  <td className="py-2.5 px-3 font-semibold text-slate-900 font-mono">{c.capexNumber}</td>
                  <td className="py-2.5 px-3">
                    <div className="font-semibold text-slate-800">{c.project}</div>
                    <div className="text-[11px] text-slate-500">{c.description}</div>
                  </td>
                  <td className="py-2.5 px-3 text-slate-700">{c.vendorName}</td>
                  <td className="py-2.5 px-3 text-slate-600">{formatDate(c.acquisitionDate)}</td>
                  <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-900">{formatRupiah(c.acquisitionCost)}</td>
                  <td className="py-2.5 px-3 text-center">
                    <span className="px-2 py-0.5 rounded text-[11px] bg-slate-100 text-slate-700 font-medium">
                      {c.status}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-center">
                    {c.status === 'Asset Created' ? (
                      <span className="text-emerald-700 font-semibold text-[11px] inline-flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Terkapitalisasi
                      </span>
                    ) : (
                      <span className="text-slate-400 text-[11px]">Dalam Proses</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
