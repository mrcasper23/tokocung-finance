import React, { useState } from 'react';
import { useFinance } from '../../context/FinanceContext';
import { formatRupiah, formatDate, downloadCSV, printReport } from '../../utils/formatters';
import { OpexCategoryName, OpexTransaction } from '../../types/finance';
import { Plus, Search, Filter, FileSpreadsheet, Tag, Building2, Calendar, Eye, Printer, CheckCircle2, ShieldCheck } from 'lucide-react';

const OPEX_CATEGORIES: OpexCategoryName[] = [
  'ATK',
  'Advertisement',
  'Gaji',
  'Utilities',
  'Insurance',
  'Internet',
  'Maintenance',
  'Transportation',
  'Tunjangan',
  'Administrasi',
  'Professional Fee',
  'Server',
  'Logistik',
  'Other Operating Expenses',
];

export const OpexDashboard: React.FC = () => {
  const { opex, addOpex, entities, vendors, currentUser } = useFinance();
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('ALL');
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedOpex, setSelectedOpex] = useState<OpexTransaction | null>(null);

  // Form state
  const [entityId, setEntityId] = useState(entities[0]?.id || 'cung-retail');
  const [vendorName, setVendorName] = useState(vendors[0]?.name || 'PT Rekanan');
  const [category, setCategory] = useState<OpexCategoryName>('Utilities');
  const [description, setDescription] = useState('');
  const [nominal, setNominal] = useState(2500000);
  const [tax, setTax] = useState(0);
  const [date, setDate] = useState('2026-03-20');

  const filtered = opex.filter(item => {
    const matchSearch =
      item.opexNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.vendorName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchCat = categoryFilter === 'ALL' || item.category === categoryFilter;
    return matchSearch && matchCat;
  });

  const totalFiltered = filtered.reduce((sum, item) => sum + item.total, 0);

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    const total = nominal + tax;

    addOpex({
      date,
      entityId,
      vendorName,
      category,
      description,
      nominal,
      tax,
      total,
      status: 'Dibayar',
      approver: currentUser.name,
      paymentDate: date,
    });

    setShowAddModal(false);
    setDescription('');
  };

  const handleExport = () => {
    const headers = ['No. OPEX', 'Tanggal', 'Entitas', 'Kategori', 'Vendor', 'Deskripsi', 'Nominal', 'Pajak', 'Total', 'Status'];
    const rows = filtered.map(o => [
      o.opexNumber,
      o.date,
      o.entityId,
      o.category,
      o.vendorName,
      o.description,
      o.nominal,
      o.tax,
      o.total,
      o.status
    ]);
    downloadCSV('Laporan_OPEX_TokoCung', headers, rows);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="bg-white border border-slate-200/90 rounded-xl p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">OPEX Dashboard (Biaya Operasional)</h1>
          <p className="text-xs text-slate-500 mt-1">
            Manajemen pos beban operasional bisnis toko, kantor cabang, dan fasilitas pusat.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExport}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border border-slate-200 hover:bg-slate-50 text-slate-700 transition-colors cursor-pointer"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={() => setShowAddModal(true)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white transition-colors cursor-pointer shadow-2xs"
          >
            <Plus className="w-4 h-4" />
            <span>+ Catat Transaksi OPEX</span>
          </button>
        </div>
      </div>

      {/* Filter and Summary */}
      <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-xs flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2 flex-1 max-w-sm border border-slate-200 rounded-lg px-2.5 py-1.5 bg-slate-50">
          <Search className="w-3.5 h-3.5 text-slate-400" />
          <input
            type="text"
            placeholder="Cari nomor OPEX, vendor, atau keterangan..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full bg-transparent outline-none text-xs text-slate-800 placeholder-slate-400"
          />
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            <span className="text-slate-500 font-medium">Kategori:</span>
            <select
              value={categoryFilter}
              onChange={e => setCategoryFilter(e.target.value)}
              className="border border-slate-200 rounded-lg px-2 py-1 text-xs text-slate-700 bg-white"
            >
              <option value="ALL">Semua Kategori ({OPEX_CATEGORIES.length})</option>
              {OPEX_CATEGORIES.map(cat => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          <div className="bg-slate-100 px-3 py-1 rounded-lg font-medium text-slate-700 text-xs tabular-nums">
            Total: <span className="font-bold text-slate-900">{formatRupiah(totalFiltered)}</span>
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                <th className="py-3 px-3">No. OPEX</th>
                <th className="py-3 px-3">Tanggal</th>
                <th className="py-3 px-3">Entitas</th>
                <th className="py-3 px-3">Kategori</th>
                <th className="py-3 px-3">Vendor / Rekanan</th>
                <th className="py-3 px-3">Deskripsi</th>
                <th className="py-3 px-3 text-right">Nominal</th>
                <th className="py-3 px-3 text-right">Pajak</th>
                <th className="py-3 px-3 text-right">Total Beban</th>
                <th className="py-3 px-3 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map(op => (
                <tr
                  key={op.id}
                  onClick={() => setSelectedOpex(op)}
                  className="hover:bg-slate-50/90 transition-colors cursor-pointer group"
                >
                  <td className="py-2.5 px-3 font-semibold text-slate-900 font-mono">
                    <div className="flex items-center gap-1.5 group-hover:text-blue-700">
                      <span>{op.opexNumber}</span>
                      <Eye className="w-3.5 h-3.5 text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                    {op.paymentRequestNumber && (
                      <div className="text-[10px] text-slate-400">Ref: {op.paymentRequestNumber}</div>
                    )}
                  </td>
                  <td className="py-2.5 px-3 text-slate-600">{formatDate(op.date)}</td>
                  <td className="py-2.5 px-3 font-medium text-slate-700">
                    {entities.find(e => e.id === op.entityId)?.code || op.entityId}
                  </td>
                  <td className="py-2.5 px-3">
                    <span className="font-medium text-slate-800 bg-slate-100 px-2 py-0.5 rounded text-[11px]">
                      {op.category}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 font-medium text-slate-800">{op.vendorName}</td>
                  <td className="py-2.5 px-3 text-slate-600 max-w-[220px] truncate" title={op.description}>
                    {op.description}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-700">
                    {formatRupiah(op.nominal)}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-500">
                    {op.tax > 0 ? formatRupiah(op.tax) : '-'}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono font-bold tabular-nums text-slate-900">
                    {formatRupiah(op.total)}
                  </td>
                  <td className="py-2.5 px-3 text-center">
                    <span className="text-[11px] font-medium px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200/50">
                      {op.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* OPEX DETAIL VOUCHER MODAL */}
      {selectedOpex && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 animate-in fade-in">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-lg w-full flex flex-col text-xs overflow-hidden animate-in zoom-in-95">
            {/* Header */}
            <div className="p-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
              <div>
                <span className="font-mono text-base font-bold text-slate-900">{selectedOpex.opexNumber}</span>
                <div className="text-[11px] text-slate-500">Voucher Beban Operasional · {formatDate(selectedOpex.date)}</div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={printReport}
                  className="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-100 text-slate-600"
                  title="Cetak Bukti Pengeluaran"
                >
                  <Printer className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setSelectedOpex(null)}
                  className="w-8 h-8 rounded-lg border border-slate-200 flex items-center justify-center text-slate-400 hover:text-slate-800 hover:bg-slate-100"
                >
                  ✕
                </button>
              </div>
            </div>

            {/* Content */}
            <div className="p-5 space-y-4">
              <div className="grid grid-cols-2 gap-3 p-3 bg-slate-50 border border-slate-200 rounded-xl">
                <div>
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Kategori Biaya</span>
                  <span className="font-semibold text-slate-900 text-xs">{selectedOpex.category}</span>
                </div>
                <div>
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Entitas Pembebanan</span>
                  <span className="font-semibold text-slate-800 text-xs">
                    {entities.find(e => e.id === selectedOpex.entityId)?.name || selectedOpex.entityId}
                  </span>
                </div>
              </div>

              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Vendor / Penerima Dana</span>
                <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 text-slate-800 font-medium">
                  {selectedOpex.vendorName}
                </div>
              </div>

              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Uraian / Deskripsi Pengeluaran</span>
                <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 text-slate-800 leading-relaxed">
                  {selectedOpex.description}
                </div>
              </div>

              {/* Rincian Finansial */}
              <div className="border border-slate-200 rounded-xl p-3.5 bg-slate-50/70 space-y-2">
                <div className="flex justify-between text-slate-600">
                  <span>Nominal Pokok:</span>
                  <span className="font-mono tabular-nums">{formatRupiah(selectedOpex.nominal)}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Pajak Terkait:</span>
                  <span className="font-mono tabular-nums">{formatRupiah(selectedOpex.tax)}</span>
                </div>
                <div className="pt-2 border-t border-slate-200 flex justify-between font-bold text-slate-950 text-sm">
                  <span>Total Beban OPEX:</span>
                  <span className="font-mono tabular-nums text-rose-700">{formatRupiah(selectedOpex.total)}</span>
                </div>
              </div>

              <div className="p-3 bg-white border border-slate-200 rounded-xl flex items-center justify-between text-[11px]">
                <div>
                  <span className="text-slate-400 block">Disetujui Oleh:</span>
                  <span className="font-semibold text-slate-800">{selectedOpex.approver || 'Budi Hartono (Director)'}</span>
                </div>
                <div className="text-right">
                  <span className="text-slate-400 block">Tanggal Dibayar:</span>
                  <span className="font-semibold text-slate-800">{selectedOpex.paymentDate ? formatDate(selectedOpex.paymentDate) : formatDate(selectedOpex.date)}</span>
                </div>
              </div>
            </div>

            <div className="p-3.5 border-t border-slate-200 bg-slate-50 flex justify-end">
              <button
                onClick={() => setSelectedOpex(null)}
                className="px-4 py-1.5 rounded-lg bg-slate-900 text-white font-semibold hover:bg-slate-800"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}


      {/* Add OPEX Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-md w-full p-6 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h3 className="text-sm font-bold text-slate-900">Catat Transaksi OPEX Baru</h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-600">✕</button>
            </div>

            <form onSubmit={handleCreate} className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Tanggal</label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={e => setDate(e.target.value)}
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Entitas</label>
                  <select
                    value={entityId}
                    onChange={e => setEntityId(e.target.value)}
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                  >
                    {entities.map(e => (
                      <option key={e.id} value={e.id}>{e.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-600 font-medium mb-1">Kategori OPEX</label>
                <select
                  value={category}
                  onChange={e => setCategory(e.target.value as any)}
                  className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                >
                  {OPEX_CATEGORIES.map(c => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-600 font-medium mb-1">Vendor / Rekanan</label>
                <input
                  type="text"
                  required
                  value={vendorName}
                  onChange={e => setVendorName(e.target.value)}
                  className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                />
              </div>

              <div>
                <label className="block text-slate-600 font-medium mb-1">Deskripsi Beban</label>
                <input
                  type="text"
                  required
                  placeholder="Keterangan pengeluaran..."
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Nominal Pokok (Rp)</label>
                  <input
                    type="number"
                    step={1000}
                    required
                    value={nominal}
                    onChange={e => setNominal(Number(e.target.value))}
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Pajak (Rp)</label>
                  <input
                    type="number"
                    step={1000}
                    value={tax}
                    onChange={e => setTax(Number(e.target.value))}
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs font-mono"
                  />
                </div>
              </div>

              <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg flex justify-between font-bold text-slate-900">
                <span>Total Beban OPEX:</span>
                <span className="font-mono">{formatRupiah(nominal + tax)}</span>
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-600"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-semibold"
                >
                  Simpan OPEX
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
