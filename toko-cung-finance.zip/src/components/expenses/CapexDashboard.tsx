import React from 'react';
import { useFinance } from '../../context/FinanceContext';
import { formatCompactRupiah, formatRupiah, MONTH_SHORT_ID } from '../../utils/formatters';
import { StatCard } from '../common/StatCard';
import { BarChart } from '../common/SimpleChart';
import { Building, HardDrive, CalendarDays, ShieldCheck } from 'lucide-react';

export const CapexDashboard: React.FC = () => {
  const { assets, capexRequests, twelveMonthsPnl, globalFilter } = useFinance();

  const totalCapexValue = capexRequests.reduce((sum, c) => sum + c.acquisitionCost, 0);
  const totalAssetsBookValue = assets.reduce((sum, a) => sum + a.bookValue, 0);
  const totalMonthlyDepreciation = assets.reduce((sum, a) => sum + a.monthlyDepreciation, 0);
  const activeAssetsCount = assets.filter(a => a.status === 'Active').length;

  const capexVsDeprData = twelveMonthsPnl.map((m, idx) => {
    const monthNum = idx + 1;
    const monthCapex = capexRequests
      .filter(c => {
        if (!c.acquisitionDate) return false;
        const [y, mStr] = c.acquisitionDate.split('-').map(Number);
        return y === globalFilter.year && mStr === monthNum;
      })
      .reduce((sum, c) => sum + c.acquisitionCost, 0);

    return {
      label: MONTH_SHORT_ID[idx],
      value: monthCapex,
      secondaryValue: m.totalDepreciation,
      color: 'bg-amber-600',
    };
  });

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="bg-white border border-slate-200/90 rounded-xl p-5 shadow-xs">
        <h1 className="text-xl font-bold text-slate-900 tracking-tight">CAPEX & Fixed Asset Dashboard</h1>
        <p className="text-xs text-slate-500 mt-1">
          Pengendalian belanja modal, kapitalisasi aktiva tetap, dan jadwal penyusutan terintegrasi ke P&L dan Arus Kas.
        </p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Belanja CAPEX"
          value={formatCompactRupiah(totalCapexValue)}
          subtitle={formatRupiah(totalCapexValue)}
          indicatorText={`${capexRequests.length} Paket Pengadaan`}
          icon={<Building className="w-4 h-4" />}
        />
        <StatCard
          title="Nilai Buku Aset (Book Value)"
          value={formatCompactRupiah(totalAssetsBookValue)}
          subtitle={formatRupiah(totalAssetsBookValue)}
          indicatorText="Total Aset Berjalan"
          icon={<HardDrive className="w-4 h-4" />}
        />
        <StatCard
          title="Beban Susut (Depresiasi/Bln)"
          value={formatCompactRupiah(totalMonthlyDepreciation)}
          subtitle={`${formatRupiah(totalMonthlyDepreciation)} / bulan`}
          indicatorText="Mengurangi EBITDA di P&L"
          icon={<CalendarDays className="w-4 h-4" />}
        />
        <StatCard
          title="Total Aset Aktif"
          value={`${activeAssetsCount} Unit`}
          subtitle="Tercatat di Asset Register"
          indicatorText="Semua Terawat & Beroperasi"
          icon={<HardDrive className="w-4 h-4" />}
        />
      </div>

      {/* Accounting Integrity Note */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs flex items-start gap-3 text-xs text-slate-600">
        <ShieldCheck className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
        <div className="leading-relaxed">
          <span className="font-semibold text-slate-900">Perbedaan Prinsip Akuntansi P&L vs Arus Kas pada CAPEX:</span>
          <p className="mt-0.5">
            1. <strong className="text-slate-800">Laporan Laba Rugi (P&L):</strong> Pengeluaran modal tidak langsung diakui sebagai beban saat beli. Beban yang masuk hanyalah <code className="font-mono bg-slate-100 px-1 py-0.5 rounded text-indigo-700">Depresiasi Bulanan</code>.
            <br />
            2. <strong className="text-slate-800">Laporan Arus Kas:</strong> Nilai perolehan CAPEX masuk penuh sebagai pengeluaran kas di pos <code className="font-mono bg-slate-100 px-1 py-0.5 rounded text-amber-700">Arus Kas Investasi (Investing Outflow)</code>.
          </p>
        </div>
      </div>

      {/* Main Chart */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
        <div className="flex items-center justify-between mb-2">
          <div>
            <h2 className="text-sm font-bold text-slate-900">Alokasi CAPEX vs Beban Depresiasi Bulanan (2026)</h2>
            <p className="text-xs text-slate-500">Perbandingan belanja aset modal baru terhadap beban susut P&L per bulan</p>
          </div>
          <span className="text-xs font-semibold px-2 py-0.5 rounded bg-slate-100 text-slate-700">
            Audit Ready
          </span>
        </div>
        <div className="h-64">
          <BarChart
            data={capexVsDeprData}
            primaryLegend="CAPEX Baru (Investing Cash)"
            secondaryLegend="Beban Penyusutan (P&L)"
            height={240}
          />
        </div>
      </div>
    </div>
  );
};
