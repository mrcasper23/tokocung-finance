import React, { useState } from 'react';
import { useFinance } from '../../context/FinanceContext';
import { formatRupiah, formatCompactRupiah } from '../../utils/formatters';
import { Tag, TrendingUp, AlertCircle, Eye, MousePointerClick } from 'lucide-react';
import { OpexCategoryName } from '../../types/finance';
import { CategoryOpexModal } from '../modals/CategoryOpexModal';

const DEFAULT_CATEGORIES: { name: OpexCategoryName; desc: string; targetMonthlyBudget: number }[] = [
  { name: 'Gaji', desc: 'Gaji pokok, lembur, dan kompensasi karyawan operasional', targetMonthlyBudget: 42_000_000 },
  { name: 'Utilities', desc: 'Listrik PLN, air PAM, dan utilitas fasilitas', targetMonthlyBudget: 8_500_000 },
  { name: 'Logistik', desc: 'Bahan bakar minyak armada, tol, dan ekspedisi lokal', targetMonthlyBudget: 9_000_000 },
  { name: 'Advertisement', desc: 'Iklan digital Meta Ads, Google Ads, dan promosi banner', targetMonthlyBudget: 7_500_000 },
  { name: 'Maintenance', desc: 'Perbaikan sarana toko, service AC berkala, dan mesin', targetMonthlyBudget: 4_000_000 },
  { name: 'Server', desc: 'Cloud hosting AWS/GCP, lisensi POS, dan software keuangan', targetMonthlyBudget: 3_500_000 },
  { name: 'ATK', desc: 'Kertas struk kasir, plastik belanja, dan alat tulis kantor', targetMonthlyBudget: 3_200_000 },
  { name: 'Internet', desc: 'Dedicated fiber optic, bandwidth, dan VPN cabang', targetMonthlyBudget: 2_800_000 },
  { name: 'Insurance', desc: 'Asuransi gedung toko, stok gudang, dan armada pengiriman', targetMonthlyBudget: 2_500_000 },
  { name: 'Professional Fee', desc: 'Jasa kantor konsultan pajak, legal, dan notaris', targetMonthlyBudget: 2_000_000 },
  { name: 'Transportation', desc: 'Transport dinas luar kota dan perjalanan manajerial', targetMonthlyBudget: 1_500_000 },
  { name: 'Tunjangan', desc: 'Tunjangan hari raya, insentif lembur, dan benefit staf', targetMonthlyBudget: 2_000_000 },
  { name: 'Administrasi', desc: 'Biaya materai, perizinan dinas, dan pengurusan domisili', targetMonthlyBudget: 1_000_000 },
  { name: 'Other Operating Expenses', desc: 'Pengeluaran operasional lain-lain yang belum terpetakan', targetMonthlyBudget: 1_500_000 },
];

export const ExpenseCategories: React.FC = () => {
  const { opex, globalFilter } = useFinance();
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  return (
    <div className="space-y-6 pb-12">
      <div className="bg-white border border-slate-200/90 rounded-xl p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Kategori Beban Operasional (OPEX)</h1>
          <p className="text-xs text-slate-500 mt-1">
            Daftar standar pos akun pengeluaran operasional dengan pagu anggaran bulanan. Klik kartu mana saja untuk melihat voucher transaksi riil.
          </p>
        </div>
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-blue-50 text-blue-800 text-[11px] font-semibold border border-blue-200/60 shrink-0">
          <MousePointerClick className="w-3.5 h-3.5 text-blue-600" />
          <span>Klik kartu untuk daftar voucher</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {DEFAULT_CATEGORIES.map(cat => {
          // Total actual in this month or year
          const totalActual = opex
            .filter(o => o.category === cat.name)
            .reduce((sum, o) => sum + o.total, 0);

          const monthlyAvg = totalActual / 12;
          const budget = cat.targetMonthlyBudget;
          const variance = monthlyAvg - budget;
          const isOverBudget = variance > 0;

          return (
            <div
              key={cat.name}
              onClick={() => setSelectedCategory(cat.name)}
              className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs flex flex-col justify-between hover:border-blue-400 hover:shadow-md transition-all cursor-pointer group"
              title={`Klik untuk melihat seluruh transaksi OPEX ${cat.name}`}
            >
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="font-bold text-sm text-slate-900 group-hover:text-blue-700 transition-colors flex items-center gap-1.5">
                    <span>{cat.name}</span>
                    <Eye className="w-3.5 h-3.5 text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </span>
                  <span className="text-[11px] font-mono text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                    Bujet: {formatCompactRupiah(budget)}/bln
                  </span>
                </div>
                <p className="text-xs text-slate-500 leading-relaxed min-h-[36px]">{cat.desc}</p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                <div>
                  <span className="text-[11px] text-slate-400 block">Rata-rata Realisasi:</span>
                  <span className="font-bold text-slate-800 font-mono tabular-nums">
                    {formatRupiah(monthlyAvg)}
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-[11px] text-slate-400 block">Status:</span>
                  <span
                    className={`font-semibold tabular-nums text-[11px] ${
                      isOverBudget ? 'text-rose-600' : 'text-emerald-600'
                    }`}
                  >
                    {isOverBudget ? `Over +${formatCompactRupiah(variance)}` : 'On Budget'}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Category Detail Modal */}
      {selectedCategory && (
        <CategoryOpexModal
          category={selectedCategory}
          onClose={() => setSelectedCategory(null)}
        />
      )}
    </div>
  );
};
