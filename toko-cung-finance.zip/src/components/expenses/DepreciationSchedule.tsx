import React, { useState } from 'react';
import { useFinance } from '../../context/FinanceContext';
import { formatRupiah, MONTH_SHORT_ID, downloadCSV } from '../../utils/formatters';
import { CalendarDays, FileSpreadsheet } from 'lucide-react';

export const DepreciationSchedule: React.FC = () => {
  const { assets, globalFilter } = useFinance();
  const [selectedAssetId, setSelectedAssetId] = useState<string>('ALL');

  const filteredAssets = selectedAssetId === 'ALL'
    ? assets
    : assets.filter(a => a.id === selectedAssetId);

  const handleExport = () => {
    const headers = ['Kode Aset', 'Nama Aset', ...MONTH_SHORT_ID, 'Total Penyusutan 2026'];
    const rows = filteredAssets.map(a => {
      const monthly = a.monthlyDepreciation;
      const total2026 = monthly * 12;
      return [
        a.assetCode,
        a.assetName,
        ...Array(12).fill(monthly),
        total2026
      ];
    });
    downloadCSV(`Jadwal_Penyusutan_Aset_${globalFilter.year}`, headers, rows);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="bg-white border border-slate-200/90 rounded-xl p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Depreciation Schedule (Jadwal Penyusutan)</h1>
          <p className="text-xs text-slate-500 mt-1">
            Matriks pembebanan penyusutan garis lurus bulanan selama tahun buku 2026 untuk seluruh aktiva tetap.
          </p>
        </div>

        <button
          onClick={handleExport}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white transition-colors cursor-pointer shadow-2xs shrink-0"
        >
          <FileSpreadsheet className="w-3.5 h-3.5" />
          <span>Export Excel</span>
        </button>
      </div>

      {/* Asset Selector Filter */}
      <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-xs flex items-center gap-3 text-xs">
        <span className="text-slate-500 font-medium">Pilih Aset:</span>
        <select
          value={selectedAssetId}
          onChange={e => setSelectedAssetId(e.target.value)}
          className="border border-slate-200 rounded-lg px-2.5 py-1 text-xs text-slate-800 bg-white"
        >
          <option value="ALL">Semua Aset Tetap ({assets.length} Aset)</option>
          {assets.map(a => (
            <option key={a.id} value={a.id}>
              {a.assetCode} - {a.assetName}
            </option>
          ))}
        </select>
      </div>

      {/* Monthly Depreciation Schedule Table */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="bg-slate-100/80 border-b border-slate-200 text-slate-700">
                <th className="py-3 px-3 font-semibold sticky left-0 bg-slate-100 min-w-[200px]">
                  Aset & Kode
                </th>
                {MONTH_SHORT_ID.map((m, idx) => (
                  <th key={idx} className="py-3 px-2 text-right font-medium min-w-[85px] tabular-nums">
                    {m}
                  </th>
                ))}
                <th className="py-3 px-3 text-right font-bold text-slate-900 bg-slate-200/70 min-w-[110px] tabular-nums">
                  Total 2026
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredAssets.map(a => {
                const monthly = a.monthlyDepreciation;
                const totalYear = monthly * 12;

                return (
                  <tr key={a.id} className="hover:bg-slate-50">
                    <td className="py-2.5 px-3 sticky left-0 bg-white font-medium text-slate-900">
                      <div>{a.assetName}</div>
                      <div className="text-[10px] text-slate-400 font-mono">{a.assetCode}</div>
                    </td>
                    {Array(12).fill(0).map((_, mIdx) => (
                      <td key={mIdx} className="py-2.5 px-2 text-right font-mono tabular-nums text-slate-700">
                        {formatRupiah(monthly, false)}
                      </td>
                    ))}
                    <td className="py-2.5 px-3 text-right font-mono font-bold tabular-nums text-slate-950 bg-slate-50">
                      {formatRupiah(totalYear)}
                    </td>
                  </tr>
                );
              })}
            </tbody>
            <tfoot>
              <tr className="bg-slate-100 font-bold border-t-2 border-slate-300">
                <td className="py-3 px-3 sticky left-0 bg-slate-100 text-slate-900">
                  TOTAL BEBAN SUSUT (P&L)
                </td>
                {Array(12).fill(0).map((_, mIdx) => {
                  const sumMonth = filteredAssets.reduce((s, a) => s + a.monthlyDepreciation, 0);
                  return (
                    <td key={mIdx} className="py-3 px-2 text-right font-mono tabular-nums text-indigo-900">
                      {formatRupiah(sumMonth, false)}
                    </td>
                  );
                })}
                <td className="py-3 px-3 text-right font-mono tabular-nums text-indigo-950 bg-slate-200">
                  {formatRupiah(filteredAssets.reduce((s, a) => s + a.monthlyDepreciation * 12, 0))}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    </div>
  );
};
