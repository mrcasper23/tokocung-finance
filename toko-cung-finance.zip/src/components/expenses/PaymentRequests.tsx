import React, { useState } from 'react';
import { useFinance } from '../../context/FinanceContext';
import { formatRupiah, formatDate, downloadCSV, printReport } from '../../utils/formatters';
import { PaymentRequest, PaymentRequestStatus } from '../../types/finance';
import {
  Plus,
  Check,
  ArrowRight,
  Clock,
  FileText,
  CheckCircle2,
  DollarSign,
  Filter,
  Search,
  Eye,
  Building,
  User,
  Calendar,
  AlertCircle,
  Paperclip,
  Printer,
  ChevronRight,
  ShieldCheck,
  CreditCard
} from 'lucide-react';

export const PaymentRequests: React.FC = () => {
  const { paymentRequests, createPaymentRequest, updatePaymentRequestStatus, currentUser, vendors } = useFinance();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedPr, setSelectedPr] = useState<PaymentRequest | null>(null);

  // New PR Form State
  const [requestor, setRequestor] = useState(currentUser.name);
  const [department, setDepartment] = useState('Operations');
  const [purpose, setPurpose] = useState('');
  const [dueDate, setDueDate] = useState('2026-04-15');
  const [priority, setPriority] = useState<'Rendah' | 'Sedang' | 'Tinggi'>('Sedang');
  const [vendorName, setVendorName] = useState(vendors[0]?.name || 'PT Vendor Rekanan');
  const [invoiceNumber, setInvoiceNumber] = useState('');
  const [invoiceDate, setInvoiceDate] = useState('2026-04-01');
  const [itemDesc, setItemDesc] = useState('');
  const [itemQty, setItemQty] = useState(1);
  const [itemPrice, setItemPrice] = useState(500000);
  const [taxAmount, setTaxAmount] = useState(0);

  const filtered = paymentRequests.filter(pr => {
    const matchSearch =
      pr.prNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      pr.purpose.toLowerCase().includes(searchTerm.toLowerCase()) ||
      pr.vendorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      pr.requestor.toLowerCase().includes(searchTerm.toLowerCase());
    const matchStatus = statusFilter === 'ALL' || pr.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    const itemTotal = itemQty * itemPrice;
    const subtotal = itemTotal;
    const grandTotal = subtotal + taxAmount;

    createPaymentRequest({
      requestor,
      department,
      purpose,
      dueDate,
      priority,
      vendorName,
      invoiceNumber: invoiceNumber || `INV-${Date.now().toString().slice(-4)}`,
      invoiceDate,
      items: [
        {
          id: `item-${Date.now()}`,
          description: itemDesc || purpose,
          qty: itemQty,
          unit: 'Paket/Unit',
          price: itemPrice,
          total: itemTotal,
        },
      ],
      subtotal,
      tax: taxAmount,
      grandTotal,
      status: 'Submitted',
    });

    setShowAddModal(false);
    setPurpose('');
    setItemDesc('');
  };

  const getStatusBadge = (status: PaymentRequestStatus) => {
    switch (status) {
      case 'Draft':
        return <span className="text-slate-600 bg-slate-100 px-2 py-0.5 rounded text-[11px] font-medium">Draft</span>;
      case 'Submitted':
        return <span className="text-blue-700 bg-blue-50 px-2 py-0.5 rounded text-[11px] font-medium">Diajukan (Submitted)</span>;
      case 'Reviewed':
        return <span className="text-purple-700 bg-purple-50 px-2 py-0.5 rounded text-[11px] font-medium">Direview Finance</span>;
      case 'Approved':
        return <span className="text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded text-[11px] font-medium">Disetujui Direktur</span>;
      case 'Paid':
        return <span className="text-amber-800 bg-amber-50 px-2 py-0.5 rounded text-[11px] font-bold">Lunas (Paid)</span>;
      case 'Completed':
        return <span className="text-slate-900 bg-slate-200 px-2 py-0.5 rounded text-[11px] font-bold">Selesai (Completed)</span>;
    }
  };

  // Helper for Workflow Step Index
  const getWorkflowStepIndex = (status: PaymentRequestStatus) => {
    switch (status) {
      case 'Draft': return 0;
      case 'Submitted': return 1;
      case 'Reviewed': return 2;
      case 'Approved': return 3;
      case 'Paid': return 4;
      case 'Completed': return 5;
      default: return 1;
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="bg-white border border-slate-200/90 rounded-xl p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Payment Request (Pengajuan Pembayaran)</h1>
          <p className="text-xs text-slate-500 mt-1">
            Alur persetujuan bertingkat: <span className="font-semibold text-slate-700">Draft → Submitted → Reviewed → Approved → Paid → Completed</span>. Klik baris mana saja untuk melihat detail lengkap.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white transition-colors cursor-pointer shadow-2xs shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>+ Buat Payment Request</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-xs flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2 flex-1 max-w-sm border border-slate-200 rounded-lg px-2.5 py-1.5 bg-slate-50">
          <Search className="w-3.5 h-3.5 text-slate-400" />
          <input
            type="text"
            placeholder="Cari PR, vendor, pemohon, atau tujuan..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full bg-transparent outline-none text-xs text-slate-800 placeholder-slate-400"
          />
        </div>

        <div className="flex items-center gap-2">
          <span className="text-slate-500 font-medium">Filter Status:</span>
          <select
            value={statusFilter}
            onChange={e => setStatusFilter(e.target.value)}
            className="border border-slate-200 rounded-lg px-2 py-1 text-xs text-slate-700 bg-white"
          >
            <option value="ALL">Semua Status</option>
            <option value="Submitted">Submitted (Diajukan)</option>
            <option value="Reviewed">Reviewed (Direview)</option>
            <option value="Approved">Approved (Disetujui)</option>
            <option value="Paid">Paid (Dibayar)</option>
          </select>
        </div>
      </div>

      {/* Payment Requests Table */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                <th className="py-3 px-3">No. PR</th>
                <th className="py-3 px-3">Tanggal / Due Date</th>
                <th className="py-3 px-3">Pemohon & Dept</th>
                <th className="py-3 px-3">Vendor / Invoice</th>
                <th className="py-3 px-3">Keperluan</th>
                <th className="py-3 px-3 text-right">Grand Total</th>
                <th className="py-3 px-3 text-center">Status Alur</th>
                <th className="py-3 px-3 text-right">Aksi Alur Kerja</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map(pr => (
                <tr
                  key={pr.id}
                  onClick={() => setSelectedPr(pr)}
                  className="hover:bg-slate-50/90 transition-colors cursor-pointer group"
                >
                  <td className="py-2.5 px-3 font-semibold text-slate-900 font-mono">
                    <div className="flex items-center gap-1.5 group-hover:text-blue-700">
                      <span>{pr.prNumber}</span>
                      <Eye className="w-3.5 h-3.5 text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                  </td>
                  <td className="py-2.5 px-3 text-slate-600">
                    <div>{formatDate(pr.createdAt)}</div>
                    <div className="text-[10px] text-slate-400">Due: {formatDate(pr.dueDate)}</div>
                  </td>
                  <td className="py-2.5 px-3">
                    <div className="font-medium text-slate-800">{pr.requestor}</div>
                    <div className="text-[10px] text-slate-500">{pr.department}</div>
                  </td>
                  <td className="py-2.5 px-3">
                    <div className="font-medium text-slate-800">{pr.vendorName}</div>
                    <div className="text-[10px] text-slate-500 font-mono">{pr.invoiceNumber}</div>
                  </td>
                  <td className="py-2.5 px-3 max-w-[200px] truncate text-slate-700" title={pr.purpose}>
                    {pr.purpose}
                  </td>
                  <td className="py-2.5 px-3 text-right font-bold font-mono tabular-nums text-slate-900">
                    {formatRupiah(pr.grandTotal)}
                  </td>
                  <td className="py-2.5 px-3 text-center">
                    {getStatusBadge(pr.status)}
                  </td>
                  <td className="py-2.5 px-3 text-right" onClick={e => e.stopPropagation()}>
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={() => setSelectedPr(pr)}
                        className="px-2 py-1 rounded bg-slate-100 text-slate-700 hover:bg-slate-200 font-medium text-[11px] cursor-pointer"
                        title="Buka rincian lengkap"
                      >
                        Detail
                      </button>

                      {pr.status === 'Submitted' && (
                        <button
                          onClick={() => updatePaymentRequestStatus(pr.id, 'Reviewed')}
                          className="px-2 py-1 rounded bg-purple-50 text-purple-700 hover:bg-purple-100 font-medium text-[11px] cursor-pointer"
                          title="Review oleh Finance"
                        >
                          Review Finance
                        </button>
                      )}
                      {pr.status === 'Reviewed' && (
                        <button
                          onClick={() => updatePaymentRequestStatus(pr.id, 'Approved')}
                          className="px-2 py-1 rounded bg-emerald-600 text-white hover:bg-emerald-700 font-medium text-[11px] cursor-pointer"
                          title="Approval oleh Direktur"
                        >
                          Setujui Direktur
                        </button>
                      )}
                      {pr.status === 'Approved' && (
                        <button
                          onClick={() => updatePaymentRequestStatus(pr.id, 'Paid')}
                          className="px-2 py-1 rounded bg-amber-500 text-slate-950 font-bold hover:bg-amber-400 text-[11px] cursor-pointer"
                          title="Bayar & Otomatis Bukukan ke OPEX"
                        >
                          Bayar (Paid)
                        </button>
                      )}
                      {pr.status === 'Paid' && (
                        <span className="text-[11px] text-emerald-600 font-medium flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" /> Terbukukan OPEX
                        </span>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* DETAIL MODAL / POPUP (TRIGGERED WHEN ROW IS CLICKED) */}
      {selectedPr && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 animate-in fade-in">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-2xl w-full max-h-[90vh] flex flex-col text-xs overflow-hidden animate-in zoom-in-95">
            {/* Modal Header */}
            <div className="p-4 sm:p-5 border-b border-slate-200 bg-slate-50/80 flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-slate-900 text-white font-bold flex items-center justify-center text-sm shadow-xs">
                  PR
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-base text-slate-900 font-mono">{selectedPr.prNumber}</span>
                    {getStatusBadge(selectedPr.status)}
                    <span className={`text-[10px] font-semibold px-2 py-0.5 rounded ${
                      selectedPr.priority === 'Tinggi' ? 'bg-rose-100 text-rose-800' :
                      selectedPr.priority === 'Sedang' ? 'bg-amber-100 text-amber-800' : 'bg-slate-100 text-slate-700'
                    }`}>
                      Prioritas: {selectedPr.priority}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    Dibuat pada {formatDate(selectedPr.createdAt)} · Jatuh Tempo: {formatDate(selectedPr.dueDate)}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={printReport}
                  className="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-100 text-slate-600 cursor-pointer"
                  title="Cetak Voucher"
                >
                  <Printer className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setSelectedPr(null)}
                  className="w-8 h-8 rounded-lg border border-slate-200 flex items-center justify-center text-slate-400 hover:text-slate-800 hover:bg-slate-100 cursor-pointer"
                >
                  ✕
                </button>
              </div>
            </div>

            {/* Modal Scrollable Content */}
            <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5">
              {/* Visual Workflow Stepper */}
              <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-200">
                <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-2.5">
                  Status Alur Persetujuan & Pembayaran
                </div>
                <div className="flex items-center justify-between relative">
                  <div className="absolute left-3 right-3 top-3 h-0.5 bg-slate-200 -z-0" />
                  {[
                    { label: 'Draft', key: 'Draft', step: 0 },
                    { label: 'Diajukan', key: 'Submitted', step: 1 },
                    { label: 'Review Finance', key: 'Reviewed', step: 2 },
                    { label: 'Approval Direktur', key: 'Approved', step: 3 },
                    { label: 'Lunas (Paid)', key: 'Paid', step: 4 },
                  ].map((stepItem, sIdx) => {
                    const currentStepIdx = getWorkflowStepIndex(selectedPr.status);
                    const isDone = currentStepIdx >= stepItem.step;
                    const isCurrent = currentStepIdx === stepItem.step;

                    return (
                      <div key={sIdx} className="flex flex-col items-center z-10 text-center relative px-1">
                        <div
                          className={`w-6 h-6 rounded-full flex items-center justify-center font-bold text-[10px] transition-colors ${
                            isDone
                              ? 'bg-emerald-600 text-white ring-4 ring-emerald-50'
                              : 'bg-white border-2 border-slate-300 text-slate-400'
                          }`}
                        >
                          {isDone ? <Check className="w-3.5 h-3.5" /> : sIdx + 1}
                        </div>
                        <span
                          className={`text-[10px] mt-1.5 font-medium whitespace-nowrap ${
                            isCurrent ? 'font-bold text-slate-900' : isDone ? 'text-emerald-700' : 'text-slate-400'
                          }`}
                        >
                          {stepItem.label}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Informational Cards Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                {/* Pemohon & Departemen */}
                <div className="p-3.5 bg-white border border-slate-200 rounded-xl space-y-1.5 shadow-2xs">
                  <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-slate-400" />
                    <span>Pemohon & Departemen</span>
                  </div>
                  <div className="font-bold text-slate-900 text-sm">{selectedPr.requestor}</div>
                  <div className="text-slate-600">{selectedPr.department}</div>
                  <div className="pt-2 border-t border-slate-100 flex justify-between text-[11px] text-slate-500">
                    <span>Jatuh Tempo:</span>
                    <span className="font-semibold text-slate-800">{formatDate(selectedPr.dueDate)}</span>
                  </div>
                </div>

                {/* Vendor Rekanan & Faktur */}
                <div className="p-3.5 bg-white border border-slate-200 rounded-xl space-y-1.5 shadow-2xs">
                  <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                    <Building className="w-3.5 h-3.5 text-slate-400" />
                    <span>Vendor Rekanan & Faktur</span>
                  </div>
                  <div className="font-bold text-slate-900 text-sm">{selectedPr.vendorName}</div>
                  <div className="font-mono text-slate-600 text-[11px]">No Invoice: {selectedPr.invoiceNumber}</div>
                  <div className="pt-2 border-t border-slate-100 flex justify-between text-[11px] text-slate-500">
                    <span>Tgl Invoice:</span>
                    <span className="font-semibold text-slate-800">{formatDate(selectedPr.invoiceDate)}</span>
                  </div>
                </div>
              </div>

              {/* Keperluan Pembayaran */}
              <div className="p-3.5 bg-slate-50 border border-slate-200/90 rounded-xl space-y-1">
                <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                  Maksud & Tujuan Pembayaran (Purpose)
                </div>
                <div className="text-slate-800 font-medium leading-relaxed">
                  {selectedPr.purpose}
                </div>
              </div>

              {/* Rincian Item Barang / Jasa */}
              <div className="border border-slate-200 rounded-xl overflow-hidden shadow-2xs">
                <div className="px-4 py-2.5 bg-slate-50 border-b border-slate-200 font-bold text-slate-900 flex justify-between items-center">
                  <span>Rincian Item Pembayaran</span>
                  <span className="text-slate-500 text-[11px] font-normal">{selectedPr.items.length} Item</span>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-slate-100/60 border-b border-slate-200 text-slate-600 font-semibold">
                        <th className="py-2 px-3">No</th>
                        <th className="py-2 px-3">Deskripsi Barang / Jasa</th>
                        <th className="py-2 px-3 text-right">Kuantitas</th>
                        <th className="py-2 px-3">Satuan</th>
                        <th className="py-2 px-3 text-right">Harga Satuan</th>
                        <th className="py-2 px-3 text-right">Subtotal</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {selectedPr.items.map((item, i) => (
                        <tr key={item.id || i} className="hover:bg-slate-50/60">
                          <td className="py-2 px-3 text-slate-400 font-mono">{i + 1}</td>
                          <td className="py-2 px-3 font-medium text-slate-900">{item.description}</td>
                          <td className="py-2 px-3 text-right font-mono tabular-nums">{item.qty}</td>
                          <td className="py-2 px-3 text-slate-500">{item.unit || 'Unit'}</td>
                          <td className="py-2 px-3 text-right font-mono tabular-nums text-slate-700">{formatRupiah(item.price)}</td>
                          <td className="py-2 px-3 text-right font-mono font-semibold tabular-nums text-slate-900">{formatRupiah(item.total)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Perhitungan Finansial */}
                <div className="p-4 bg-slate-50/80 border-t border-slate-200 space-y-1.5 text-xs">
                  <div className="flex justify-between text-slate-600">
                    <span>Subtotal Biaya Item:</span>
                    <span className="font-mono tabular-nums">{formatRupiah(selectedPr.subtotal)}</span>
                  </div>
                  <div className="flex justify-between text-slate-600">
                    <span>Pajak (PPN / PPh):</span>
                    <span className="font-mono tabular-nums">{formatRupiah(selectedPr.tax)}</span>
                  </div>
                  <div className="flex justify-between pt-2 border-t border-slate-200 font-bold text-slate-950 text-sm">
                    <span>Grand Total Tagihan:</span>
                    <span className="font-mono tabular-nums text-emerald-700">{formatRupiah(selectedPr.grandTotal)}</span>
                  </div>
                </div>
              </div>

              {/* Jejak Verifikasi & Otorisasi */}
              <div className="p-3.5 bg-white border border-slate-200 rounded-xl space-y-2 text-xs">
                <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-slate-400" />
                  <span>Jejak Otorisasi & Verifikasi Finansial</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1 text-[11px]">
                  <div className="p-2 bg-slate-50 rounded border border-slate-100">
                    <span className="text-slate-400 block">Pemohon (Requestor):</span>
                    <span className="font-semibold text-slate-800">{selectedPr.requestor}</span>
                  </div>
                  <div className="p-2 bg-slate-50 rounded border border-slate-100">
                    <span className="text-slate-400 block">Review Finance:</span>
                    <span className="font-semibold text-slate-800">{selectedPr.reviewedBy || 'Siti Rahmawati (Finance)'}</span>
                  </div>
                  <div className="p-2 bg-slate-50 rounded border border-slate-100">
                    <span className="text-slate-400 block">Approval Direktur:</span>
                    <span className="font-semibold text-slate-800">{selectedPr.approvedBy || (selectedPr.status === 'Approved' || selectedPr.status === 'Paid' ? 'Budi Hartono (Director)' : 'Menunggu Approval')}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Modal Footer with Actions */}
            <div className="p-4 border-t border-slate-200 bg-slate-50 flex flex-wrap items-center justify-between gap-3">
              <div className="text-[11px] text-slate-500">
                {selectedPr.status === 'Paid' ? (
                  <span className="text-emerald-700 font-semibold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Pembayaran telah lunas & terintegrasi ke pos OPEX
                  </span>
                ) : (
                  <span>Tindakan alur persetujuan dapat dilakukan di bawah:</span>
                )}
              </div>

              <div className="flex items-center gap-2">
                {selectedPr.status === 'Submitted' && (
                  <button
                    onClick={() => {
                      updatePaymentRequestStatus(selectedPr.id, 'Reviewed');
                      setSelectedPr({ ...selectedPr, status: 'Reviewed', reviewedBy: currentUser.name });
                    }}
                    className="px-3 py-1.5 rounded-lg bg-purple-700 hover:bg-purple-800 text-white font-semibold cursor-pointer shadow-xs"
                  >
                    Verifikasi / Review Finance
                  </button>
                )}

                {selectedPr.status === 'Reviewed' && (
                  <button
                    onClick={() => {
                      updatePaymentRequestStatus(selectedPr.id, 'Approved');
                      setSelectedPr({ ...selectedPr, status: 'Approved', approvedBy: currentUser.name });
                    }}
                    className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-semibold cursor-pointer shadow-xs"
                  >
                    Setujui Direktur (Approve)
                  </button>
                )}

                {selectedPr.status === 'Approved' && (
                  <button
                    onClick={() => {
                      updatePaymentRequestStatus(selectedPr.id, 'Paid');
                      setSelectedPr({ ...selectedPr, status: 'Paid' });
                    }}
                    className="px-4 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold cursor-pointer shadow-xs flex items-center gap-1.5"
                  >
                    <CreditCard className="w-3.5 h-3.5" />
                    <span>Bayar & Bukukan ke OPEX</span>
                  </button>
                )}

                <button
                  onClick={() => setSelectedPr(null)}
                  className="px-3 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-100 text-slate-700 font-medium cursor-pointer"
                >
                  Tutup
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal Add Payment Request */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-lg w-full p-6 text-xs animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h3 className="text-sm font-bold text-slate-900">Buat Payment Request Baru</h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreate} className="space-y-3.5">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Pemohon (Requestor)</label>
                  <input
                    type="text"
                    required
                    value={requestor}
                    onChange={e => setRequestor(e.target.value)}
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Departemen</label>
                  <select
                    value={department}
                    onChange={e => setDepartment(e.target.value)}
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                  >
                    <option value="Operations">Operations</option>
                    <option value="Finance">Finance</option>
                    <option value="Accounting">Accounting</option>
                    <option value="Gudang & Logistik">Gudang & Logistik</option>
                    <option value="Commercial">Commercial</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-600 font-medium mb-1">Vendor Rekanan</label>
                <input
                  type="text"
                  required
                  value={vendorName}
                  onChange={e => setVendorName(e.target.value)}
                  className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                  placeholder="Nama vendor atau rekanan..."
                />
              </div>

              <div>
                <label className="block text-slate-600 font-medium mb-1">Keperluan Pembayaran (Purpose)</label>
                <input
                  type="text"
                  required
                  value={purpose}
                  onChange={e => setPurpose(e.target.value)}
                  className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                  placeholder="Contoh: Pengadaan bahan habis pakai toko Q2"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Jatuh Tempo (Due Date)</label>
                  <input
                    type="date"
                    required
                    value={dueDate}
                    onChange={e => setDueDate(e.target.value)}
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Prioritas</label>
                  <select
                    value={priority}
                    onChange={e => setPriority(e.target.value as any)}
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                  >
                    <option value="Rendah">Rendah</option>
                    <option value="Sedang">Sedang</option>
                    <option value="Tinggi">Tinggi</option>
                  </select>
                </div>
              </div>

              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg space-y-2">
                <div className="font-semibold text-slate-800">Rincian Item & Biaya</div>
                <div className="grid grid-cols-3 gap-2">
                  <div className="col-span-2">
                    <label className="block text-[11px] text-slate-500">Deskripsi Item</label>
                    <input
                      type="text"
                      value={itemDesc}
                      onChange={e => setItemDesc(e.target.value)}
                      placeholder="Item barang/jasa"
                      className="w-full border border-slate-200 rounded p-1.5 bg-white text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-500">Qty</label>
                    <input
                      type="number"
                      min={1}
                      value={itemQty}
                      onChange={e => setItemQty(Number(e.target.value))}
                      className="w-full border border-slate-200 rounded p-1.5 bg-white text-xs font-mono"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[11px] text-slate-500">Harga Satuan (Rp)</label>
                    <input
                      type="number"
                      step={1000}
                      value={itemPrice}
                      onChange={e => setItemPrice(Number(e.target.value))}
                      className="w-full border border-slate-200 rounded p-1.5 bg-white text-xs font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-500">Pajak (PPN/PPh) (Rp)</label>
                    <input
                      type="number"
                      step={1000}
                      value={taxAmount}
                      onChange={e => setTaxAmount(Number(e.target.value))}
                      className="w-full border border-slate-200 rounded p-1.5 bg-white text-xs font-mono"
                    />
                  </div>
                </div>

                <div className="pt-2 flex justify-between font-bold text-slate-900 border-t border-slate-200">
                  <span>Grand Total:</span>
                  <span className="font-mono">{formatRupiah(itemQty * itemPrice + taxAmount)}</span>
                </div>
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-600 font-medium cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-semibold cursor-pointer shadow-xs"
                >
                  Simpan & Ajukan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
