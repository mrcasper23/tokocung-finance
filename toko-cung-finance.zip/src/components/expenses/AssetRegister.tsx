import React, { useState } from 'react';
import { useFinance } from '../../context/FinanceContext';
import { formatRupiah, formatDate, downloadCSV, printReport } from '../../utils/formatters';
import { AssetRecord, AssetStatus } from '../../types/finance';
import { Plus, HardDrive, Search, Filter, FileSpreadsheet, MapPin, Eye, Printer, Calendar, ShieldCheck } from 'lucide-react';

export const AssetRegister: React.FC = () => {
  const { assets, addAsset } = useFinance();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedAsset, setSelectedAsset] = useState<AssetRecord | null>(null);

  // Form state
  const [assetCode, setAssetCode] = useState('');
  const [assetName, setAssetName] = useState('');
  const [category, setCategory] = useState('Peralatan & Mesin Toko');
  const [location, setLocation] = useState('Gudang Pusat Bekasi');
  const [acquisitionDate, setAcquisitionDate] = useState('2026-03-01');
  const [acquisitionCost, setAcquisitionCost] = useState(45000000);
  const [usefulLifeMonths, setUsefulLifeMonths] = useState(48);
  const [residualValue, setResidualValue] = useState(5000000);

  const filtered = assets.filter(a => {
    const matchSearch =
      a.assetCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
      a.assetName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      a.location.toLowerCase().includes(searchTerm.toLowerCase());
    const matchStatus = statusFilter === 'ALL' || a.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const totalCost = filtered.reduce((sum, a) => sum + a.acquisitionCost, 0);
  const totalBookValue = filtered.reduce((sum, a) => sum + a.bookValue, 0);
  const totalMonthlyDepr = filtered.reduce((sum, a) => sum + a.monthlyDepreciation, 0);

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    const code = assetCode || `AST-2026-${Date.now().toString().slice(-4)}`;

    addAsset({
      assetCode: code,
      assetName,
      category,
      location,
      acquisitionDate,
      acquisitionCost,
      usefulLifeMonths,
      residualValue,
      depreciationMethod: 'Straight Line',
      status: 'Active',
      isDemo: false,
    });

    setShowAddModal(false);
    setAssetName('');
    setAssetCode('');
  };

  const handleExport = () => {
    const headers = [
      'Kode Aset',
      'Nama Aset',
      'Kategori',
      'Lokasi',
      'Tgl Perolehan',
      'Nilai Perolehan',
      'Masa Manfaat (Bln)',
      'Nilai Residu',
      'Metode',
      'Depresiasi/Bln',
      'Akumulasi Depresiasi',
      'Nilai Buku',
      'Status',
    ];
    const rows = filtered.map(a => [
      a.assetCode,
      a.assetName,
      a.category,
      a.location,
      a.acquisitionDate,
      a.acquisitionCost,
      a.usefulLifeMonths,
      a.residualValue,
      a.depreciationMethod,
      a.monthlyDepreciation,
      a.accumulatedDepreciation,
      a.bookValue,
      a.status,
    ]);
    downloadCSV('Asset_Register_TokoCung', headers, rows);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="bg-white border border-slate-200/90 rounded-xl p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Asset Register (Buku Daftar Aset Tetap)</h1>
          <p className="text-xs text-slate-500 mt-1">
            Pencatatan aktiva tetap, nilai buku, dan jadwal penyusutan garis lurus (Straight Line Depreciation).
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExport}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border border-slate-200 hover:bg-slate-50 text-slate-700 transition-colors cursor-pointer"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={() => setShowAddModal(true)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white transition-colors cursor-pointer shadow-2xs"
          >
            <Plus className="w-4 h-4" />
            <span>+ Registrasi Aset Baru</span>
          </button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <span className="text-slate-500 font-medium block">Total Nilai Perolehan Aset</span>
          <span className="text-lg font-bold text-slate-900 font-mono tabular-nums">{formatRupiah(totalCost)}</span>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <span className="text-slate-500 font-medium block">Total Nilai Buku (Book Value)</span>
          <span className="text-lg font-bold text-blue-700 font-mono tabular-nums">{formatRupiah(totalBookValue)}</span>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <span className="text-slate-500 font-medium block">Total Beban Penyusutan Bulanan</span>
          <span className="text-lg font-bold text-indigo-700 font-mono tabular-nums">{formatRupiah(totalMonthlyDepr)}/bln</span>
        </div>
      </div>

      {/* Table Filter */}
      <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-xs flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2 flex-1 max-w-sm border border-slate-200 rounded-lg px-2.5 py-1.5 bg-slate-50">
          <Search className="w-3.5 h-3.5 text-slate-400" />
          <input
            type="text"
            placeholder="Cari kode aset, nama aset, atau lokasi..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full bg-transparent outline-none text-xs text-slate-800 placeholder-slate-400"
          />
        </div>

        <div className="flex items-center gap-2">
          <span className="text-slate-500 font-medium">Status Aset:</span>
          <select
            value={statusFilter}
            onChange={e => setStatusFilter(e.target.value)}
            className="border border-slate-200 rounded-lg px-2 py-1 text-xs text-slate-700 bg-white"
          >
            <option value="ALL">Semua Status</option>
            <option value="Active">Active (Aktif)</option>
            <option value="Under Maintenance">Under Maintenance</option>
            <option value="Fully Depreciated">Fully Depreciated</option>
            <option value="Disposed">Disposed / Dijual</option>
          </select>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                <th className="py-3 px-3">Kode Aset</th>
                <th className="py-3 px-3">Nama & Kategori Aset</th>
                <th className="py-3 px-3">Lokasi</th>
                <th className="py-3 px-3">Tgl Perolehan</th>
                <th className="py-3 px-3 text-right">Nilai Perolehan</th>
                <th className="py-3 px-3 text-right">Masa Manfaat</th>
                <th className="py-3 px-3 text-right">Depresiasi / Bulan</th>
                <th className="py-3 px-3 text-right">Akumulasi Susut</th>
                <th className="py-3 px-3 text-right">Nilai Buku (Book Value)</th>
                <th className="py-3 px-3 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map(a => (
                <tr
                  key={a.id}
                  onClick={() => setSelectedAsset(a)}
                  className="hover:bg-slate-50/90 transition-colors cursor-pointer group"
                >
                  <td className="py-2.5 px-3 font-semibold text-slate-900 font-mono">
                    <div className="flex items-center gap-1.5 group-hover:text-blue-700">
                      <span>{a.assetCode}</span>
                      <Eye className="w-3.5 h-3.5 text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                  </td>
                  <td className="py-2.5 px-3">
                    <div className="font-semibold text-slate-900">{a.assetName}</div>
                    <div className="text-[10px] text-slate-500">{a.category}</div>
                  </td>
                  <td className="py-2.5 px-3 text-slate-600">
                    <div className="flex items-center gap-1">
                      <MapPin className="w-3 h-3 text-slate-400" />
                      <span>{a.location}</span>
                    </div>
                  </td>
                  <td className="py-2.5 px-3 text-slate-600">{formatDate(a.acquisitionDate)}</td>
                  <td className="py-2.5 px-3 text-right font-mono font-semibold text-slate-900">
                    {formatRupiah(a.acquisitionCost)}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono text-slate-600">
                    {a.usefulLifeMonths} bln
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono font-semibold text-indigo-700">
                    {formatRupiah(a.monthlyDepreciation)}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono text-slate-500">
                    {formatRupiah(a.accumulatedDepreciation)}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-950">
                    {formatRupiah(a.bookValue)}
                  </td>
                  <td className="py-2.5 px-3 text-center">
                    <span className="px-2 py-0.5 rounded text-[11px] font-medium bg-emerald-50 text-emerald-700 border border-emerald-200/50">
                      {a.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* ASSET REGISTER DETAIL MODAL */}
      {selectedAsset && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 animate-in fade-in">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-lg w-full flex flex-col text-xs overflow-hidden animate-in zoom-in-95">
            {/* Header */}
            <div className="p-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
              <div>
                <span className="font-mono text-base font-bold text-slate-900">{selectedAsset.assetCode}</span>
                <div className="text-[11px] text-slate-500">Kartu Induk Aktiva Tetap · {selectedAsset.category}</div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={printReport}
                  className="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-100 text-slate-600"
                  title="Cetak Kartu Aset"
                >
                  <Printer className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setSelectedAsset(null)}
                  className="w-8 h-8 rounded-lg border border-slate-200 flex items-center justify-center text-slate-400 hover:text-slate-800 hover:bg-slate-100"
                >
                  ✕
                </button>
              </div>
            </div>

            {/* Content */}
            <div className="p-5 space-y-4">
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
                <div className="text-[10px] uppercase font-bold text-slate-400">Nama Aktiva Tetap</div>
                <div className="text-slate-900 font-bold text-sm">{selectedAsset.assetName}</div>
                <div className="text-[11px] text-slate-500 flex items-center gap-1.5 pt-1">
                  <MapPin className="w-3.5 h-3.5 text-slate-400" />
                  <span>Lokasi Penempatan: <strong>{selectedAsset.location}</strong></span>
                </div>
              </div>

              {/* Depreciation & Book Value Calculation Card */}
              <div className="border border-slate-200 rounded-xl p-3.5 bg-slate-50/70 space-y-2">
                <div className="flex justify-between text-slate-600">
                  <span>Tanggal Perolehan Aset:</span>
                  <span className="font-semibold text-slate-800">{formatDate(selectedAsset.acquisitionDate)}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Harga Perolehan (Cost):</span>
                  <span className="font-mono font-bold text-slate-900">{formatRupiah(selectedAsset.acquisitionCost)}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Masa Manfaat Ekonomis:</span>
                  <span className="font-mono">{selectedAsset.usefulLifeMonths} Bulan ({Math.round(selectedAsset.usefulLifeMonths / 12)} Tahun)</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Estimasi Nilai Residu:</span>
                  <span className="font-mono">{formatRupiah(selectedAsset.residualValue)}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Metode Depresiasi:</span>
                  <span className="font-semibold text-slate-800">{selectedAsset.depreciationMethod} (Garis Lurus)</span>
                </div>
                <div className="flex justify-between text-indigo-900 font-semibold pt-1 border-t border-slate-200">
                  <span>Beban Susut Per Bulan (ke P&L):</span>
                  <span className="font-mono text-indigo-700">{formatRupiah(selectedAsset.monthlyDepreciation)} / bulan</span>
                </div>
                <div className="flex justify-between text-rose-700">
                  <span>Akumulasi Penyusutan Berjalan:</span>
                  <span className="font-mono">-{formatRupiah(selectedAsset.accumulatedDepreciation)}</span>
                </div>
                <div className="pt-2 border-t border-slate-300 flex justify-between font-bold text-slate-950 text-sm">
                  <span>Nilai Buku Saat Ini (Book Value):</span>
                  <span className="font-mono text-emerald-700">{formatRupiah(selectedAsset.bookValue)}</span>
                </div>
              </div>

              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between text-[11px]">
                <span className="text-emerald-900 font-medium">Status Operasional Aktiva:</span>
                <span className="font-bold text-emerald-800">{selectedAsset.status}</span>
              </div>
            </div>

            <div className="p-3.5 border-t border-slate-200 bg-slate-50 flex justify-end">
              <button
                onClick={() => setSelectedAsset(null)}
                className="px-4 py-1.5 rounded-lg bg-slate-900 text-white font-semibold hover:bg-slate-800"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}


      {/* Modal Add Asset */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-lg w-full p-6 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h3 className="text-sm font-bold text-slate-900">Registrasi Aset Baru</h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-600">✕</button>
            </div>

            <form onSubmit={handleCreate} className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Kode Aset</label>
                  <input
                    type="text"
                    value={assetCode}
                    onChange={e => setAssetCode(e.target.value)}
                    placeholder="Auto (misal AST-2026-001)"
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Kategori</label>
                  <select
                    value={category}
                    onChange={e => setCategory(e.target.value)}
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                  >
                    <option value="Gedung & Bangunan">Gedung & Bangunan</option>
                    <option value="Kendaraan & Alat Berat">Kendaraan & Alat Berat</option>
                    <option value="Peralatan Elektronik">Peralatan Elektronik</option>
                    <option value="Peralatan & Inventaris">Peralatan & Inventaris</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-600 font-medium mb-1">Nama Aset</label>
                <input
                  type="text"
                  required
                  value={assetName}
                  onChange={e => setAssetName(e.target.value)}
                  placeholder="Nama aset lengkap..."
                  className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Lokasi Aset</label>
                  <input
                    type="text"
                    required
                    value={location}
                    onChange={e => setLocation(e.target.value)}
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Tanggal Perolehan</label>
                  <input
                    type="date"
                    required
                    value={acquisitionDate}
                    onChange={e => setAcquisitionDate(e.target.value)}
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Harga Perolehan (Rp)</label>
                  <input
                    type="number"
                    step={1000000}
                    required
                    value={acquisitionCost}
                    onChange={e => setAcquisitionCost(Number(e.target.value))}
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Masa Manfaat (Bln)</label>
                  <input
                    type="number"
                    min={6}
                    required
                    value={usefulLifeMonths}
                    onChange={e => setUsefulLifeMonths(Number(e.target.value))}
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Nilai Residu (Rp)</label>
                  <input
                    type="number"
                    step={500000}
                    value={residualValue}
                    onChange={e => setResidualValue(Number(e.target.value))}
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs font-mono"
                  />
                </div>
              </div>

              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg flex justify-between font-bold text-slate-900">
                <span>Depresiasi Per Bulan:</span>
                <span className="font-mono text-indigo-700">
                  {formatRupiah(Math.round((acquisitionCost - residualValue) / Math.max(1, usefulLifeMonths)))}
                </span>
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-600"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-semibold"
                >
                  Simpan Aset
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
