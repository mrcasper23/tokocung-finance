import React, { useState } from 'react';
import { useFinance } from '../../context/FinanceContext';
import { formatRupiah, downloadCSV } from '../../utils/formatters';
import { Plus, Users, Search, Phone, FileSpreadsheet, Eye } from 'lucide-react';
import { DebiturDetailModal } from '../modals/DebiturDetailModal';
import { KasbonDebitur as IDebitur } from '../../types/finance';

export const KasbonDebitur: React.FC = () => {
  const { debiturKasbon, addKasbonTransaction } = useFinance();
  const [searchTerm, setSearchTerm] = useState('');
  const [showApplyModal, setShowApplyModal] = useState(false);
  const [selectedDebiturDetail, setSelectedDebiturDetail] = useState<IDebitur | null>(null);

  // Apply Kasbon Form
  const [selectedDebiturId, setSelectedDebiturId] = useState(debiturKasbon[0]?.id || 'deb-01');
  const [amount, setAmount] = useState(1000000);
  const [purpose, setPurpose] = useState('');
  const [date, setDate] = useState('2026-03-26');

  const filtered = debiturKasbon.filter(d =>
    d.employeeName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    d.department.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const selectedDebitur = debiturKasbon.find(d => d.id === selectedDebiturId) || debiturKasbon[0];

  const handleApply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDebitur) return;

    addKasbonTransaction({
      debiturId: selectedDebitur.id,
      debiturName: selectedDebitur.employeeName,
      date,
      purpose,
      amount,
      repaidAmount: 0,
      remainingAmount: amount,
      status: 'Disetujui',
      isDemo: false,
    });

    setShowApplyModal(false);
    setPurpose('');
  };

  const handleExport = () => {
    const headers = ['Nama Karyawan', 'Departemen', 'Telepon', 'Plafon Maksimal', 'Saldo Kasbon Berjalan', 'Status'];
    const rows = filtered.map(d => [
      d.employeeName,
      d.department,
      d.phone,
      d.ceilingLimit,
      d.currentBalance,
      d.status
    ]);
    downloadCSV('Daftar_Debitur_Kasbon_TokoCung', headers, rows);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="bg-white border border-slate-200/90 rounded-xl p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Debitur Kasbon Karyawan</h1>
          <p className="text-xs text-slate-500 mt-1">
            Data karyawan terdaftar pemegang fasilitas pinjaman kasbon dengan batas plafon.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExport}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border border-slate-200 hover:bg-slate-50 text-slate-700 transition-colors cursor-pointer"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={() => setShowApplyModal(true)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white transition-colors cursor-pointer shadow-2xs"
          >
            <Plus className="w-4 h-4" />
            <span>+ Ajukan Kasbon Baru</span>
          </button>
        </div>
      </div>

      {/* Filter and Search */}
      <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-xs flex items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2 flex-1 max-w-sm border border-slate-200 rounded-lg px-2.5 py-1.5 bg-slate-50">
          <Search className="w-3.5 h-3.5 text-slate-400" />
          <input
            type="text"
            placeholder="Cari nama karyawan atau divisi..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full bg-transparent outline-none text-xs text-slate-800 placeholder-slate-400"
          />
        </div>
      </div>

      {/* Debitur Grid Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
        {filtered.map(d => {
          const usagePct = (d.currentBalance / d.ceilingLimit) * 100;

          return (
            <div
              key={d.id}
              onClick={() => setSelectedDebiturDetail(d)}
              className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs flex flex-col justify-between hover:border-blue-400 hover:shadow-md transition-all cursor-pointer group"
              title="Klik untuk melihat kartu piutang debitur lengkap"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <div className="w-8 h-8 rounded-full bg-slate-100 group-hover:bg-blue-100 group-hover:text-blue-700 transition-colors font-bold text-slate-700 flex items-center justify-center">
                    {d.employeeName.charAt(0)}
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200/50">
                      {d.status}
                    </span>
                    <Eye className="w-3.5 h-3.5 text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                </div>

                <div className="font-bold text-sm text-slate-900 group-hover:text-blue-700 transition-colors">{d.employeeName}</div>
                <div className="text-[11px] text-slate-500 mt-0.5">{d.department}</div>
                <div className="text-[11px] text-slate-400 flex items-center gap-1 mt-1">
                  <Phone className="w-3 h-3" />
                  <span>{d.phone}</span>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-500">Plafon Maksimal:</span>
                  <span className="font-semibold text-slate-800 font-mono">{formatRupiah(d.ceilingLimit)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Saldo Kasbon Aktif:</span>
                  <span className="font-bold text-amber-700 font-mono">{formatRupiah(d.currentBalance)}</span>
                </div>

                {/* Progress bar */}
                <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full ${usagePct > 70 ? 'bg-rose-500' : 'bg-slate-800'}`}
                    style={{ width: `${Math.min(100, usagePct)}%` }}
                  />
                </div>
                <div className="flex justify-between text-[10px]">
                  <span className="text-blue-600 font-medium opacity-0 group-hover:opacity-100 transition-opacity">Detail Kartu →</span>
                  <span className="text-slate-400">Terpakai {usagePct.toFixed(0)}%</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Debitur Detail Modal */}
      {selectedDebiturDetail && (
        <DebiturDetailModal
          debitur={selectedDebiturDetail}
          onClose={() => setSelectedDebiturDetail(null)}
        />
      )}

      {/* Modal Apply Kasbon */}
      {showApplyModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-md w-full p-6 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h3 className="text-sm font-bold text-slate-900">Pengajuan Kasbon Karyawan</h3>
              <button onClick={() => setShowApplyModal(false)} className="text-slate-400 hover:text-slate-600">✕</button>
            </div>

            <form onSubmit={handleApply} className="space-y-3">
              <div>
                <label className="block text-slate-600 font-medium mb-1">Pilih Karyawan (Debitur)</label>
                <select
                  value={selectedDebiturId}
                  onChange={e => setSelectedDebiturId(e.target.value)}
                  className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                >
                  {debiturKasbon.map(d => (
                    <option key={d.id} value={d.id}>
                      {d.employeeName} - {d.department} (Sisa Plafon: {formatRupiah(d.ceilingLimit - d.currentBalance)})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Tanggal</label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={e => setDate(e.target.value)}
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Nominal Pinjaman (Rp)</label>
                  <input
                    type="number"
                    step={100000}
                    required
                    value={amount}
                    onChange={e => setAmount(Number(e.target.value))}
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-600 font-medium mb-1">Keperluan Pinjaman (Darurat/Dinas)</label>
                <input
                  type="text"
                  required
                  value={purpose}
                  onChange={e => setPurpose(e.target.value)}
                  placeholder="Contoh: Kebutuhan darurat keluarga"
                  className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                />
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowApplyModal(false)}
                  className="px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-600"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-semibold"
                >
                  Setujui & Cairkan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
