import React, { useState } from 'react';
import { useFinance } from '../../context/FinanceContext';
import { formatRupiah, formatDate, downloadCSV } from '../../utils/formatters';
import { Plus, ArrowLeftRight, Search, FileSpreadsheet, ArrowDownLeft, ArrowUpRight, Eye } from 'lucide-react';
import { MutasiDetailModal } from '../modals/MutasiDetailModal';
import { CashMutation } from '../../types/finance';

export const MutasiKas: React.FC = () => {
  const { cashMutations, addCashMutation } = useFinance();
  const [searchTerm, setSearchTerm] = useState('');
  const [accountFilter, setAccountFilter] = useState('ALL');
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedMutation, setSelectedMutation] = useState<CashMutation | null>(null);

  // Form state
  const [date, setDate] = useState('2026-03-24');
  const [account, setAccount] = useState<'BCA Operasional' | 'Mandiri Bisnis' | 'Kas Kecil (Petty Cash)'>('Kas Kecil (Petty Cash)');
  const [type, setType] = useState<'Masuk' | 'Keluar'>('Keluar');
  const [category, setCategory] = useState('Operasional Harian Toko');
  const [amount, setAmount] = useState(500000);
  const [description, setDescription] = useState('');

  const filtered = cashMutations.filter(m => {
    const matchSearch =
      m.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      m.referenceNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      m.category.toLowerCase().includes(searchTerm.toLowerCase());
    const matchAccount = accountFilter === 'ALL' || m.account === accountFilter;
    return matchSearch && matchAccount;
  });

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    const ref = `MUT-${Date.now().toString().slice(-4)}`;
    addCashMutation({
      date,
      account,
      type,
      category,
      amount,
      balanceAfter: 15000000,
      description,
      referenceNumber: ref,
      isDemo: false,
    });
    setShowAddModal(false);
    setDescription('');
  };

  const handleExport = () => {
    const headers = ['Tanggal', 'Rekening/Akun Kas', 'Jenis Mutasi', 'Kategori', 'Nominal', 'Deskripsi', 'No. Referensi'];
    const rows = filtered.map(m => [
      m.date,
      m.account,
      m.type,
      m.category,
      m.amount,
      m.description,
      m.referenceNumber
    ]);
    downloadCSV('Laporan_Mutasi_Kas_TokoCung', headers, rows);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="bg-white border border-slate-200/90 rounded-xl p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Mutasi Kas & Rekening Bank</h1>
          <p className="text-xs text-slate-500 mt-1">
            Riwayat penerimaan dan pengeluaran kas real time untuk BCA, Mandiri, dan Petty Cash.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExport}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border border-slate-200 hover:bg-slate-50 text-slate-700 transition-colors cursor-pointer"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={() => setShowAddModal(true)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white transition-colors cursor-pointer shadow-2xs"
          >
            <Plus className="w-4 h-4" />
            <span>+ Catat Mutasi Kas</span>
          </button>
        </div>
      </div>

      {/* Filter and Search */}
      <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-xs flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2 flex-1 max-w-sm border border-slate-200 rounded-lg px-2.5 py-1.5 bg-slate-50">
          <Search className="w-3.5 h-3.5 text-slate-400" />
          <input
            type="text"
            placeholder="Cari transaksi mutasi, no ref, atau pos..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full bg-transparent outline-none text-xs text-slate-800 placeholder-slate-400"
          />
        </div>

        <div className="flex items-center gap-2">
          <span className="text-slate-500 font-medium">Akun Kas:</span>
          <select
            value={accountFilter}
            onChange={e => setAccountFilter(e.target.value)}
            className="border border-slate-200 rounded-lg px-2 py-1 text-xs text-slate-700 bg-white"
          >
            <option value="ALL">Semua Akun Rekening</option>
            <option value="BCA Operasional">BCA Operasional</option>
            <option value="Mandiri Bisnis">Mandiri Bisnis</option>
            <option value="Kas Kecil (Petty Cash)">Kas Kecil (Petty Cash)</option>
          </select>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                <th className="py-3 px-3">Tanggal</th>
                <th className="py-3 px-3">Akun Rekening</th>
                <th className="py-3 px-3">Tipe</th>
                <th className="py-3 px-3">Kategori Mutasi</th>
                <th className="py-3 px-3">Keterangan</th>
                <th className="py-3 px-3 text-right">Nominal</th>
                <th className="py-3 px-3">No. Referensi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map(m => (
                <tr
                  key={m.id}
                  onClick={() => setSelectedMutation(m)}
                  className="hover:bg-slate-50/90 transition-colors cursor-pointer group"
                >
                  <td className="py-2.5 px-3 text-slate-600">{formatDate(m.date)}</td>
                  <td className="py-2.5 px-3 font-semibold text-slate-900">{m.account}</td>
                  <td className="py-2.5 px-3">
                    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold ${
                      m.type === 'Masuk' ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'
                    }`}>
                      {m.type === 'Masuk' ? <ArrowDownLeft className="w-3 h-3" /> : <ArrowUpRight className="w-3 h-3" />}
                      {m.type}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-slate-700 font-medium">{m.category}</td>
                  <td className="py-2.5 px-3 text-slate-600 max-w-[240px] truncate">{m.description}</td>
                  <td className={`py-2.5 px-3 text-right font-mono font-bold tabular-nums ${
                    m.type === 'Masuk' ? 'text-emerald-700' : 'text-rose-700'
                  }`}>
                    {m.type === 'Masuk' ? `+${formatRupiah(m.amount)}` : `-${formatRupiah(m.amount)}`}
                  </td>
                  <td className="py-2.5 px-3 font-mono text-slate-500 text-[11px]">
                    <div className="flex items-center gap-1.5 group-hover:text-blue-700">
                      <span>{m.referenceNumber}</span>
                      <Eye className="w-3.5 h-3.5 text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Mutasi Detail Modal */}
      {selectedMutation && (
        <MutasiDetailModal
          mutation={selectedMutation}
          onClose={() => setSelectedMutation(null)}
        />
      )}

      {/* Modal Add Cash Mutation */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-md w-full p-6 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h3 className="text-sm font-bold text-slate-900">Catat Mutasi Kas Baru</h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-600">✕</button>
            </div>

            <form onSubmit={handleCreate} className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Tanggal</label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={e => setDate(e.target.value)}
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Akun Kas / Bank</label>
                  <select
                    value={account}
                    onChange={e => setAccount(e.target.value as any)}
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                  >
                    <option value="BCA Operasional">BCA Operasional</option>
                    <option value="Mandiri Bisnis">Mandiri Bisnis</option>
                    <option value="Kas Kecil (Petty Cash)">Kas Kecil (Petty Cash)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Tipe Mutasi</label>
                  <select
                    value={type}
                    onChange={e => setType(e.target.value as any)}
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                  >
                    <option value="Keluar">Keluar (Kas Out)</option>
                    <option value="Masuk">Masuk (Kas In)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Nominal (Rp)</label>
                  <input
                    type="number"
                    step={10000}
                    required
                    value={amount}
                    onChange={e => setAmount(Number(e.target.value))}
                    className="w-full border border-slate-200 rounded-lg p-2 text-xs font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-600 font-medium mb-1">Kategori Pos</label>
                <input
                  type="text"
                  required
                  value={category}
                  onChange={e => setCategory(e.target.value)}
                  className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                />
              </div>

              <div>
                <label className="block text-slate-600 font-medium mb-1">Keterangan</label>
                <input
                  type="text"
                  required
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  placeholder="Detail keperluan transaksi..."
                  className="w-full border border-slate-200 rounded-lg p-2 text-xs"
                />
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-600"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-semibold"
                >
                  Simpan Mutasi
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
