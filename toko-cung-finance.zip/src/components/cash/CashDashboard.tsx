import React from 'react';
import { useFinance } from '../../context/FinanceContext';
import { formatRupiah, formatCompactRupiah, formatDate } from '../../utils/formatters';
import { StatCard } from '../common/StatCard';
import { Wallet, ArrowDownRight, ArrowUpRight, Users, CreditCard } from 'lucide-react';

export const CashDashboard: React.FC = () => {
  const { debiturKasbon, kasbonTransactions, cashMutations, cashFlowStatement } = useFinance();

  const totalOutstandingKasbon = debiturKasbon.reduce((s, d) => s + d.currentBalance, 0);
  const activeDebiturCount = debiturKasbon.filter(d => d.currentBalance > 0).length;

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="bg-white border border-slate-200/90 rounded-xl p-5 shadow-xs">
        <h1 className="text-xl font-bold text-slate-900 tracking-tight">Dashboard Kas & Kasbon Internal</h1>
        <p className="text-xs text-slate-500 mt-1">
          Monitoring likuiditas kas bank, brankas toko, dan piutang pinjaman karyawan (Kasbon).
        </p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Saldo Kas & Bank Total"
          value={formatCompactRupiah(cashFlowStatement.endingCash)}
          subtitle={formatRupiah(cashFlowStatement.endingCash)}
          indicatorText="Tersedia di BCA, Mandiri & Kas"
          icon={<Wallet className="w-4 h-4" />}
        />
        <StatCard
          title="Total Piutang Kasbon"
          value={formatCompactRupiah(totalOutstandingKasbon)}
          subtitle={formatRupiah(totalOutstandingKasbon)}
          indicatorText={`${activeDebiturCount} Karyawan Aktif Meminjam`}
          icon={<CreditCard className="w-4 h-4 text-amber-600" />}
        />
        <StatCard
          title="Jumlah Debitur Terdaftar"
          value={`${debiturKasbon.length} Orang`}
          subtitle="Plafon Pinjaman Disetujui"
          indicatorText="Semua Terverifikasi"
          icon={<Users className="w-4 h-4" />}
        />
        <StatCard
          title="Pengajuan Kasbon Bulan Ini"
          value={`${kasbonTransactions.length} Transaksi`}
          subtitle="Status Aktif & Pelunasan"
          indicatorText="Tercatat di Mutasi Kas"
          icon={<Wallet className="w-4 h-4" />}
        />
      </div>

      {/* Mutasi Terakhir & Daftar Debitur */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Rekening Kas & Saldo */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
          <h2 className="text-sm font-bold text-slate-900 mb-3">Rekening Bank & Pos Kas</h2>
          <div className="space-y-3 text-xs">
            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg flex justify-between items-center">
              <div>
                <div className="font-bold text-slate-900">BCA Operasional (Bisnis Giro)</div>
                <div className="text-[11px] text-slate-500 font-mono">No. Rek: 001-2993881</div>
              </div>
              <div className="text-right">
                <div className="font-bold text-slate-900 font-mono text-sm">Rp 601.000.000</div>
                <div className="text-[10px] text-emerald-600">Aktif Operasional</div>
              </div>
            </div>

            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg flex justify-between items-center">
              <div>
                <div className="font-bold text-slate-900">Mandiri Bisnis (Escrow & Pajak)</div>
                <div className="text-[11px] text-slate-500 font-mono">No. Rek: 118-0098231</div>
              </div>
              <div className="text-right">
                <div className="font-bold text-slate-900 font-mono text-sm">Rp 312.200.000</div>
                <div className="text-[10px] text-emerald-600">Penyimpanan Cadangan</div>
              </div>
            </div>

            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg flex justify-between items-center">
              <div>
                <div className="font-bold text-slate-900">Kas Kecil (Petty Cash Kantor & Toko)</div>
                <div className="text-[11px] text-slate-500 font-mono">Brankas Kasir Pusat</div>
              </div>
              <div className="text-right">
                <div className="font-bold text-slate-900 font-mono text-sm">Rp 14.200.000</div>
                <div className="text-[10px] text-blue-600">Kas Harian</div>
              </div>
            </div>
          </div>
        </div>

        {/* Debitur Kasbon Top Outstanding */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
          <h2 className="text-sm font-bold text-slate-900 mb-3">Debitur Kasbon Aktif</h2>
          <div className="space-y-2.5 text-xs">
            {debiturKasbon.map(d => (
              <div key={d.id} className="p-3 border border-slate-200 rounded-lg flex items-center justify-between">
                <div>
                  <div className="font-bold text-slate-800">{d.employeeName}</div>
                  <div className="text-[11px] text-slate-500">{d.department} · Plafon: {formatCompactRupiah(d.ceilingLimit)}</div>
                </div>
                <div className="text-right">
                  <div className="font-bold font-mono text-slate-900 tabular-nums">
                    {formatRupiah(d.currentBalance)}
                  </div>
                  <div className={`text-[10px] font-medium ${d.currentBalance > 0 ? 'text-amber-600' : 'text-emerald-600'}`}>
                    {d.currentBalance > 0 ? 'Ada Tagihan' : 'Lunas'}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
