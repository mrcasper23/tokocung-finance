import React, { useState } from 'react';
import { useFinance } from '../../context/FinanceContext';
import { formatRupiah, formatDate, downloadCSV } from '../../utils/formatters';
import { CheckCircle2, DollarSign, Search, FileSpreadsheet, Eye } from 'lucide-react';
import { KasbonDetailModal } from '../modals/KasbonDetailModal';
import { KasbonTransaction } from '../../types/finance';

export const KasbonPelunasan: React.FC = () => {
  const { kasbonTransactions, repayKasbon } = useFinance();
  const [searchTerm, setSearchTerm] = useState('');
  const [repayModalTx, setRepayModalTx] = useState<any | null>(null);
  const [repayAmount, setRepayAmount] = useState(500000);
  const [selectedDetailTx, setSelectedDetailTx] = useState<KasbonTransaction | null>(null);

  const filtered = kasbonTransactions.filter(tx =>
    tx.debiturName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    tx.transactionNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
    tx.purpose.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleRepay = (e: React.FormEvent) => {
    e.preventDefault();
    if (!repayModalTx) return;

    repayKasbon(repayModalTx.id, repayAmount);
    setRepayModalTx(null);
  };

  const handleExport = () => {
    const headers = ['No Kasbon', 'Nama Debitur', 'Tanggal Pinjam', 'Tujuan', 'Total Pinjaman', 'Sudah Dicicil', 'Sisa Tagihan', 'Status'];
    const rows = filtered.map(k => [
      k.transactionNumber,
      k.debiturName,
      k.date,
      k.purpose,
      k.amount,
      k.repaidAmount,
      k.remainingAmount,
      k.status
    ]);
    downloadCSV('Riwayat_Pelunasan_Kasbon_TokoCung', headers, rows);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="bg-white border border-slate-200/90 rounded-xl p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Pelunasan & Angsuran Kasbon</h1>
          <p className="text-xs text-slate-500 mt-1">
            Pencatatan angsuran cicilan pinjaman karyawan atau pelunasan penuh via tunai maupun potong gaji.
          </p>
        </div>

        <button
          onClick={handleExport}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border border-slate-200 hover:bg-slate-50 text-slate-700 transition-colors cursor-pointer"
        >
          <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
          <span>Export CSV</span>
        </button>
      </div>

      {/* Filter and Search */}
      <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-xs flex items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2 flex-1 max-w-sm border border-slate-200 rounded-lg px-2.5 py-1.5 bg-slate-50">
          <Search className="w-3.5 h-3.5 text-slate-400" />
          <input
            type="text"
            placeholder="Cari transaksi kasbon atau debitur..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full bg-transparent outline-none text-xs text-slate-800 placeholder-slate-400"
          />
        </div>
      </div>

      {/* Table */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                <th className="py-3 px-3">No. Kasbon</th>
                <th className="py-3 px-3">Tanggal</th>
                <th className="py-3 px-3">Nama Karyawan (Debitur)</th>
                <th className="py-3 px-3">Keperluan Pinjaman</th>
                <th className="py-3 px-3 text-right">Pokok Pinjaman</th>
                <th className="py-3 px-3 text-right">Sudah Dibayar</th>
                <th className="py-3 px-3 text-right">Sisa Tagihan</th>
                <th className="py-3 px-3 text-center">Status</th>
                <th className="py-3 px-3 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map(tx => (
                <tr
                  key={tx.id}
                  onClick={() => setSelectedDetailTx(tx)}
                  className="hover:bg-slate-50/90 transition-colors cursor-pointer group"
                >
                  <td className="py-2.5 px-3 font-semibold text-slate-900 font-mono">
                    <div className="flex items-center gap-1.5 group-hover:text-blue-700">
                      <span>{tx.transactionNumber}</span>
                      <Eye className="w-3.5 h-3.5 text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                  </td>
                  <td className="py-2.5 px-3 text-slate-600">{formatDate(tx.date)}</td>
                  <td className="py-2.5 px-3 font-bold text-slate-900">{tx.debiturName}</td>
                  <td className="py-2.5 px-3 text-slate-600">{tx.purpose}</td>
                  <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-700">{formatRupiah(tx.amount)}</td>
                  <td className="py-2.5 px-3 text-right font-mono tabular-nums text-emerald-700">{formatRupiah(tx.repaidAmount)}</td>
                  <td className="py-2.5 px-3 text-right font-mono font-bold tabular-nums text-rose-700">{formatRupiah(tx.remainingAmount)}</td>
                  <td className="py-2.5 px-3 text-center">
                    <span className={`px-2 py-0.5 rounded text-[11px] font-medium ${
                      tx.status === 'Lunas'
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200/50'
                        : 'bg-amber-50 text-amber-700 border border-amber-200/50'
                    }`}>
                      {tx.status}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-right" onClick={e => e.stopPropagation()}>
                    {tx.remainingAmount > 0 ? (
                      <button
                        onClick={() => {
                          setRepayModalTx(tx);
                          setRepayAmount(Math.min(500000, tx.remainingAmount));
                        }}
                        className="px-2.5 py-1 rounded bg-slate-900 hover:bg-slate-800 text-white font-medium text-[11px] cursor-pointer"
                      >
                        Pelunasan / Cicil
                      </button>
                    ) : (
                      <span className="text-[11px] text-emerald-600 font-medium flex items-center justify-end gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Lunas Penuh
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Kasbon Detail Modal */}
      {selectedDetailTx && (
        <KasbonDetailModal
          transaction={selectedDetailTx}
          onClose={() => setSelectedDetailTx(null)}
          onOpenRepay={() => {
            setRepayModalTx(selectedDetailTx);
            setRepayAmount(Math.min(500000, selectedDetailTx.remainingAmount));
          }}
        />
      )}

      {/* Modal Repay */}
      {repayModalTx && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-sm w-full p-6 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h3 className="text-sm font-bold text-slate-900">Input Pembayaran Angsuran Kasbon</h3>
              <button onClick={() => setRepayModalTx(null)} className="text-slate-400 hover:text-slate-600">✕</button>
            </div>

            <form onSubmit={handleRepay} className="space-y-3">
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg space-y-1">
                <div className="text-slate-500">Debitur: <strong className="text-slate-800">{repayModalTx.debiturName}</strong></div>
                <div className="text-slate-500">No. Pinjaman: <strong className="font-mono text-slate-800">{repayModalTx.transactionNumber}</strong></div>
                <div className="text-slate-500">Sisa Tagihan: <strong className="font-mono text-rose-700">{formatRupiah(repayModalTx.remainingAmount)}</strong></div>
              </div>

              <div>
                <label className="block text-slate-600 font-medium mb-1">Nominal Pembayaran (Rp)</label>
                <input
                  type="number"
                  step={50000}
                  min={10000}
                  max={repayModalTx.remainingAmount}
                  required
                  value={repayAmount}
                  onChange={e => setRepayAmount(Number(e.target.value))}
                  className="w-full border border-slate-200 rounded-lg p-2 text-xs font-mono"
                />
              </div>

              <div className="flex justify-between text-xs pt-1">
                <button
                  type="button"
                  onClick={() => setRepayAmount(repayModalTx.remainingAmount)}
                  className="text-xs text-indigo-600 hover:underline font-medium"
                >
                  Lunasi Sekaligus ({formatRupiah(repayModalTx.remainingAmount)})
                </button>
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setRepayModalTx(null)}
                  className="px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-600"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-semibold"
                >
                  Konfirmasi Pembayaran
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
