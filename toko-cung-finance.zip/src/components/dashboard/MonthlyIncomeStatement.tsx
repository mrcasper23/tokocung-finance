import React, { useState } from 'react';
import { useFinance } from '../../context/FinanceContext';
import { MONTH_SHORT_ID, formatRupiah, formatPercent, downloadCSV, printReport } from '../../utils/formatters';
import { FileSpreadsheet, Printer, ShieldCheck, ChevronRight, ChevronDown, Info, MousePointerClick } from 'lucide-react';
import { PnlDrilldownModal } from '../modals/PnlDrilldownModal';

export const MonthlyIncomeStatement: React.FC = () => {
  const { monthlyPnlTable, globalFilter, entities, opex, settings } = useFinance();
  const [showOpexDetails, setShowOpexDetails] = useState(false);
  const [drilldownTarget, setDrilldownTarget] = useState<{
    rowLabel: string;
    rowLevel?: string;
    monthIndex?: number | null;
    value: number;
  } | null>(null);

  const activeEntityName =
    globalFilter.entityId === 'ALL'
      ? 'Konsolidasi Seluruh Entitas'
      : entities.find(e => e.id === globalFilter.entityId)?.name || 'Entitas Terpilih';

  const handleExport = () => {
    const headers = ['Pos Laporan Laba Rugi', ...MONTH_SHORT_ID, 'YTD (Total)'];
    const rows = monthlyPnlTable.map(r => [
      r.label,
      ...r.values.map(v => (r.isPercentage ? `${v.toFixed(1)}%` : Math.round(v))),
      r.isPercentage ? `${r.ytd.toFixed(1)}%` : Math.round(r.ytd),
    ]);
    downloadCSV(`Monthly_Income_Statement_${globalFilter.year}`, headers, rows);
  };

  return (
    <div className="space-y-6 pb-12 print-full-width">
      {/* Top Header Card */}
      <div className="bg-white border border-slate-200/90 rounded-xl p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-900 tracking-tight">
              Monthly Income Statement (Laporan Laba Rugi)
            </h1>
            <span className="text-xs font-semibold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800">
              Formula Resmi
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Entitas: <span className="font-semibold text-slate-700">{activeEntityName}</span> · Tahun Buku: <span className="font-semibold text-slate-700">{globalFilter.year}</span> · Tarif Pajak Badan: <span className="font-semibold text-slate-700">{settings.taxRatePercent}%</span>
          </p>
        </div>

        <div className="flex items-center gap-2 no-print">
          <button
            onClick={() => setShowOpexDetails(!showOpexDetails)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-700 transition-colors cursor-pointer"
          >
            {showOpexDetails ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
            <span>{showOpexDetails ? 'Sembunyikan Rincian OPEX' : 'Tampilkan Rincian OPEX'}</span>
          </button>
          <button
            onClick={handleExport}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-slate-900 hover:bg-slate-800 text-white transition-colors cursor-pointer shadow-2xs"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>Export Excel</span>
          </button>
          <button
            onClick={printReport}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Cetak PDF</span>
          </button>
        </div>
      </div>

      {/* Accounting Compliance Rule Banner */}
      <div className="bg-slate-900 text-slate-200 rounded-xl p-4 shadow-xs text-xs flex items-start gap-3 border border-slate-800 no-print">
        <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
        <div className="leading-relaxed">
          <div className="font-semibold text-white">Alur Formula Akuntansi Internal Toko Cung</div>
          <div className="text-slate-300 font-mono text-[11px] mt-1 overflow-x-auto whitespace-nowrap">
            SALES → HPP → GROSS PROFIT → OPEX → EBITDA → DEPRECIATION → EBIT / MANAGEMENT PROFIT → NON-OPERATING → EBT → INCOME TAX → NET PROFIT
          </div>
          <div className="text-slate-400 text-[11px] mt-1">
            *Pengeluaran CAPEX tidak mengurangi Laba Bersih langsung pada periode berjalan, melainkan dikapitalisasi ke Asset Register dan diamortisasi sebagai beban depresiasi bulanan.
          </div>
        </div>
      </div>

      {/* Click hint banner */}
      <div className="bg-blue-50/80 border border-blue-200/90 rounded-xl p-3 flex items-center justify-between gap-3 text-xs text-blue-900 shadow-2xs no-print">
        <div className="flex items-center gap-2">
          <div className="p-1 rounded bg-blue-600 text-white shrink-0">
            <MousePointerClick className="w-3.5 h-3.5" />
          </div>
          <span>
            <strong>Klik untuk Rincian Transaksi:</strong> Klik nama komponen atau angka bulan mana saja untuk memeriksa transaksi riil pembentuk angka tersebut.
          </span>
        </div>
        <span className="text-[11px] font-semibold text-blue-700 shrink-0 hidden sm:inline">
          Drill-Down Siap
        </span>
      </div>

      {/* Horizontal Spreadsheet-style Income Statement Table */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="bg-slate-100/80 border-b border-slate-200 text-slate-700">
                <th className="py-3 px-4 font-bold text-slate-900 sticky left-0 bg-slate-100 z-10 min-w-[260px]">
                  Komponen Laba Rugi
                </th>
                {MONTH_SHORT_ID.map((mName, idx) => (
                  <th key={idx} className="py-3 px-2.5 text-right font-semibold min-w-[100px] tabular-nums">
                    {mName}
                  </th>
                ))}
                <th className="py-3 px-3 text-right font-bold text-slate-950 bg-slate-200/70 min-w-[125px] tabular-nums">
                  YTD 2026
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {monthlyPnlTable.map((row, idx) => {
                const isTotalRow = row.isTotal;
                const isHeaderRow = row.isHeader;
                const isPct = row.isPercentage;

                let rowClass = 'hover:bg-slate-50/80 transition-colors';
                let labelClass = 'text-slate-700';

                if (isHeaderRow) {
                  rowClass = 'bg-slate-50/60 font-bold';
                  labelClass = 'font-bold text-slate-950';
                } else if (isTotalRow) {
                  rowClass = 'bg-slate-50 font-semibold';
                  labelClass = 'font-bold text-slate-900';
                }

                if (row.level === 'net_profit') {
                  rowClass = 'bg-emerald-50/60 font-bold border-y-2 border-emerald-400';
                  labelClass = 'text-emerald-950 font-bold';
                }

                return (
                  <tr key={idx} className={rowClass}>
                    {/* Row Label (Clickable for YTD drilldown) */}
                    <td
                      onClick={() =>
                        !isPct &&
                        setDrilldownTarget({
                          rowLabel: row.label,
                          rowLevel: row.level,
                          monthIndex: null,
                          value: row.ytd,
                        })
                      }
                      className={`py-2.5 px-4 sticky left-0 bg-inherit z-10 ${labelClass} ${
                        !isPct ? 'cursor-pointer hover:text-blue-700 group/label' : ''
                      }`}
                      title={!isPct ? `Klik untuk melihat rincian YTD ${row.label}` : undefined}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          {row.isIndent && <span className="w-3" />}
                          <span className={isTotalRow || isHeaderRow ? 'font-bold' : ''}>
                            {row.label}
                          </span>
                        </div>
                        {!isPct && (
                          <span className="text-[10px] text-blue-500 opacity-0 group-hover/label:opacity-100 transition-opacity">
                            detail →
                          </span>
                        )}
                      </div>
                    </td>

                    {/* 12 Months Columns (Clickable for that month's drilldown) */}
                    {row.values.map((val, mIdx) => {
                      const isNegative = val < 0;
                      let textColor = 'text-slate-700';

                      if (isPct) {
                        textColor = val >= 15 ? 'text-emerald-700 font-semibold' : 'text-slate-600';
                      } else if (isNegative) {
                        textColor = 'text-rose-600 font-medium';
                      } else if (row.level === 'net_profit') {
                        textColor = 'text-emerald-900 font-bold';
                      }

                      return (
                        <td
                          key={mIdx}
                          onClick={() =>
                            !isPct &&
                            setDrilldownTarget({
                              rowLabel: row.label,
                              rowLevel: row.level,
                              monthIndex: mIdx,
                              value: val,
                            })
                          }
                          className={`py-2.5 px-2.5 text-right font-mono tabular-nums text-[11px] ${textColor} ${
                            !isPct
                              ? 'cursor-pointer hover:bg-blue-100/60 hover:text-blue-900 hover:font-bold transition-all'
                              : ''
                          }`}
                          title={
                            !isPct
                              ? `Klik untuk rincian ${row.label} (${MONTH_SHORT_ID[mIdx]})`
                              : undefined
                          }
                        >
                          {isPct ? formatPercent(val) : formatRupiah(val, false)}
                        </td>
                      );
                    })}

                    {/* YTD Total Column (Clickable for YTD drilldown) */}
                    <td
                      onClick={() =>
                        !isPct &&
                        setDrilldownTarget({
                          rowLabel: row.label,
                          rowLevel: row.level,
                          monthIndex: null,
                          value: row.ytd,
                        })
                      }
                      className={`py-2.5 px-3 text-right font-mono tabular-nums text-[11px] bg-slate-100/60 font-bold ${
                        row.level === 'net_profit'
                          ? 'text-emerald-950 bg-emerald-100/50'
                          : 'text-slate-900'
                      } ${
                        !isPct
                          ? 'cursor-pointer hover:bg-blue-100/80 hover:text-blue-900 transition-all'
                          : ''
                      }`}
                      title={!isPct ? `Klik untuk rincian YTD ${row.label}` : undefined}
                    >
                      {isPct ? formatPercent(row.ytd) : formatRupiah(row.ytd, true)}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* RENDER PNL DRILLDOWN MODAL */}
      {drilldownTarget && (
        <PnlDrilldownModal
          rowLabel={drilldownTarget.rowLabel}
          rowLevel={drilldownTarget.rowLevel}
          monthIndex={drilldownTarget.monthIndex}
          value={drilldownTarget.value}
          year={globalFilter.year}
          onClose={() => setDrilldownTarget(null)}
        />
      )}

      {/* Optional Rincian OPEX Breakdown per Bulan */}
      {showOpexDetails && (
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Rincian Komposisi Biaya Operasional (OPEX)</h3>
              <p className="text-xs text-slate-500">Breakdown per pos pengeluaran bulanan</p>
            </div>
            <span className="text-xs text-slate-500 font-mono">14 Kategori Operasional</span>
          </div>

          <div className="overflow-x-auto text-xs">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600">
                  <th className="py-2 px-3 font-semibold">Kategori OPEX</th>
                  <th className="py-2 px-3 text-right">Rata-rata/Bulan</th>
                  <th className="py-2 px-3 text-right">Total Realisasi 2026</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {['Gaji', 'Utilities', 'Advertisement', 'Logistik', 'Maintenance', 'Server', 'ATK', 'Internet', 'Other Operating Expenses'].map(cat => {
                  const totalCat = opex.filter(o => o.category === cat).reduce((s, o) => s + o.total, 0);
                  const avgCat = totalCat / 12;

                  return (
                    <tr key={cat} className="hover:bg-slate-50">
                      <td className="py-2 px-3 font-medium text-slate-800">{cat}</td>
                      <td className="py-2 px-3 text-right font-mono tabular-nums text-slate-600">
                        {formatRupiah(avgCat)}
                      </td>
                      <td className="py-2 px-3 text-right font-mono tabular-nums font-semibold text-slate-900">
                        {formatRupiah(totalCat)}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
