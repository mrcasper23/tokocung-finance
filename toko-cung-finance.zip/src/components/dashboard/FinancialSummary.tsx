import React, { useState } from 'react';
import { useFinance } from '../../context/FinanceContext';
import { formatCompactRupiah, formatPercent, formatRupiah } from '../../utils/formatters';
import { StatCard } from '../common/StatCard';
import { Scale, TrendingUp, Percent, Activity, Landmark, ShieldCheck, PieChart, MousePointerClick } from 'lucide-react';
import { KpiDetailModal, KpiMetricType } from '../modals/KpiDetailModal';

export const FinancialSummary: React.FC = () => {
  const { currentMonthPnl, yearlyPnlSummary, globalFilter, cashFlowStatement } = useFinance();
  const [kpiModalMetric, setKpiModalMetric] = useState<KpiMetricType | null>(null);

  const isYtd = globalFilter.period === 'YTD';
  const pnl = isYtd ? yearlyPnlSummary : currentMonthPnl;

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="bg-white border border-slate-200/90 rounded-xl p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Ringkasan Keuangan (Financial Summary)</h1>
          <p className="text-xs text-slate-500 mt-1">
            Analisis rasio keuangan kunci, efisiensi operasional, margin profitabilitas, dan likuiditas Toko Cung.
          </p>
        </div>
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-blue-50 text-blue-800 text-[11px] font-semibold border border-blue-200/60 shrink-0">
          <MousePointerClick className="w-3.5 h-3.5 text-blue-600" />
          <span>Klik kartu rasio / baris untuk detail</span>
        </div>
      </div>

      {/* Ratios Matrix */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Gross Profit Margin"
          value={formatPercent(pnl.grossMarginPct)}
          subtitle="Efisiensi HPP terhadap Sales"
          indicatorText="Target Industri: >18%"
          icon={<Percent className="w-4 h-4" />}
          onClick={() => setKpiModalMetric('gross_profit')}
        />
        <StatCard
          title="EBITDA Margin"
          value={formatPercent(pnl.ebitdaMarginPct)}
          subtitle="Margin Operasional sebelum Depresiasi"
          indicatorText="Sehat & Positif"
          icon={<TrendingUp className="w-4 h-4" />}
          onClick={() => setKpiModalMetric('ebitda')}
        />
        <StatCard
          title="Net Profit Margin"
          value={formatPercent(pnl.netProfitMarginPct)}
          subtitle="Laba Bersih Akhir terhadap Revenue"
          indicatorText="Bottom Line Sehat"
          icon={<Scale className="w-4 h-4" />}
          onClick={() => setKpiModalMetric('net_profit')}
        />
        <StatCard
          title="Operating Cash Flow Ratio"
          value={formatCompactRupiah(cashFlowStatement.operatingCashFlow.total)}
          subtitle="Arus Kas Operasional Berjalan"
          indicatorText="Likuiditas Positif"
          icon={<Activity className="w-4 h-4" />}
          onClick={() => setKpiModalMetric('cash_bank')}
        />
      </div>

      {/* Comparison Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Ringkasan Laba Rugi Eksekutif */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
          <h2 className="text-sm font-bold text-slate-900 mb-1">Struktur Neraca Keuntungan</h2>
          <p className="text-xs text-slate-500 mb-4">Penguraian dari Penjualan hingga Net Profit (klik baris mana saja untuk rincian)</p>

          <div className="space-y-2.5 text-xs">
            <div
              onClick={() => setKpiModalMetric('sales')}
              className="flex justify-between py-1.5 px-2 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer border-b border-slate-100 group"
            >
              <span className="text-slate-600 group-hover:text-blue-700 font-medium">Penjualan Bersih (Sales) →</span>
              <span className="font-bold text-slate-900 tabular-nums">{formatRupiah(pnl.sales)}</span>
            </div>
            <div
              onClick={() => setKpiModalMetric('gross_profit')}
              className="flex justify-between py-1.5 px-2 rounded-lg hover:bg-rose-50 transition-colors cursor-pointer border-b border-slate-100 text-rose-700 group"
            >
              <span className="group-hover:font-semibold">Beban Pokok Penjualan (HPP) →</span>
              <span className="font-semibold tabular-nums">-{formatRupiah(pnl.hpp)}</span>
            </div>
            <div
              onClick={() => setKpiModalMetric('gross_profit')}
              className="flex justify-between py-1.5 border-b border-slate-100 font-semibold bg-slate-50 px-2 rounded hover:bg-blue-50 transition-colors cursor-pointer group"
            >
              <span className="text-slate-800 group-hover:text-blue-800">Laba Kotor (Gross Profit) →</span>
              <span className="text-slate-900 tabular-nums">{formatRupiah(pnl.grossProfit)}</span>
            </div>
            <div
              onClick={() => setKpiModalMetric('opex')}
              className="flex justify-between py-1.5 px-2 rounded-lg hover:bg-amber-50 transition-colors cursor-pointer border-b border-slate-100 text-amber-700 group"
            >
              <span className="group-hover:font-semibold">Beban Operasional (OPEX) →</span>
              <span className="font-semibold tabular-nums">-{formatRupiah(pnl.totalOpex)}</span>
            </div>
            <div
              onClick={() => setKpiModalMetric('ebitda')}
              className="flex justify-between py-1.5 border-b border-slate-100 font-semibold bg-slate-50 px-2 rounded hover:bg-emerald-50 transition-colors cursor-pointer group"
            >
              <span className="text-slate-800 group-hover:text-emerald-800">EBITDA →</span>
              <span className="text-slate-900 tabular-nums">{formatRupiah(pnl.ebitda)}</span>
            </div>
            <div
              onClick={() => setKpiModalMetric('ebit')}
              className="flex justify-between py-1.5 px-2 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer border-b border-slate-100 text-slate-600 group"
            >
              <span className="group-hover:text-slate-900">Beban Penyusutan (Depresiasi) →</span>
              <span className="font-medium tabular-nums">-{formatRupiah(pnl.totalDepreciation)}</span>
            </div>
            <div
              onClick={() => setKpiModalMetric('ebit')}
              className="flex justify-between py-1.5 px-2 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer border-b border-slate-100 font-semibold group"
            >
              <span className="text-slate-800 group-hover:text-slate-900">EBIT / Management Profit →</span>
              <span className="text-slate-900 tabular-nums">{formatRupiah(pnl.ebit)}</span>
            </div>
            <div
              onClick={() => setKpiModalMetric('ebt')}
              className="flex justify-between py-1.5 px-2 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer border-b border-slate-100 text-slate-600 group"
            >
              <span className="group-hover:text-slate-900">Pendapatan / (Beban) Non-Operasional Bersih →</span>
              <span className="font-medium tabular-nums">{formatRupiah(pnl.netNonOperating)}</span>
            </div>
            <div
              onClick={() => setKpiModalMetric('ebt')}
              className="flex justify-between py-1.5 px-2 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer border-b border-slate-100 font-semibold group"
            >
              <span className="text-slate-800 group-hover:text-slate-900">Laba Sebelum Pajak (EBT) →</span>
              <span className="text-slate-900 tabular-nums">{formatRupiah(pnl.ebt)}</span>
            </div>
            <div
              onClick={() => setKpiModalMetric('net_profit')}
              className="flex justify-between py-1.5 px-2 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer border-b border-slate-100 text-slate-600 group"
            >
              <span className="group-hover:text-slate-900">Estimasi Pajak Penghasilan Badan →</span>
              <span className="font-medium tabular-nums">-{formatRupiah(pnl.taxExpense)}</span>
            </div>
            <div
              onClick={() => setKpiModalMetric('net_profit')}
              className="flex justify-between py-2 px-2 rounded bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 font-bold text-emerald-950 transition-colors cursor-pointer group"
            >
              <span className="flex items-center gap-1">
                <span>Laba Bersih Tahun Berjalan (Net Profit)</span>
                <span className="text-[10px] text-emerald-700 font-normal opacity-0 group-hover:opacity-100 transition-opacity">→ detail</span>
              </span>
              <span className="tabular-nums">{formatRupiah(pnl.netProfit)}</span>
            </div>
          </div>
        </div>

        {/* Status Arus Kas & Likuiditas */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs flex flex-col justify-between">
          <div>
            <h2 className="text-sm font-bold text-slate-900 mb-1">Status Arus Kas Terintegrasi</h2>
            <p className="text-xs text-slate-500 mb-4">Pemisahan arus kas operasi, investasi (CAPEX), dan pendanaan</p>

            <div className="space-y-3 text-xs">
              <div className="p-3 rounded-lg border border-slate-200 bg-slate-50 flex justify-between items-center">
                <span className="text-slate-700 font-medium">Saldo Kas Awal Periode</span>
                <span className="font-bold text-slate-900 tabular-nums">{formatRupiah(cashFlowStatement.beginningCash)}</span>
              </div>
              <div className="p-3 rounded-lg border border-emerald-200 bg-emerald-50/50 flex justify-between items-center">
                <span className="text-emerald-900 font-medium">Arus Kas Operasi (OCF)</span>
                <span className="font-bold text-emerald-700 tabular-nums">+{formatRupiah(cashFlowStatement.operatingCashFlow.total)}</span>
              </div>
              <div className="p-3 rounded-lg border border-amber-200 bg-amber-50/50 flex justify-between items-center">
                <span className="text-amber-900 font-medium">Arus Kas Investasi (CAPEX Belanja Modal)</span>
                <span className="font-bold text-amber-800 tabular-nums">{formatRupiah(cashFlowStatement.investingCashFlow.total)}</span>
              </div>
              <div className="p-3 rounded-lg border border-blue-200 bg-blue-50/50 flex justify-between items-center">
                <span className="text-blue-900 font-medium">Arus Kas Pendanaan</span>
                <span className="font-bold text-blue-700 tabular-nums">{formatRupiah(cashFlowStatement.financingCashFlow.total)}</span>
              </div>
              <div className="p-3.5 rounded-lg border-2 border-slate-800 bg-slate-900 text-white flex justify-between items-center font-bold">
                <span>Saldo Kas Akhir Periode</span>
                <span className="tabular-nums text-emerald-300">{formatRupiah(cashFlowStatement.endingCash)}</span>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center gap-2 text-xs text-slate-500">
            <ShieldCheck className="w-4 h-4 text-emerald-500 shrink-0" />
            <span>Rekonsiliasi otomatis antara Laporan Laba Rugi dan Arus Kas.</span>
          </div>
        </div>
      </div>

      {/* KPI Detail Modal */}
      {kpiModalMetric && (
        <KpiDetailModal
          metric={kpiModalMetric}
          onClose={() => setKpiModalMetric(null)}
        />
      )}
    </div>
  );
};
