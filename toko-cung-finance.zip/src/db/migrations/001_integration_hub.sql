-- ======================================================================
-- TOKO CUNG FINANCE — INTEGRATION HUB DATABASE MIGRATION
-- Supports: Bank/Open Banking/SNAP, Shopee, TikTok Shop, Tokopedia,
-- Normalization, Settlement Reconciliation, Webhooks, SKU Mapping.
-- ======================================================================

-- 1. Extend Sales Table with Sales Channel
ALTER TABLE sales ADD COLUMN IF NOT EXISTS sales_channel VARCHAR(50) DEFAULT 'OFFLINE';
ALTER TABLE sales ADD COLUMN IF NOT EXISTS external_order_id VARCHAR(100);
ALTER TABLE sales ADD COLUMN IF NOT EXISTS external_channel_id VARCHAR(100);
ALTER TABLE sales ADD COLUMN IF NOT EXISTS source_platform VARCHAR(50);
ALTER TABLE sales ADD COLUMN IF NOT EXISTS marketplace_fee NUMERIC(15, 2) DEFAULT 0;

CREATE INDEX IF NOT EXISTS idx_sales_channel ON sales(sales_channel);
CREATE INDEX IF NOT EXISTS idx_sales_ext_order ON sales(external_order_id);

-- 2. Bank Connections Table
CREATE TABLE IF NOT EXISTS bank_connections (
    id VARCHAR(50) PRIMARY KEY,
    provider VARCHAR(50) NOT NULL, -- 'BCA_API', 'MANDIRI_API', 'SNAP_BI', 'MANUAL_CSV'
    bank_name VARCHAR(100) NOT NULL,
    account_name VARCHAR(150) NOT NULL,
    account_number_masked VARCHAR(50) NOT NULL, -- e.g. '**** **** 1234'
    currency VARCHAR(10) DEFAULT 'IDR',
    connection_status VARCHAR(30) DEFAULT 'CONNECTED', -- 'CONNECTED', 'SYNCING', 'WARNING', 'ERROR', 'DISCONNECTED'
    access_token_encrypted TEXT,
    refresh_token_encrypted TEXT,
    token_expired_at TIMESTAMP WITH TIME ZONE,
    last_sync_at TIMESTAMP WITH TIME ZONE,
    next_sync_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_bank_conn_status ON bank_connections(connection_status);

-- 3. Bank Transactions Table
CREATE TABLE IF NOT EXISTS bank_transactions (
    id VARCHAR(50) PRIMARY KEY,
    bank_connection_id VARCHAR(50) NOT NULL REFERENCES bank_connections(id) ON DELETE CASCADE,
    external_transaction_id VARCHAR(100) NOT NULL,
    transaction_date DATE NOT NULL,
    value_date DATE NOT NULL,
    description TEXT NOT NULL,
    reference_number VARCHAR(100),
    debit NUMERIC(15, 2) DEFAULT 0,
    credit NUMERIC(15, 2) DEFAULT 0,
    amount NUMERIC(15, 2) NOT NULL,
    currency VARCHAR(10) DEFAULT 'IDR',
    balance NUMERIC(15, 2) NOT NULL,
    counterparty VARCHAR(150),
    category VARCHAR(100),
    sub_category VARCHAR(100),
    transaction_type VARCHAR(10) NOT NULL, -- 'CR' or 'DB'
    source VARCHAR(30) DEFAULT 'API_SYNC', -- 'API_SYNC', 'CSV_IMPORT', 'WEBHOOK'
    raw_payload JSONB,
    sync_batch_id VARCHAR(50),
    reconciliation_status VARCHAR(30) DEFAULT 'UNMATCHED', -- 'UNMATCHED', 'MATCHED', 'PARTIAL', 'DUPLICATE', 'IGNORED'
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_bank_tx_id UNIQUE (bank_connection_id, external_transaction_id)
);

CREATE INDEX IF NOT EXISTS idx_bank_tx_date ON bank_transactions(transaction_date);
CREATE INDEX IF NOT EXISTS idx_bank_tx_ext_id ON bank_transactions(external_transaction_id);
CREATE INDEX IF NOT EXISTS idx_bank_tx_recon_status ON bank_transactions(reconciliation_status);

-- 4. Marketplace Connections Table
CREATE TABLE IF NOT EXISTS marketplace_connections (
    id VARCHAR(50) PRIMARY KEY,
    platform VARCHAR(50) NOT NULL, -- 'SHOPEE', 'TIKTOK_SHOP', 'TOKOPEDIA', etc.
    shop_id VARCHAR(100) NOT NULL,
    shop_name VARCHAR(150) NOT NULL,
    seller_id VARCHAR(100),
    country VARCHAR(10) DEFAULT 'ID',
    currency VARCHAR(10) DEFAULT 'IDR',
    status VARCHAR(30) DEFAULT 'CONNECTED',
    authorization_status VARCHAR(30) DEFAULT 'AUTHORIZED',
    api_version VARCHAR(50) DEFAULT 'v2.0',
    access_token_encrypted TEXT,
    refresh_token_encrypted TEXT,
    token_expires_at TIMESTAMP WITH TIME ZONE,
    last_sync_at TIMESTAMP WITH TIME ZONE,
    last_success_at TIMESTAMP WITH TIME ZONE,
    last_error_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_marketplace_shop UNIQUE (platform, shop_id)
);

CREATE INDEX IF NOT EXISTS idx_mp_conn_platform ON marketplace_connections(platform);
CREATE INDEX IF NOT EXISTS idx_mp_conn_status ON marketplace_connections(status);

-- 5. Marketplace Orders Table
CREATE TABLE IF NOT EXISTS marketplace_orders (
    id VARCHAR(50) PRIMARY KEY,
    platform VARCHAR(50) NOT NULL,
    connection_id VARCHAR(50) NOT NULL REFERENCES marketplace_connections(id) ON DELETE CASCADE,
    external_order_id VARCHAR(100) NOT NULL,
    order_number VARCHAR(100) NOT NULL,
    order_date DATE NOT NULL,
    status VARCHAR(50) NOT NULL,
    buyer_reference VARCHAR(150),
    currency VARCHAR(10) DEFAULT 'IDR',
    subtotal NUMERIC(15, 2) DEFAULT 0,
    discount NUMERIC(15, 2) DEFAULT 0,
    shipping_fee NUMERIC(15, 2) DEFAULT 0,
    seller_discount NUMERIC(15, 2) DEFAULT 0,
    platform_discount NUMERIC(15, 2) DEFAULT 0,
    voucher NUMERIC(15, 2) DEFAULT 0,
    tax NUMERIC(15, 2) DEFAULT 0,
    platform_fee NUMERIC(15, 2) DEFAULT 0,
    commission_fee NUMERIC(15, 2) DEFAULT 0,
    payment_fee NUMERIC(15, 2) DEFAULT 0,
    other_fee NUMERIC(15, 2) DEFAULT 0,
    refund_amount NUMERIC(15, 2) DEFAULT 0,
    gross_sales NUMERIC(15, 2) DEFAULT 0,
    net_sales NUMERIC(15, 2) DEFAULT 0,
    settlement_amount NUMERIC(15, 2) DEFAULT 0,
    settlement_date DATE,
    raw_payload JSONB,
    sync_batch_id VARCHAR(50),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_mp_order UNIQUE (platform, external_order_id)
);

CREATE INDEX IF NOT EXISTS idx_mp_order_date ON marketplace_orders(order_date);
CREATE INDEX IF NOT EXISTS idx_mp_order_ext_id ON marketplace_orders(external_order_id);
CREATE INDEX IF NOT EXISTS idx_mp_order_platform ON marketplace_orders(platform);

-- 6. Normalized Marketplace Transactions Table
CREATE TABLE IF NOT EXISTS marketplace_transactions (
    id VARCHAR(50) PRIMARY KEY,
    platform VARCHAR(50) NOT NULL,
    connection_id VARCHAR(50) NOT NULL REFERENCES marketplace_connections(id) ON DELETE CASCADE,
    external_transaction_id VARCHAR(100) NOT NULL,
    external_order_id VARCHAR(100),
    transaction_date DATE NOT NULL,
    transaction_type VARCHAR(50) NOT NULL, -- 'SALE', 'REFUND', 'COMMISSION', 'SERVICE_FEE', etc.
    gross_amount NUMERIC(15, 2) DEFAULT 0,
    discount_amount NUMERIC(15, 2) DEFAULT 0,
    shipping_amount NUMERIC(15, 2) DEFAULT 0,
    fee_amount NUMERIC(15, 2) DEFAULT 0,
    tax_amount NUMERIC(15, 2) DEFAULT 0,
    refund_amount NUMERIC(15, 2) DEFAULT 0,
    net_amount NUMERIC(15, 2) DEFAULT 0,
    currency VARCHAR(10) DEFAULT 'IDR',
    category VARCHAR(100),
    sub_category VARCHAR(100),
    raw_payload JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_mp_tx UNIQUE (platform, external_transaction_id)
);

CREATE INDEX IF NOT EXISTS idx_mp_tx_date ON marketplace_transactions(transaction_date);
CREATE INDEX IF NOT EXISTS idx_mp_tx_type ON marketplace_transactions(transaction_type);
CREATE INDEX IF NOT EXISTS idx_mp_tx_ext_order ON marketplace_transactions(external_order_id);

-- 7. Channel SKU Mapping Table
CREATE TABLE IF NOT EXISTS channel_sku_mapping (
    id VARCHAR(50) PRIMARY KEY,
    platform VARCHAR(50) NOT NULL,
    connection_id VARCHAR(50) NOT NULL REFERENCES marketplace_connections(id) ON DELETE CASCADE,
    external_sku VARCHAR(100) NOT NULL,
    external_product_name VARCHAR(255) NOT NULL,
    internal_product_id VARCHAR(50),
    internal_sku VARCHAR(100),
    hpp_method VARCHAR(30) DEFAULT 'AVERAGE',
    active BOOLEAN DEFAULT TRUE,
    CONSTRAINT uq_channel_sku UNIQUE (platform, connection_id, external_sku)
);

CREATE INDEX IF NOT EXISTS idx_sku_map_ext ON channel_sku_mapping(external_sku);
CREATE INDEX IF NOT EXISTS idx_sku_map_int ON channel_sku_mapping(internal_sku);

-- 8. Marketplace Settlements Table
CREATE TABLE IF NOT EXISTS marketplace_settlements (
    id VARCHAR(50) PRIMARY KEY,
    platform VARCHAR(50) NOT NULL,
    connection_id VARCHAR(50) NOT NULL REFERENCES marketplace_connections(id) ON DELETE CASCADE,
    settlement_id VARCHAR(100) NOT NULL,
    settlement_period_start DATE NOT NULL,
    settlement_period_end DATE NOT NULL,
    gross_sales NUMERIC(15, 2) DEFAULT 0,
    discount NUMERIC(15, 2) DEFAULT 0,
    shipping NUMERIC(15, 2) DEFAULT 0,
    commission NUMERIC(15, 2) DEFAULT 0,
    service_fee NUMERIC(15, 2) DEFAULT 0,
    transaction_fee NUMERIC(15, 2) DEFAULT 0,
    tax NUMERIC(15, 2) DEFAULT 0,
    refund NUMERIC(15, 2) DEFAULT 0,
    adjustment NUMERIC(15, 2) DEFAULT 0,
    net_settlement NUMERIC(15, 2) NOT NULL,
    settlement_date DATE NOT NULL,
    bank_transaction_id VARCHAR(50) REFERENCES bank_transactions(id),
    reconciliation_status VARCHAR(30) DEFAULT 'PENDING', -- 'PENDING', 'RECEIVED', 'MATCHED', 'PARTIAL', 'DISPUTED'
    CONSTRAINT uq_settlement UNIQUE (platform, settlement_id)
);

CREATE INDEX IF NOT EXISTS idx_stl_ext_id ON marketplace_settlements(settlement_id);
CREATE INDEX IF NOT EXISTS idx_stl_date ON marketplace_settlements(settlement_date);
CREATE INDEX IF NOT EXISTS idx_stl_status ON marketplace_settlements(reconciliation_status);

-- 9. Raw Integration Events & Webhooks Table
CREATE TABLE IF NOT EXISTS integration_raw_events (
    id VARCHAR(50) PRIMARY KEY,
    provider VARCHAR(50) NOT NULL,
    connection_id VARCHAR(50),
    event_type VARCHAR(100) NOT NULL,
    external_event_id VARCHAR(150),
    payload JSONB NOT NULL,
    signature_valid BOOLEAN DEFAULT TRUE,
    processed BOOLEAN DEFAULT FALSE,
    processing_status VARCHAR(30) DEFAULT 'PENDING',
    error_message TEXT,
    received_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    processed_at TIMESTAMP WITH TIME ZONE
);

CREATE INDEX IF NOT EXISTS idx_raw_events_provider ON integration_raw_events(provider);
CREATE INDEX IF NOT EXISTS idx_raw_events_processed ON integration_raw_events(processed);
