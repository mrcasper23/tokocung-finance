import {
  Entity,
  User,
  Product,
  Customer,
  Vendor,
  SalesTransaction,
  HppRecord,
  OpexTransaction,
  PaymentRequest,
  CapexRequest,
  AssetRecord,
  NonOperatingTransaction,
  TaxTransaction,
  PayrollRecord,
  KasbonDebitur,
  KasbonTransaction,
  CashMutation,
  PurchaseOrder,
  PriceAdjustment,
  BudgetRecord,
  AuditLog
} from '../types/finance';

export const INITIAL_ENTITIES: Entity[] = [
  { id: 'cung-retail', code: 'TCR', name: 'PT Toko Cung Retail', type: 'Supermarket & Retail', location: 'Jakarta Pusat' },
  { id: 'cung-distribusi', code: 'TCD', name: 'CV Toko Cung Distribusi', type: 'Grosir & Logistik', location: 'Bekasi' },
  { id: 'cung-flagship', code: 'TCF', name: 'Toko Cung Flagship Store', type: 'Flagship Outlet', location: 'Tangerang Selatan' },
];

export const INITIAL_USERS: User[] = [
  { id: 'u1', name: 'Budi Hartono', email: 'budi.director@tokocung.co.id', role: 'Director', department: 'Executive Management', active: true },
  { id: 'u2', name: 'Siti Rahmawati', email: 'siti.finance@tokocung.co.id', role: 'Finance', department: 'Finance & Treasury', active: true },
  { id: 'u3', name: 'Hendra Wijaya', email: 'hendra.ops@tokocung.co.id', role: 'Operations', department: 'Supply Chain & Operations', active: true },
  { id: 'u4', name: 'Dewi Lestari', email: 'dewi.acc@tokocung.co.id', role: 'Accounting', department: 'Accounting & Tax', active: true },
  { id: 'u5', name: 'Andi Pratama', email: 'andi.viewer@tokocung.co.id', role: 'Viewer', department: 'Internal Audit', active: true },
];

export const INITIAL_PRODUCTS: Product[] = [
  { id: 'p1', sku: 'BRS-PREM-5K', name: 'Beras Premium Pulen 5kg', category: 'Sembako', unit: 'Sak', sellingPrice: 76000, costPrice: 62000 },
  { id: 'p2', sku: 'MYK-GOR-2L', name: 'Minyak Goreng Sawit 2L', category: 'Sembako', unit: 'Pouch', sellingPrice: 38500, costPrice: 32000 },
  { id: 'p3', sku: 'GLA-PAS-1K', name: 'Gula Pasir Kristal Putih 1kg', category: 'Sembako', unit: 'Bks', sellingPrice: 17500, costPrice: 14200 },
  { id: 'p4', sku: 'KOP-ROB-250', name: 'Kopi Robusta Specialty 250g', category: 'Minuman', unit: 'Bks', sellingPrice: 45000, costPrice: 31000 },
  { id: 'p5', sku: 'TPG-TRG-1K', name: 'Tepung Terigu Serbaguna 1kg', category: 'Bahan Kue', unit: 'Bks', sellingPrice: 13500, costPrice: 10500 },
  { id: 'p6', sku: 'SSU-UHT-1L', name: 'Susu Cair UHT Full Cream 1L', category: 'Dairy', unit: 'Kotak', sellingPrice: 21500, costPrice: 16500 },
  { id: 'p7', sku: 'MIE-INS-KTN', name: 'Mie Instan Goreng (Karton isi 40)', category: 'Makanan Instan', unit: 'Karton', sellingPrice: 122000, costPrice: 104000 },
  { id: 'p8', sku: 'SBN-CCC-800', name: 'Deterjen Cair Konsentrat 800ml', category: 'Household', unit: 'Pouch', sellingPrice: 22000, costPrice: 16000 },
];

export const INITIAL_CUSTOMERS: Customer[] = [
  { id: 'c1', name: 'Supermarket Bahagia Abadi', category: 'Corporate', phone: '021-5551234', email: 'procurement@bahagia.com', address: 'Jl. Sudirman No. 45, Jakarta' },
  { id: 'c2', name: 'Minimarket Sentosa Raya', category: 'Wholesale', phone: '021-8890223', email: 'sentosa.mart@gmail.com', address: 'Jl. Pemuda No. 12, Bekasi' },
  { id: 'c3', name: 'Restoran Sari Rasa Nusantara', category: 'Corporate', phone: '021-7788991', email: 'purchasing@sarirasa.co.id', address: 'Jl. Asia Afrika No. 8, Tangerang' },
  { id: 'c4', name: 'Toko Kelontong Berkah Ibu', category: 'Retail', phone: '081234567890', email: 'berkah.ibu@gmail.com', address: 'Jl. Cempaka Putih No. 90, Jakarta' },
  { id: 'c5', name: 'Hotel Grand Mulia Suites', category: 'Corporate', phone: '021-5678123', email: 'fnb@grandmulia.com', address: 'Jl. Rasuna Said Kav 2, Jakarta' },
];

export const INITIAL_VENDORS: Vendor[] = [
  { id: 'v1', name: 'PT Indofood Sukses Makmur Tbk', category: 'Supplier Makanan', phone: '021-57958822', email: 'sales@indofood.co.id', bankAccount: 'BCA 001-2893881' },
  { id: 'v2', name: 'PT Unilever Indonesia Tbk', category: 'Supplier Household', phone: '021-5262112', email: 'b2b@unilever.co.id', bankAccount: 'Mandiri 118-0098231' },
  { id: 'v3', name: 'PT Wilmar Nabati Indonesia', category: 'Supplier Minyak & Gula', phone: '021-2525888', email: 'distribution@wilmar.co.id', bankAccount: 'BCA 084-3329918' },
  { id: 'v4', name: 'Perum BULOG Divre DKI', category: 'Supplier Beras', phone: '021-5250077', email: 'komersial@bulog.co.id', bankAccount: 'BRI 0206-01-000456-30-1' },
  { id: 'v5', name: 'PT Mitra Solusi Perkantoran', category: 'ATK & Fasilitas', phone: '021-8378291', email: 'sales@mitrasolusi.id', bankAccount: 'BCA 542-0192837' },
];

// Helper to generate full 12 months (Jan-Des 2026) realistic data
const generateFullYearSalesAndHpp = () => {
  const sales: SalesTransaction[] = [];
  const hpp: HppRecord[] = [];

  // Monthly base targets in Rupiah (Sales ~ Rp 420 Juta - 680 Juta per month, peak around festive Ramadan in Mar/Apr and year-end)
  const monthlyScale = [
    { m: 1, baseSales: 450_000_000, growth: 1.0 },
    { m: 2, baseSales: 480_000_000, growth: 1.06 },
    { m: 3, baseSales: 610_000_000, growth: 1.35 }, // Ramadan peak
    { m: 4, baseSales: 650_000_000, growth: 1.44 }, // Idul Fitri peak
    { m: 5, baseSales: 510_000_000, growth: 1.13 },
    { m: 6, baseSales: 530_000_000, growth: 1.17 },
    { m: 7, baseSales: 540_000_000, growth: 1.20 },
    { m: 8, baseSales: 560_000_000, growth: 1.24 },
    { m: 9, baseSales: 575_000_000, growth: 1.27 },
    { m: 10, baseSales: 590_000_000, growth: 1.31 },
    { m: 11, baseSales: 620_000_000, growth: 1.37 },
    { m: 12, baseSales: 710_000_000, growth: 1.57 }, // Year-end peak
  ];

  const entities = ['cung-retail', 'cung-distribusi', 'cung-flagship'];
  const entityShares = [0.45, 0.35, 0.20]; // 45% Retail, 35% Distribusi, 20% Flagship

  let txCounter = 1000;
  let hppCounter = 1000;

  monthlyScale.forEach(({ m, baseSales }) => {
    const monthStr = m.toString().padStart(2, '0');

    // Create 4-6 sales tranches per month
    entities.forEach((entId, eIdx) => {
      const share = entityShares[eIdx];
      const targetEntitySales = baseSales * share;
      
      // Let's create 2 sales transactions per entity per month
      const half = targetEntitySales / 2;
      const days = [5 + eIdx * 2, 18 + eIdx * 3];

      days.forEach((day, dIdx) => {
        txCounter++;
        hppCounter++;
        const dateStr = `2026-${monthStr}-${day.toString().padStart(2, '0')}`;
        const prod = INITIAL_PRODUCTS[(m + eIdx + dIdx) % INITIAL_PRODUCTS.length];
        const qty = Math.round(half / prod.sellingPrice);
        const totalSales = qty * prod.sellingPrice;
        const totalHpp = qty * prod.costPrice;

        sales.push({
          id: `sls-${txCounter}`,
          transactionNumber: `TRX-2026-${monthStr}-${txCounter}`,
          date: dateStr,
          entityId: entId,
          customerName: INITIAL_CUSTOMERS[(eIdx + dIdx) % INITIAL_CUSTOMERS.length].name,
          productName: prod.name,
          productCategory: prod.category,
          qty,
          unitPrice: prod.sellingPrice,
          discount: 0,
          totalSales,
          status: 'Lunas',
          isDemo: true,
        });

        hpp.push({
          id: `hpp-${hppCounter}`,
          date: dateStr,
          sku: prod.sku,
          productName: prod.name,
          qty,
          unitCost: prod.costPrice,
          totalHpp,
          supplierName: INITIAL_VENDORS[(eIdx + dIdx) % INITIAL_VENDORS.length].name,
          poNumber: `PO-2026-${monthStr}-${hppCounter}`,
          referenceNumber: `TRX-2026-${monthStr}-${txCounter}`,
          isDemo: true,
        });
      });
    });
  });

  return { sales, hpp };
};

const { sales: FULL_SALES, hpp: FULL_HPP } = generateFullYearSalesAndHpp();

export const INITIAL_SALES: SalesTransaction[] = FULL_SALES;
export const INITIAL_HPP: HppRecord[] = FULL_HPP;

// Full 12-month realistic OPEX transactions (Total OPEX ~ Rp 70 Jt - 95 Jt per month)
const generateFullYearOpex = (): OpexTransaction[] => {
  const opex: OpexTransaction[] = [];
  let opexCounter = 2000;

  for (let m = 1; m <= 12; m++) {
    const monthStr = m.toString().padStart(2, '0');

    // 1. Gaji Tim Operasional & Toko
    opexCounter++;
    opex.push({
      id: `opx-${opexCounter}`,
      opexNumber: `OPX-2026-${monthStr}-01`,
      paymentRequestNumber: `PR-2026-${monthStr}-01`,
      date: `2026-${monthStr}-25`,
      entityId: 'cung-retail',
      vendorName: 'Internal Payroll Team',
      category: 'Gaji',
      description: `Gaji Pokok & Upah Lembur Karyawan Toko Bulan ${monthStr}`,
      nominal: 38_000_000,
      tax: 0,
      total: 38_000_000,
      status: 'Dibayar',
      approver: 'Budi Hartono',
      paymentDate: `2026-${monthStr}-25`,
      isDemo: true,
    });

    // 2. Listrik & Utilities
    opexCounter++;
    opex.push({
      id: `opx-${opexCounter}`,
      opexNumber: `OPX-2026-${monthStr}-02`,
      date: `2026-${monthStr}-10`,
      entityId: 'cung-retail',
      vendorName: 'PT PLN (Persero)',
      category: 'Utilities',
      description: `Tagihan Listrik PLN 3 Cabang & Gudang ${monthStr}/2026`,
      nominal: 7_800_000,
      tax: 0,
      total: 7_800_000,
      status: 'Dibayar',
      approver: 'Siti Rahmawati',
      paymentDate: `2026-${monthStr}-10`,
      isDemo: true,
    });

    // 3. Internet & Fiber Optic
    opexCounter++;
    opex.push({
      id: `opx-${opexCounter}`,
      opexNumber: `OPX-2026-${monthStr}-03`,
      date: `2026-${monthStr}-12`,
      entityId: 'cung-distribusi',
      vendorName: 'PT Telkom Indonesia',
      category: 'Internet',
      description: `Dedicated Internet & VPN Antar Cabang ${monthStr}/2026`,
      nominal: 2_400_000,
      tax: 264_000,
      total: 2_664_000,
      status: 'Dibayar',
      approver: 'Siti Rahmawati',
      paymentDate: `2026-${monthStr}-12`,
      isDemo: true,
    });

    // 4. Advertisement & Promosi Digital
    opexCounter++;
    opex.push({
      id: `opx-${opexCounter}`,
      opexNumber: `OPX-2026-${monthStr}-04`,
      date: `2026-${monthStr}-08`,
      entityId: 'cung-flagship',
      vendorName: 'Meta Ads & Google Ads Agency',
      category: 'Advertisement',
      description: `Iklan Digital Campaign Promo Bulanan ${monthStr}`,
      nominal: 6_500_000,
      tax: 715_000,
      total: 7_215_000,
      status: 'Dibayar',
      approver: 'Budi Hartono',
      paymentDate: `2026-${monthStr}-08`,
      isDemo: true,
    });

    // 5. Logistik & Bahan Bakar Armada
    opexCounter++;
    opex.push({
      id: `opx-${opexCounter}`,
      opexNumber: `OPX-2026-${monthStr}-05`,
      date: `2026-${monthStr}-15`,
      entityId: 'cung-distribusi',
      vendorName: 'Pertamina Retail & Tol',
      category: 'Logistik',
      description: `BBM & E-Toll Pengiriman Armada Gudang ${monthStr}`,
      nominal: 8_200_000,
      tax: 0,
      total: 8_200_000,
      status: 'Dibayar',
      approver: 'Hendra Wijaya',
      paymentDate: `2026-${monthStr}-15`,
      isDemo: true,
    });

    // 6. Maintenance & Perawatan Alat
    opexCounter++;
    opex.push({
      id: `opx-${opexCounter}`,
      opexNumber: `OPX-2026-${monthStr}-06`,
      date: `2026-${monthStr}-20`,
      entityId: 'cung-retail',
      vendorName: 'CV Teknik Mandiri',
      category: 'Maintenance',
      description: `Servis AC Berkala & Pemeliharaan Genset ${monthStr}`,
      nominal: 3_500_000,
      tax: 0,
      total: 3_500_000,
      status: 'Dibayar',
      approver: 'Hendra Wijaya',
      paymentDate: `2026-${monthStr}-20`,
      isDemo: true,
    });

    // 7. Cloud Server & POS Software License
    opexCounter++;
    opex.push({
      id: `opx-${opexCounter}`,
      opexNumber: `OPX-2026-${monthStr}-07`,
      date: `2026-${monthStr}-05`,
      entityId: 'cung-retail',
      vendorName: 'PT Cloud Hosting Indonesia',
      category: 'Server',
      description: `Sewa Server Cloud Database & Lisensi POS ${monthStr}`,
      nominal: 2_800_000,
      tax: 308_000,
      total: 3_108_000,
      status: 'Dibayar',
      approver: 'Siti Rahmawati',
      paymentDate: `2026-${monthStr}-05`,
      isDemo: true,
    });

    // 8. ATK & Perlengkapan Kasir
    opexCounter++;
    opex.push({
      id: `opx-${opexCounter}`,
      opexNumber: `OPX-2026-${monthStr}-08`,
      date: `2026-${monthStr}-18`,
      entityId: 'cung-flagship',
      vendorName: 'PT Mitra Solusi Perkantoran',
      category: 'ATK',
      description: `Kertas Struk Thermal Kasir & Plastik Belanja ${monthStr}`,
      nominal: 2_900_000,
      tax: 319_000,
      total: 3_219_000,
      status: 'Dibayar',
      approver: 'Siti Rahmawati',
      paymentDate: `2026-${monthStr}-18`,
      isDemo: true,
    });
  }

  return opex;
};

export const INITIAL_OPEX: OpexTransaction[] = generateFullYearOpex();

// Payment Requests across workflow stages
export const INITIAL_PAYMENT_REQUESTS: PaymentRequest[] = [
  {
    id: 'pr-101',
    prNumber: 'PR-2026-03-01',
    requestor: 'Hendra Wijaya',
    department: 'Operations',
    purpose: 'Pengadaan Kertas Struk Thermal & Plastik Ramah Lingkungan',
    dueDate: '2026-03-25',
    priority: 'Sedang',
    vendorName: 'PT Mitra Solusi Perkantoran',
    invoiceNumber: 'INV-MSP-2026-88',
    invoiceDate: '2026-03-15',
    items: [
      { id: 'pri-1', description: 'Kertas Thermal Roll 80mm', qty: 100, unit: 'Roll', price: 12000, total: 1200000 },
      { id: 'pri-2', description: 'Kantong Plastik Singkong Eco 500s', qty: 20, unit: 'Pack', price: 85000, total: 1700000 },
    ],
    subtotal: 2900000,
    tax: 319000,
    grandTotal: 3219000,
    status: 'Paid',
    reviewedBy: 'Siti Rahmawati',
    approvedBy: 'Budi Hartono',
    createdAt: '2026-03-16',
    isDemo: true,
  },
  {
    id: 'pr-102',
    prNumber: 'PR-2026-03-02',
    requestor: 'Dewi Lestari',
    department: 'Accounting',
    purpose: 'Jasa Konsultasi Audit Pajak Tahunan Q1',
    dueDate: '2026-03-30',
    priority: 'Tinggi',
    vendorName: 'Kantor Akuntan Publik Mulia & Rekan',
    invoiceNumber: 'KAP-2026-091',
    invoiceDate: '2026-03-20',
    items: [
      { id: 'pri-3', description: 'Review Kepatuhan PPh & PPN Q1', qty: 1, unit: 'Paket', price: 12000000, total: 12000000 },
    ],
    subtotal: 12000000,
    tax: 240000, // PPh 23
    grandTotal: 12240000,
    status: 'Approved',
    reviewedBy: 'Siti Rahmawati',
    approvedBy: 'Budi Hartono',
    createdAt: '2026-03-21',
    isDemo: true,
  },
  {
    id: 'pr-103',
    prNumber: 'PR-2026-03-03',
    requestor: 'Hendra Wijaya',
    department: 'Supply Chain',
    purpose: 'Pallet Kayu Standar Ekspor Gudang Pusat',
    dueDate: '2026-04-05',
    priority: 'Sedang',
    vendorName: 'CV Kayu Lestari Abadi',
    invoiceNumber: 'INV-KLA-441',
    invoiceDate: '2026-03-24',
    items: [
      { id: 'pri-4', description: 'Pallet Kayu Hardwood 120x100cm', qty: 40, unit: 'Unit', price: 145000, total: 5800000 },
    ],
    subtotal: 5800000,
    tax: 0,
    grandTotal: 5800000,
    status: 'Reviewed',
    reviewedBy: 'Siti Rahmawati',
    createdAt: '2026-03-24',
    isDemo: true,
  },
  {
    id: 'pr-104',
    prNumber: 'PR-2026-04-01',
    requestor: 'Siti Rahmawati',
    department: 'Finance',
    purpose: 'Perpanjangan Sertifikat SSL & Cloud Security Firewall',
    dueDate: '2026-04-10',
    priority: 'Rendah',
    vendorName: 'PT Cloud Hosting Indonesia',
    invoiceNumber: 'INV-CHI-2026-90',
    invoiceDate: '2026-03-26',
    items: [
      { id: 'pri-5', description: 'SSL EV Wildcard 1 Year', qty: 1, unit: 'Lisensi', price: 3200000, total: 3200000 },
    ],
    subtotal: 3200000,
    tax: 352000,
    grandTotal: 3552000,
    status: 'Submitted',
    createdAt: '2026-03-26',
    isDemo: true,
  },
];

// Initial CAPEX Requests & Asset Register
export const INITIAL_CAPEX_REQUESTS: CapexRequest[] = [
  {
    id: 'cpx-01',
    capexNumber: 'CPX-2026-01-01',
    requestor: 'Hendra Wijaya',
    project: 'Modernisasi Gudang Bekasi',
    description: 'Pengadaan Forklift Elektrik 2.5 Ton & Baterai Lithium',
    vendorName: 'PT Traktor Nusantara Tbk',
    assetType: 'Kendaraan & Alat Berat Gudang',
    acquisitionDate: '2026-01-15',
    acquisitionCost: 180_000_000,
    expectedUsefulLifeMonths: 60, // 5 tahun
    residualValue: 30_000_000,
    depreciationMethod: 'Straight Line',
    status: 'Asset Created',
    approvedBy: 'Budi Hartono',
    isDemo: true,
  },
  {
    id: 'cpx-02',
    capexNumber: 'CPX-2026-02-01',
    requestor: 'Siti Rahmawati',
    project: 'Sistem Kasir Pintar Flagship Store',
    description: 'Upgrade 6 Unit POS Terminal Touchscreen + Thermal Printer & Scanner 2D',
    vendorName: 'PT Solusi POS Digital',
    assetType: 'Peralatan Elektronik Kasir',
    acquisitionDate: '2026-02-10',
    acquisitionCost: 65_000_000,
    expectedUsefulLifeMonths: 48, // 4 tahun
    residualValue: 5_000_000,
    depreciationMethod: 'Straight Line',
    status: 'Asset Created',
    approvedBy: 'Budi Hartono',
    isDemo: true,
  },
  {
    id: 'cpx-03',
    capexNumber: 'CPX-2026-04-01',
    requestor: 'Hendra Wijaya',
    project: 'Ekspansi Armada Pengiriman',
    description: 'Pembelian 1 Unit Daihatsu Gran Max Blind Van Box untuk Delivery Express',
    vendorName: 'PT Astra Daihatsu Motor',
    assetType: 'Kendaraan Angkut Barang',
    acquisitionDate: '2026-04-20',
    acquisitionCost: 195_000_000,
    expectedUsefulLifeMonths: 60,
    residualValue: 45_000_000,
    depreciationMethod: 'Straight Line',
    status: 'Approved',
    approvedBy: 'Budi Hartono',
    isDemo: true,
  },
];

// Initial Asset Register
export const INITIAL_ASSETS: AssetRecord[] = [
  {
    id: 'ast-01',
    assetCode: 'AST-2025-BLDG-01',
    assetName: 'Bangunan Ruko Toko Cung Retail Pusat',
    category: 'Gedung & Bangunan',
    location: 'Jakarta Pusat',
    acquisitionDate: '2024-01-01',
    acquisitionCost: 1_200_000_000,
    usefulLifeMonths: 240, // 20 tahun
    residualValue: 240_000_000,
    depreciationMethod: 'Straight Line',
    monthlyDepreciation: 4_000_000, // (1.200M - 240M) / 240 = 4.000.000 / bln
    accumulatedDepreciation: 104_000_000,
    bookValue: 1_096_000_000,
    status: 'Active',
    isDemo: true,
  },
  {
    id: 'ast-02',
    assetCode: 'AST-2026-FKL-01',
    assetName: 'Forklift Elektrik 2.5 Ton Lithium Gudang',
    category: 'Kendaraan & Alat Berat',
    location: 'Gudang Bekasi',
    acquisitionDate: '2026-01-15',
    acquisitionCost: 180_000_000,
    usefulLifeMonths: 60, // 5 tahun
    residualValue: 30_000_000,
    depreciationMethod: 'Straight Line',
    monthlyDepreciation: 2_500_000, // (180M - 30M) / 60 = 2.500.000 / bln
    accumulatedDepreciation: 7_500_000,
    bookValue: 172_500_000,
    status: 'Active',
    isDemo: true,
  },
  {
    id: 'ast-03',
    assetCode: 'AST-2026-POS-01',
    assetName: 'Sistem POS Terminal Flagship 6 Unit',
    category: 'Peralatan Elektronik',
    location: 'Flagship Store Tangerang',
    acquisitionDate: '2026-02-10',
    acquisitionCost: 65_000_000,
    usefulLifeMonths: 48, // 4 tahun
    residualValue: 5_000_000,
    depreciationMethod: 'Straight Line',
    monthlyDepreciation: 1_250_000, // (65M - 5M) / 48 = 1.250.000 / bln
    accumulatedDepreciation: 2_500_000,
    bookValue: 62_500_000,
    status: 'Active',
    isDemo: true,
  },
  {
    id: 'ast-04',
    assetCode: 'AST-2025-RAK-01',
    assetName: 'Rak Heavy Duty Gudang Pusat 40 Bay',
    category: 'Peralatan & Inventaris',
    location: 'Gudang Bekasi',
    acquisitionDate: '2025-06-01',
    acquisitionCost: 96_000_000,
    usefulLifeMonths: 96, // 8 tahun
    residualValue: 9_600_000,
    depreciationMethod: 'Straight Line',
    monthlyDepreciation: 900_000, // 900.000 / bln
    accumulatedDepreciation: 8_100_000,
    bookValue: 87_900_000,
    status: 'Active',
    isDemo: true,
  },
];

// Non-operating transactions (Interest income, bank charges, etc.)
export const INITIAL_NON_OPERATING: NonOperatingTransaction[] = [
  { id: 'nop-01', date: '2026-01-31', category: 'Pendapatan Bunga', amount: 3_200_000, description: 'Bunga Rekening Giro & Deposito BCA Operasional', entityId: 'cung-retail', isDemo: true },
  { id: 'nop-02', date: '2026-01-31', category: 'Beban Bunga', amount: 1_800_000, description: 'Biaya Administrasi & Bunga Fasilitas Kredit Bank', entityId: 'cung-retail', isDemo: true },
  { id: 'nop-03', date: '2026-02-28', category: 'Pendapatan Bunga', amount: 3_450_000, description: 'Bunga Rekening Giro & Deposito Mandiri Bisnis', entityId: 'cung-retail', isDemo: true },
  { id: 'nop-04', date: '2026-02-28', category: 'Beban Bunga', amount: 1_800_000, description: 'Biaya Administrasi & Bunga Fasilitas Kredit Bank', entityId: 'cung-retail', isDemo: true },
  { id: 'nop-05', date: '2026-03-31', category: 'Pendapatan Bunga', amount: 3_600_000, description: 'Bunga Deposito Q1 2026', entityId: 'cung-retail', isDemo: true },
  { id: 'nop-06', date: '2026-03-31', category: 'Pendapatan Lainnya', amount: 1_500_000, description: 'Penjualan Kardus & Pallet Bekas Tidak Terpakai', entityId: 'cung-distribusi', isDemo: true },
  { id: 'nop-07', date: '2026-03-31', category: 'Beban Bunga', amount: 1_800_000, description: 'Biaya Administrasi & Bunga Fasilitas Kredit Bank', entityId: 'cung-retail', isDemo: true },
];

// Tax transactions
export const INITIAL_TAX_TRANSACTIONS: TaxTransaction[] = [
  { id: 'tax-01', taxPeriod: '2026-01', taxBase: 42_500_000, taxRate: 22, taxAmount: 9_350_000, status: 'Disetor', paymentDate: '2026-02-15', notes: 'Pajak Penghasilan Badan Jan 2026', isDemo: true },
  { id: 'tax-02', taxPeriod: '2026-02', taxBase: 48_100_000, taxRate: 22, taxAmount: 10_582_000, status: 'Disetor', paymentDate: '2026-03-15', notes: 'Pajak Penghasilan Badan Feb 2026', isDemo: true },
  { id: 'tax-03', taxPeriod: '2026-03', taxBase: 78_600_000, taxRate: 22, taxAmount: 17_292_000, status: 'Dihitung', notes: 'Estimasi Pajak Penghasilan Badan Mar 2026', isDemo: true },
];

// Payroll Records
export const INITIAL_PAYROLL: PayrollRecord[] = [
  { id: 'pay-01', period: '2026-03', employeeName: 'Agus Santoso', department: 'Kepala Toko Retail', baseSalary: 8_500_000, allowances: 2_000_000, deductions: 525_000, netSalary: 9_975_000, status: 'Dibayar', paymentDate: '2026-03-25', isDemo: true },
  { id: 'pay-02', period: '2026-03', employeeName: 'Rina Maryani', department: 'Kasir Senior', baseSalary: 5_200_000, allowances: 800_000, deductions: 300_000, netSalary: 5_700_000, status: 'Dibayar', paymentDate: '2026-03-25', isDemo: true },
  { id: 'pay-03', period: '2026-03', employeeName: 'Fajar Nugroho', department: 'Supervisor Gudang', baseSalary: 7_000_000, allowances: 1_500_000, deductions: 425_000, netSalary: 8_075_000, status: 'Dibayar', paymentDate: '2026-03-25', isDemo: true },
  { id: 'pay-04', period: '2026-03', employeeName: 'Doni Saputra', department: 'Driver Logistik', baseSalary: 4_800_000, allowances: 1_200_000, deductions: 300_000, netSalary: 5_700_000, status: 'Dibayar', paymentDate: '2026-03-25', isDemo: true },
  { id: 'pay-05', period: '2026-03', employeeName: 'Maya Indah', department: 'Staf Keuangan', baseSalary: 6_500_000, allowances: 1_000_000, deductions: 375_000, netSalary: 7_125_000, status: 'Dibayar', paymentDate: '2026-03-25', isDemo: true },
];

// Kasbon Debitur & Mutasi Kas
export const INITIAL_DEBITUR_KASBON: KasbonDebitur[] = [
  { id: 'deb-01', employeeName: 'Fajar Nugroho', department: 'Gudang Bekasi', phone: '081311223344', ceilingLimit: 10_000_000, currentBalance: 3_500_000, status: 'Aktif' },
  { id: 'deb-02', employeeName: 'Doni Saputra', department: 'Armada Pengiriman', phone: '081299887766', ceilingLimit: 5_000_000, currentBalance: 1_200_000, status: 'Aktif' },
  { id: 'deb-03', employeeName: 'Agus Santoso', department: 'Store Retail', phone: '081577665544', ceilingLimit: 12_000_000, currentBalance: 0, status: 'Aktif' },
  { id: 'deb-04', employeeName: 'Rina Maryani', department: 'Front Kasir', phone: '081722334455', ceilingLimit: 4_000_000, currentBalance: 500_000, status: 'Aktif' },
];

export const INITIAL_KASBON_TRANSACTIONS: KasbonTransaction[] = [
  { id: 'kb-01', transactionNumber: 'KB-2026-001', debiturId: 'deb-01', debiturName: 'Fajar Nugroho', date: '2026-02-10', purpose: 'Biaya Darurat Medis Keluarga', amount: 5_000_000, repaidAmount: 1_500_000, remainingAmount: 3_500_000, status: 'Sebagian Lunas', isDemo: true },
  { id: 'kb-02', transactionNumber: 'KB-2026-002', debiturId: 'deb-02', debiturName: 'Doni Saputra', date: '2026-03-05', purpose: 'Perbaikan Kendaraan Pribadi Dinas', amount: 1_200_000, repaidAmount: 0, remainingAmount: 1_200_000, status: 'Disetujui', isDemo: true },
  { id: 'kb-03', transactionNumber: 'KB-2026-003', debiturId: 'deb-04', debiturName: 'Rina Maryani', date: '2026-03-12', purpose: 'Uang Muka Pendidikan Anak', amount: 1_500_000, repaidAmount: 1_000_000, remainingAmount: 500_000, status: 'Sebagian Lunas', isDemo: true },
];

export const INITIAL_CASH_MUTATIONS: CashMutation[] = [
  { id: 'mut-01', date: '2026-03-01', account: 'BCA Operasional', type: 'Masuk', category: 'Penerimaan Penjualan', amount: 145_000_000, balanceAfter: 685_000_000, description: 'Setoran Hasil Penjualan Wholesale Toko Bahagia', referenceNumber: 'TRX-2026-03-1021', isDemo: true },
  { id: 'mut-02', date: '2026-03-05', account: 'BCA Operasional', type: 'Keluar', category: 'Pembayaran Vendor HPP', amount: 84_000_000, balanceAfter: 601_000_000, description: 'Pelunasan PO Bulog Beras Premium', referenceNumber: 'PO-2026-03-101', isDemo: true },
  { id: 'mut-03', date: '2026-03-10', account: 'Mandiri Bisnis', type: 'Keluar', category: 'Pembayaran OPEX Listrik', amount: 7_800_000, balanceAfter: 312_200_000, description: 'Autodebet Tagihan Listrik PLN 3 Cabang', referenceNumber: 'OPX-2026-03-02', isDemo: true },
  { id: 'mut-04', date: '2026-03-15', account: 'Kas Kecil (Petty Cash)', type: 'Masuk', category: 'Top-up Petty Cash', amount: 10_000_000, balanceAfter: 15_400_000, description: 'Pencairan Cek Tarik Tunai BCA untuk Kas Kecil Kantor', referenceNumber: 'CHK-BCA-9921', isDemo: true },
  { id: 'mut-05', date: '2026-03-18', account: 'Kas Kecil (Petty Cash)', type: 'Keluar', category: 'Kasbon Karyawan', amount: 1_200_000, balanceAfter: 14_200_000, description: 'Pencairan Kasbon Doni Saputra (Driver)', referenceNumber: 'KB-2026-002', isDemo: true },
];

// Purchase Monitoring
export const INITIAL_PURCHASE_ORDERS: PurchaseOrder[] = [
  { id: 'po-1', poNumber: 'PO-2026-03-501', date: '2026-03-10', supplierName: 'PT Indofood Sukses Makmur Tbk', totalItems: 500, totalCost: 52_000_000, status: 'Diterima Lengkap', receivedDate: '2026-03-14', isDemo: true },
  { id: 'po-2', poNumber: 'PO-2026-03-502', date: '2026-03-15', supplierName: 'PT Wilmar Nabati Indonesia', totalItems: 800, totalCost: 25_600_000, status: 'Diterima Sebagian', receivedDate: '2026-03-18', isDemo: true },
  { id: 'po-3', poNumber: 'PO-2026-03-503', date: '2026-03-22', supplierName: 'Perum BULOG Divre DKI', totalItems: 1200, totalCost: 74_400_000, status: 'Dipesan', isDemo: true },
  { id: 'po-4', poNumber: 'PO-2026-03-504', date: '2026-03-25', supplierName: 'PT Unilever Indonesia Tbk', totalItems: 350, totalCost: 18_200_000, status: 'Draft', isDemo: true },
];

export const INITIAL_PRICE_ADJUSTMENTS: PriceAdjustment[] = [
  { id: 'pa-1', sku: 'BRS-PREM-5K', productName: 'Beras Premium Pulen 5kg', oldPrice: 72000, newPrice: 76000, effectiveDate: '2026-02-01', reason: 'Penyesuaian kenaikan harga gabah kering panen dari supplier', status: 'Aktif', isDemo: true },
  { id: 'pa-2', sku: 'MYK-GOR-2L', productName: 'Minyak Goreng Sawit 2L', oldPrice: 36000, newPrice: 38500, effectiveDate: '2026-02-15', reason: 'Kenaikan CPO acuan DMO pasar domestik', status: 'Aktif', isDemo: true },
  { id: 'pa-3', sku: 'KOP-ROB-250', productName: 'Kopi Robusta Specialty 250g', oldPrice: 42000, newPrice: 45000, effectiveDate: '2026-03-01', reason: 'Peningkatan kualitas kemasan valve alufoil', status: 'Aktif', isDemo: true },
];

// Budget records for 2026
export const INITIAL_BUDGETS: BudgetRecord[] = [
  { id: 'bg-01', year: 2026, month: 0, entityId: 'ALL', category: 'Sales', department: 'Commercial', type: 'Sales', budgetAmount: 6_800_000_000 },
  { id: 'bg-02', year: 2026, month: 0, entityId: 'ALL', category: 'OPEX', department: 'Operations & G&A', type: 'OPEX', budgetAmount: 960_000_000 },
  { id: 'bg-03', year: 2026, month: 0, entityId: 'ALL', category: 'CAPEX', department: 'Infrastructure & Tech', type: 'CAPEX', budgetAmount: 450_000_000 },
];

// Initial Audit Logs
export const INITIAL_AUDIT_LOGS: AuditLog[] = [
  { id: 'aud-1', timestamp: '2026-03-26 10:15:32', action: 'Created', module: 'Payment Request', recordId: 'PR-2026-04-01', userName: 'Siti Rahmawati', userRole: 'Finance', details: 'Membuat Payment Request pengadaan sertifikat SSL' },
  { id: 'aud-2', timestamp: '2026-03-24 16:20:11', action: 'Submitted', module: 'Payment Request', recordId: 'PR-2026-03-03', userName: 'Hendra Wijaya', userRole: 'Operations', details: 'Mengajukan PR pallet kayu gudang' },
  { id: 'aud-3', timestamp: '2026-03-21 14:10:45', action: 'Approved', module: 'Payment Request', recordId: 'PR-2026-03-02', userName: 'Budi Hartono', userRole: 'Director', details: 'Menyetujui PR jasa audit KAP' },
  { id: 'aud-4', timestamp: '2026-03-18 11:05:00', action: 'Paid', module: 'Payment Request', recordId: 'PR-2026-03-01', userName: 'Siti Rahmawati', userRole: 'Finance', details: 'Melakukan pembayaran via transfer Bank BCA' },
  { id: 'aud-5', timestamp: '2026-02-12 09:30:20', action: 'Approved', module: 'CAPEX Request', recordId: 'CPX-2026-02-01', userName: 'Budi Hartono', userRole: 'Director', details: 'Menyetujui pengadaan 6 unit sistem kasir POS' },
];
