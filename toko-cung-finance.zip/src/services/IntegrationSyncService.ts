import {
  BankConnection,
  BankTransaction,
  MarketplaceConnection,
  MarketplaceOrder,
  MarketplaceTransaction,
  ChannelSkuMapping,
  MarketplaceSettlement,
  SyncBatch,
  FeeCategoryMapping,
  BankAutoRule,
  IntegrationSettings,
  SyncSource,
  SyncType
} from '../types/integration';
import { SalesTransaction, HppRecord } from '../types/finance';

/**
 * Service to execute provider sync, normalization, reconciliation, and audit logging.
 */

export interface SyncResult {
  success: boolean;
  batchId: string;
  recordsSynced: number;
  recordsFailed: number;
  generatedSalesCount: number;
  generatedHppCount: number;
  matchedSettlementsCount: number;
  message: string;
}

export class IntegrationSyncService {
  /**
   * Auto categorization rule matcher
   */
  static categorizeBankTransaction(
    description: string,
    counterparty: string,
    rules: BankAutoRule[]
  ): { category: string; status: 'AUTO_MATCH' | 'REVIEW' | 'CONFIRM' } {
    const descUpper = (description || '').toUpperCase();
    const cpUpper = (counterparty || '').toUpperCase();

    for (const rule of rules) {
      const target = rule.match_field === 'description' ? descUpper : cpUpper;
      if (target.includes(rule.keyword.toUpperCase())) {
        return {
          category: rule.suggested_category,
          status: rule.auto_confirm ? 'CONFIRM' : 'AUTO_MATCH',
        };
      }
    }

    return {
      category: 'Uncategorized Bank Mutation',
      status: 'REVIEW',
    };
  }

  /**
   * Normalizes a marketplace order into internal Toko Cung Sales and HPP
   */
  static normalizeOrderToSalesAndHpp(
    order: MarketplaceOrder,
    mappings: ChannelSkuMapping[],
    entityId: string = 'cung-retail'
  ): {
    salesTx: SalesTransaction;
    hppRecords: HppRecord[];
    unmappedSkus: string[];
  } {
    const unmappedSkus: string[] = [];
    const hppRecords: HppRecord[] = [];

    // Calculate total marketplace fee to record
    const totalMarketplaceFee =
      order.commission_fee + order.platform_fee + order.payment_fee + order.other_fee;

    // Build internal Sales Transaction
    const firstItem = order.items[0];
    const productName =
      order.items.length === 1
        ? firstItem.product_name
        : `${firstItem.product_name} (+${order.items.length - 1} item lainnya)`;

    const salesTx: SalesTransaction = {
      id: `sal-mp-${order.platform.toLowerCase()}-${order.id}`,
      transactionNumber: order.order_number || `TC-${order.platform}-${order.external_order_id}`,
      date: order.order_date,
      entityId,
      customerName: order.buyer_reference || `Customer ${order.platform}`,
      productName,
      productCategory: 'Marketplace Online',
      qty: order.items.reduce((sum, item) => sum + item.qty, 0),
      unitPrice: order.gross_sales,
      discount: order.discount + order.seller_discount,
      totalSales: order.net_sales,
      status: 'Lunas',
      salesChannel: order.platform as any,
      external_order_id: order.external_order_id,
      external_channel_id: order.connection_id,
      source_platform: order.platform,
      marketplace_fee: totalMarketplaceFee,
      isDemo: false,
    };

    // Calculate HPP for mapped items
    for (const item of order.items) {
      const mapping = mappings.find(
        m => m.platform === order.platform && m.external_sku.toLowerCase() === item.sku.toLowerCase()
      );

      if (mapping && mapping.internal_sku) {
        const unitCost = mapping.unit_hpp_estimate || 45000;
        const totalHpp = item.qty * unitCost;

        hppRecords.push({
          id: `hpp-mp-${order.id}-${item.sku}`,
          date: order.order_date,
          sku: mapping.internal_sku,
          productName: item.product_name,
          qty: item.qty,
          unitCost,
          totalHpp,
          supplierName: 'Gudang Pusat Toko Cung (Inventori Online)',
          poNumber: `ORD-${order.external_order_id}`,
          referenceNumber: `CHANNEL-${order.platform}`,
          isDemo: false,
        });
      } else {
        unmappedSkus.push(item.sku);
      }
    }

    return { salesTx, hppRecords, unmappedSkus };
  }

  /**
   * Auto Reconciliation algorithm: matches Bank Incoming CR with Marketplace Settlement
   */
  static autoReconcileSettlements(
    bankTxList: BankTransaction[],
    settlements: MarketplaceSettlement[],
    toleranceAmount: number = 50000
  ): {
    updatedBankTxList: BankTransaction[];
    updatedSettlements: MarketplaceSettlement[];
    matchedCount: number;
  } {
    let matchedCount = 0;
    const updatedBank = [...bankTxList];
    const updatedStl = [...settlements];

    for (let sIdx = 0; sIdx < updatedStl.length; sIdx++) {
      const stl = updatedStl[sIdx];
      if (stl.reconciliation_status === 'MATCHED') continue;

      // Find matching bank transaction by amount or reference
      const bIdx = updatedBank.findIndex(b => {
        if (b.reconciliation_status === 'MATCHED') return false;
        if (b.transaction_type !== 'CR' || b.credit <= 0) return false;

        // Check reference or ID in description
        const descMatch =
          b.description.includes(stl.settlement_id) ||
          b.reference_number.includes(stl.settlement_id) ||
          b.description.toUpperCase().includes(stl.platform);

        const diff = Math.abs(b.credit - stl.net_settlement);
        const amountMatch = diff <= toleranceAmount;

        return amountMatch && (descMatch || diff === 0);
      });

      if (bIdx !== -1) {
        // Matched!
        const b = updatedBank[bIdx];
        updatedBank[bIdx] = {
          ...b,
          reconciliation_status: 'MATCHED',
          matched_internal_id: stl.id,
          matched_internal_type: 'SETTLEMENT',
        };
        updatedStl[sIdx] = {
          ...stl,
          reconciliation_status: 'MATCHED',
          bank_transaction_id: b.id,
          bank_name: b.bank_name || 'Bank Rekening Operasional',
        };
        matchedCount++;
      }
    }

    return {
      updatedBankTxList: updatedBank,
      updatedSettlements: updatedStl,
      matchedCount,
    };
  }

  /**
   * CSV Importer helper: parses CSV lines and maps to Bank or Marketplace records
   */
  static parseCsvToRecords(
    csvText: string,
    delimiter: string = ','
  ): { headers: string[]; rows: Record<string, string>[] } {
    const lines = csvText.split(/\r?\n/).filter(line => line.trim().length > 0);
    if (lines.length === 0) return { headers: [], rows: [] };

    const headers = lines[0].split(delimiter).map(h => h.trim().replace(/^"|"$/g, ''));
    const rows: Record<string, string>[] = [];

    for (let i = 1; i < lines.length; i++) {
      const cols = lines[i].split(delimiter).map(c => c.trim().replace(/^"|"$/g, ''));
      const obj: Record<string, string> = {};
      headers.forEach((h, idx) => {
        obj[h] = cols[idx] || '';
      });
      rows.push(obj);
    }

    return { headers, rows };
  }
}
