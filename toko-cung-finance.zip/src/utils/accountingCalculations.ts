import {
  SalesTransaction,
  HppRecord,
  OpexTransaction,
  AssetRecord,
  NonOperatingTransaction,
  MonthlyPnlRow,
  CashFlowStatementData,
  CapexRequest
} from '../types/finance';

export interface PnlSummary {
  sales: number;
  hpp: number;
  grossProfit: number;
  grossMarginPct: number;
  totalOpex: number;
  ebitda: number;
  ebitdaMarginPct: number;
  totalDepreciation: number;
  ebit: number;
  ebitMarginPct: number;
  nonOperatingIncome: number;
  nonOperatingExpense: number;
  netNonOperating: number;
  ebt: number;
  incomeTax: number;
  netProfit: number;
  netProfitMarginPct: number;
}

export const calculatePnlForMonth = (
  month: number, // 1-12
  year: number,
  entityId: string,
  sales: SalesTransaction[],
  hpp: HppRecord[],
  opex: OpexTransaction[],
  assets: AssetRecord[],
  nonOp: NonOperatingTransaction[],
  taxRatePercent: number = 22,
  channel?: string
): PnlSummary => {
  const matchFilter = (itemDate: string, itemEntity?: string) => {
    if (!itemDate) return false;
    const [y, m] = itemDate.split('-').map(Number);
    if (y !== year || m !== month) return false;
    if (entityId !== 'ALL' && itemEntity && itemEntity !== entityId) return false;
    return true;
  };

  // 1. Sales (filtered by channel if specified)
  const filteredSales = sales.filter(s => {
    if (s.status === 'Dibatalkan') return false;
    if (!matchFilter(s.date, s.entityId)) return false;
    if (channel && channel !== 'ALL') {
      const sChan = s.salesChannel || (s.source_platform ? s.source_platform.toUpperCase() : 'OFFLINE');
      if (sChan !== channel) return false;
    }
    return true;
  });
  const totalSales = filteredSales.reduce((acc, s) => acc + s.totalSales, 0);

  // 2. HPP
  const filteredHpp = hpp.filter(h => matchFilter(h.date));
  const totalHpp = filteredHpp.reduce((acc, h) => acc + h.totalHpp, 0);

  // 3. Gross Profit
  const grossProfit = totalSales - totalHpp;
  const grossMarginPct = totalSales > 0 ? (grossProfit / totalSales) * 100 : 0;

  // 4. OPEX
  const filteredOpex = opex.filter(o => o.status !== 'Draft' && matchFilter(o.date, o.entityId));
  const totalOpex = filteredOpex.reduce((acc, o) => acc + o.total, 0);

  // 5. EBITDA
  const ebitda = grossProfit - totalOpex;
  const ebitdaMarginPct = totalSales > 0 ? (ebitda / totalSales) * 100 : 0;

  // 6. Depreciation (calculated per active asset active in that month/year)
  const totalDepreciation = assets.reduce((acc, asset) => {
    if (asset.status !== 'Active' && asset.status !== 'Under Maintenance') return acc;
    const [acqY, acqM] = asset.acquisitionDate.split('-').map(Number);
    const assetDateNum = acqY * 12 + acqM;
    const targetDateNum = year * 12 + month;
    if (targetDateNum >= assetDateNum) {
      return acc + asset.monthlyDepreciation;
    }
    return acc;
  }, 0);

  // 7. EBIT / Management Profit
  const ebit = ebitda - totalDepreciation;
  const ebitMarginPct = totalSales > 0 ? (ebit / totalSales) * 100 : 0;

  // 8. Non-Operating
  const filteredNonOp = nonOp.filter(n => matchFilter(n.date, n.entityId));
  let nonOperatingIncome = 0;
  let nonOperatingExpense = 0;

  filteredNonOp.forEach(item => {
    if (item.category === 'Pendapatan Bunga' || item.category === 'Pendapatan Lainnya') {
      nonOperatingIncome += item.amount;
    } else {
      nonOperatingExpense += item.amount;
    }
  });

  const netNonOperating = nonOperatingIncome - nonOperatingExpense;

  // 9. EBT (Income Before Tax)
  const ebt = ebit + netNonOperating;

  // 10. Income Tax
  const incomeTax = ebt > 0 ? (ebt * (taxRatePercent / 100)) : 0;

  // 11. NET PROFIT
  const netProfit = ebt - incomeTax;
  const netProfitMarginPct = totalSales > 0 ? (netProfit / totalSales) * 100 : 0;

  return {
    sales: totalSales,
    hpp: totalHpp,
    grossProfit,
    grossMarginPct,
    totalOpex,
    ebitda,
    ebitdaMarginPct,
    totalDepreciation,
    ebit,
    ebitMarginPct,
    nonOperatingIncome,
    nonOperatingExpense,
    netNonOperating,
    ebt,
    incomeTax,
    netProfit,
    netProfitMarginPct,
  };
};

export const generateMonthlyIncomeStatementTable = (
  year: number,
  entityId: string,
  sales: SalesTransaction[],
  hpp: HppRecord[],
  opex: OpexTransaction[],
  assets: AssetRecord[],
  nonOp: NonOperatingTransaction[],
  taxRatePercent: number = 22,
  channel?: string
): MonthlyPnlRow[] => {
  const monthsData: PnlSummary[] = [];
  for (let m = 1; m <= 12; m++) {
    monthsData.push(calculatePnlForMonth(m, year, entityId, sales, hpp, opex, assets, nonOp, taxRatePercent, channel));
  }

  const sumValues = (selector: (p: PnlSummary) => number): number[] => {
    return monthsData.map(selector);
  };

  const sumTotal = (arr: number[]): number => arr.reduce((a, b) => a + b, 0);

  const salesValues = sumValues(p => p.sales);
  const hppValues = sumValues(p => p.hpp);
  const gpValues = sumValues(p => p.grossProfit);
  const opexValues = sumValues(p => p.totalOpex);
  const ebitdaValues = sumValues(p => p.ebitda);
  const deprValues = sumValues(p => p.totalDepreciation);
  const ebitValues = sumValues(p => p.ebit);
  const nonOpValues = sumValues(p => p.netNonOperating);
  const ebtValues = sumValues(p => p.ebt);
  const taxValues = sumValues(p => p.incomeTax);
  const netProfitValues = sumValues(p => p.netProfit);

  const ytdSales = sumTotal(salesValues);
  const ytdHpp = sumTotal(hppValues);
  const ytdGp = ytdSales - ytdHpp;
  const ytdOpex = sumTotal(opexValues);
  const ytdEbitda = ytdGp - ytdOpex;
  const ytdDepr = sumTotal(deprValues);
  const ytdEbit = ytdEbitda - ytdDepr;
  const ytdNonOp = sumTotal(nonOpValues);
  const ytdEbt = ytdEbit + ytdNonOp;
  const ytdTax = sumTotal(taxValues);
  const ytdNetProfit = ytdEbt - ytdTax;

  const gmValues = salesValues.map((s, idx) => (s > 0 ? (gpValues[idx] / s) * 100 : 0));
  const ytdGm = ytdSales > 0 ? (ytdGp / ytdSales) * 100 : 0;

  const npMarginValues = salesValues.map((s, idx) => (s > 0 ? (netProfitValues[idx] / s) * 100 : 0));
  const ytdNpMargin = ytdSales > 0 ? (ytdNetProfit / ytdSales) * 100 : 0;

  return [
    {
      label: 'PENJUALAN (SALES)',
      level: 'sales',
      isHeader: true,
      values: salesValues,
      ytd: ytdSales,
    },
    {
      label: 'HARGA POKOK PENJUALAN (HPP / COGS)',
      level: 'cogs',
      isIndent: true,
      values: hppValues,
      ytd: ytdHpp,
    },
    {
      label: 'LABA KOTOR (GROSS PROFIT)',
      level: 'gross_profit',
      isTotal: true,
      values: gpValues,
      ytd: ytdGp,
    },
    {
      label: 'Margin Laba Kotor (Gross Margin %)',
      level: 'gross_margin',
      isPercentage: true,
      values: gmValues,
      ytd: ytdGm,
    },
    {
      label: 'BIAYA OPERASIONAL (TOTAL OPEX)',
      level: 'opex',
      isIndent: true,
      values: opexValues,
      ytd: ytdOpex,
    },
    {
      label: 'EBITDA (Gross Profit - Total OPEX)',
      level: 'ebitda',
      isTotal: true,
      values: ebitdaValues,
      ytd: ytdEbitda,
    },
    {
      label: 'Beban Penyusutan (Total Depreciation)',
      level: 'depreciation',
      isIndent: true,
      values: deprValues,
      ytd: ytdDepr,
    },
    {
      label: 'EBIT / MANAGEMENT PROFIT (EBITDA - Depreciation)',
      level: 'ebit',
      isTotal: true,
      values: ebitValues,
      ytd: ytdEbit,
    },
    {
      label: 'Pendapatan / (Beban) Non-Operasional',
      level: 'non_operating',
      isIndent: true,
      values: nonOpValues,
      ytd: ytdNonOp,
    },
    {
      label: 'LABA SEBELUM PAJAK (EBT)',
      level: 'ebt',
      isTotal: true,
      values: ebtValues,
      ytd: ytdEbt,
    },
    {
      label: 'Pajak Penghasilan (Income Tax)',
      level: 'tax',
      isIndent: true,
      values: taxValues,
      ytd: ytdTax,
    },
    {
      label: 'LABA BERSIH (NET PROFIT)',
      level: 'net_profit',
      isTotal: true,
      values: netProfitValues,
      ytd: ytdNetProfit,
    },
    {
      label: 'Margin Laba Bersih (Net Profit Margin %)',
      level: 'net_margin',
      isPercentage: true,
      values: npMarginValues,
      ytd: ytdNpMargin,
    },
  ];
};

export const calculateCashFlowStatement = (
  pnl: PnlSummary,
  capexRequests: CapexRequest[],
  beginningCash: number = 850_000_000
): CashFlowStatementData => {
  // Operating Cash Flow = Net Profit + Depreciation + Working Capital Adjustments
  // Working capital adjustment simulation (Accounts Receivable / Inventory delta ~ 5-10% of gross profit)
  const workingCapitalChange = Math.round(pnl.netProfit * -0.05);
  const operatingCashTotal = pnl.netProfit + pnl.totalDepreciation + workingCapitalChange;

  // Investing Cash Flow = - CAPEX Paid Outflow
  const capexPaid = capexRequests
    .filter(c => c.status === 'Paid' || c.status === 'Asset Created')
    .reduce((sum, c) => sum + c.acquisitionCost, 0);
  const investingCashTotal = -capexPaid;

  // Financing Cash Flow
  const debtMovement = 0;
  const equityMovement = 0;
  const financingCashTotal = debtMovement + equityMovement;

  const netCashFlow = operatingCashTotal + investingCashTotal + financingCashTotal;
  const endingCash = beginningCash + netCashFlow;

  return {
    beginningCash,
    operatingCashFlow: {
      netProfit: pnl.netProfit,
      depreciation: pnl.totalDepreciation,
      workingCapitalChange,
      total: operatingCashTotal,
    },
    investingCashFlow: {
      capexOutflow: capexPaid,
      total: investingCashTotal,
    },
    financingCashFlow: {
      debtMovement,
      equityMovement,
      total: financingCashTotal,
    },
    netCashFlow,
    endingCash,
  };
};
