export const formatRupiah = (value: number | undefined | null, withPrefix = true): string => {
  if (value === undefined || value === null || isNaN(value)) {
    return withPrefix ? 'Rp 0' : '0';
  }
  const isNegative = value < 0;
  const absValue = Math.round(Math.abs(value));
  const formatted = new Intl.NumberFormat('id-ID').format(absValue);
  
  if (isNegative) {
    return withPrefix ? `-Rp ${formatted}` : `-${formatted}`;
  }
  return withPrefix ? `Rp ${formatted}` : formatted;
};

export const formatCompactRupiah = (value: number): string => {
  if (isNaN(value)) return 'Rp 0';
  const isNegative = value < 0;
  const abs = Math.abs(value);
  let res = '';
  if (abs >= 1_000_000_000) {
    res = `${(abs / 1_000_000_000).toFixed(1)} M`;
  } else if (abs >= 1_000_000) {
    res = `${(abs / 1_000_000).toFixed(1)} Jt`;
  } else if (abs >= 1_000) {
    res = `${(abs / 1_000).toFixed(0)} Rb`;
  } else {
    res = abs.toString();
  }
  return `${isNegative ? '-' : ''}Rp ${res}`;
};

export const formatPercent = (value: number | undefined | null, decimals = 1): string => {
  if (value === undefined || value === null || isNaN(value)) return '0.0%';
  return `${value.toFixed(decimals)}%`;
};

export const formatDate = (dateStr: string): string => {
  if (!dateStr) return '-';
  try {
    const d = new Date(dateStr);
    return new Intl.DateTimeFormat('id-ID', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    }).format(d);
  } catch {
    return dateStr;
  }
};

export const MONTH_NAMES_ID = [
  'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
  'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
];

export const MONTH_SHORT_ID = [
  'Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun',
  'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'
];

export const downloadCSV = (filename: string, headers: string[], rows: (string | number)[][]) => {
  const processCell = (cell: string | number) => {
    if (typeof cell === 'string') {
      const escaped = cell.replace(/"/g, '""');
      return `"${escaped}"`;
    }
    return cell;
  };

  const csvContent = [
    headers.map(processCell).join(','),
    ...rows.map(row => row.map(processCell).join(','))
  ].join('\r\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `${filename}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
};

export const printReport = () => {
  window.print();
};
