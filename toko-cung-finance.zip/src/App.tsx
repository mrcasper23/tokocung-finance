import React, { useState } from 'react';
import { FinanceProvider, useFinance } from './context/FinanceContext';
import { Header } from './components/layout/Header';
import { Sidebar, NavModuleId } from './components/layout/Sidebar';

// Executive
import { ExecutiveDashboard } from './components/dashboard/ExecutiveDashboard';
import { FinancialSummary } from './components/dashboard/FinancialSummary';
import { MonthlyIncomeStatement } from './components/dashboard/MonthlyIncomeStatement';

// Cash & Kasbon
import { CashDashboard } from './components/cash/CashDashboard';
import { KasbonDebitur } from './components/cash/KasbonDebitur';
import { MutasiKas } from './components/cash/MutasiKas';
import { KasbonPelunasan } from './components/cash/KasbonPelunasan';

// Purchase Monitoring
import { PurchaseMonitor } from './components/purchase/PurchaseMonitor';
import { PurchaseOrders } from './components/purchase/PurchaseOrders';
import { PriceAdjustments } from './components/purchase/PriceAdjustments';

// Expenses
import { OpexDashboard } from './components/expenses/OpexDashboard';
import { ExpenseCategories } from './components/expenses/ExpenseCategories';
import { PaymentRequests } from './components/expenses/PaymentRequests';
import { CapexDashboard } from './components/expenses/CapexDashboard';
import { CapexPaymentRequests } from './components/expenses/CapexPaymentRequests';
import { AssetRegister } from './components/expenses/AssetRegister';
import { DepreciationSchedule } from './components/expenses/DepreciationSchedule';
import { CapexReport } from './components/expenses/CapexReport';

// Accounting
import { SalesModule } from './components/accounting/SalesModule';
import { HppModule } from './components/accounting/HppModule';
import { NonOperatingModule } from './components/accounting/NonOperatingModule';
import { PajakModule } from './components/accounting/PajakModule';
import { PayrollModule } from './components/accounting/PayrollModule';
import { ArusKasModule } from './components/accounting/ArusKasModule';
import { LaporanKeuanganModule } from './components/accounting/LaporanKeuanganModule';

// Administration
import { UsersModule } from './components/admin/UsersModule';
import { RolesPermissionsModule } from './components/admin/RolesPermissionsModule';
import { MasterDataModule } from './components/admin/MasterDataModule';
import { AuditLogModule } from './components/admin/AuditLogModule';
import { SettingsModule } from './components/admin/SettingsModule';

const MODULE_TITLES: Record<NavModuleId, string> = {
  'executive-dashboard': 'Executive Dashboard',
  'financial-summary': 'Ringkasan Keuangan',
  'monthly-pnl': 'Monthly Income Statement',
  'cash-dashboard': 'Dashboard Kas & Kasbon',
  'kasbon-debitur': 'Debitur Kasbon',
  'mutasi-kas': 'Mutasi Kas & Bank',
  'kasbon-pelunasan': 'Pelunasan Kasbon',
  'purchase-monitor': 'Purchase Monitor',
  'purchase-orders': 'Purchase Orders',
  'price-adjustments': 'Price Adjustments',
  'opex-dashboard': 'OPEX Dashboard',
  'expense-categories': 'Expense Categories',
  'payment-requests': 'Payment Request',
  'capex-dashboard': 'CAPEX Dashboard',
  'capex-payment-requests': 'CAPEX Payment Request',
  'asset-register': 'Asset Register',
  'depreciation-schedule': 'Depreciation Schedule',
  'capex-report': 'CAPEX Report',
  'sales': 'Sales (Penjualan)',
  'hpp': 'HPP (Harga Pokok Penjualan)',
  'non-operating': 'Non Operating',
  'pajak': 'Pajak (Income Tax)',
  'payroll': 'Payroll & Upah',
  'arus-kas': 'Arus Kas (Cash Flow)',
  'laporan-keuangan': 'Laporan Keuangan',
  'users': 'Users',
  'roles-permissions': 'Roles & Permissions',
  'master-data': 'Master Data',
  'audit-log': 'Audit Log',
  'pengaturan': 'Pengaturan Sistem',
};

function AppContent() {
  const [activeModule, setActiveModule] = useState<NavModuleId>('executive-dashboard');
  const [quickSalesModal, setQuickSalesModal] = useState(false);
  const [quickOpexModal, setQuickOpexModal] = useState(false);

  const renderActiveModule = () => {
    switch (activeModule) {
      // Executive
      case 'executive-dashboard':
        return (
          <ExecutiveDashboard
            onNavigate={setActiveModule}
            onOpenNewSales={() => setActiveModule('sales')}
            onOpenNewOpex={() => setActiveModule('opex-dashboard')}
          />
        );
      case 'financial-summary':
        return <FinancialSummary />;
      case 'monthly-pnl':
        return <MonthlyIncomeStatement />;

      // Cash / Kasbon
      case 'cash-dashboard':
        return <CashDashboard />;
      case 'kasbon-debitur':
        return <KasbonDebitur />;
      case 'mutasi-kas':
        return <MutasiKas />;
      case 'kasbon-pelunasan':
        return <KasbonPelunasan />;

      // Purchase Monitoring
      case 'purchase-monitor':
        return <PurchaseMonitor />;
      case 'purchase-orders':
        return <PurchaseOrders />;
      case 'price-adjustments':
        return <PriceAdjustments />;

      // Expenses
      case 'opex-dashboard':
        return <OpexDashboard />;
      case 'expense-categories':
        return <ExpenseCategories />;
      case 'payment-requests':
        return <PaymentRequests />;
      case 'capex-dashboard':
        return <CapexDashboard />;
      case 'capex-payment-requests':
        return <CapexPaymentRequests />;
      case 'asset-register':
        return <AssetRegister />;
      case 'depreciation-schedule':
        return <DepreciationSchedule />;
      case 'capex-report':
        return <CapexReport />;

      // Accounting
      case 'sales':
        return <SalesModule />;
      case 'hpp':
        return <HppModule />;
      case 'non-operating':
        return <NonOperatingModule />;
      case 'pajak':
        return <PajakModule />;
      case 'payroll':
        return <PayrollModule />;
      case 'arus-kas':
        return <ArusKasModule />;
      case 'laporan-keuangan':
        return <LaporanKeuanganModule />;

      // Administration
      case 'users':
        return <UsersModule />;
      case 'roles-permissions':
        return <RolesPermissionsModule />;
      case 'master-data':
        return <MasterDataModule />;
      case 'audit-log':
        return <AuditLogModule />;
      case 'pengaturan':
        return <SettingsModule />;

      default:
        return (
          <ExecutiveDashboard
            onNavigate={setActiveModule}
            onOpenNewSales={() => setActiveModule('sales')}
            onOpenNewOpex={() => setActiveModule('opex-dashboard')}
          />
        );
    }
  };

  return (
    <div className="min-h-screen bg-slate-100/60 flex">
      {/* Sidebar Navigation */}
      <Sidebar activeModule={activeModule} onSelectModule={setActiveModule} />

      {/* Main Viewport Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        <Header currentModuleTitle={MODULE_TITLES[activeModule]} />
        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-[1600px] w-full mx-auto">
          {renderActiveModule()}
        </main>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <FinanceProvider>
      <AppContent />
    </FinanceProvider>
  );
}
