import React, { createContext, useContext, useState, useEffect, useMemo, useCallback } from 'react';
import {
  Entity,
  User,
  Product,
  Customer,
  Vendor,
  SalesTransaction,
  HppRecord,
  OpexTransaction,
  PaymentRequest,
  PaymentRequestStatus,
  CapexRequest,
  CapexStatus,
  AssetRecord,
  NonOperatingTransaction,
  TaxTransaction,
  PayrollRecord,
  KasbonDebitur,
  KasbonTransaction,
  CashMutation,
  PurchaseOrder,
  PriceAdjustment,
  BudgetRecord,
  AuditLog,
  GlobalFilter,
  MonthlyPnlRow,
  CashFlowStatementData,
  UserRole,
  SalesChannel
} from '../types/finance';
import {
  BankConnection,
  BankTransaction,
  MarketplaceConnection,
  MarketplaceOrder,
  MarketplaceTransaction,
  ChannelSkuMapping,
  MarketplaceSettlement,
  IntegrationRawEvent,
  SyncBatch,
  FeeCategoryMapping,
  BankAutoRule,
  IntegrationSettings,
  SyncType
} from '../types/integration';
import {
  INITIAL_ENTITIES,
  INITIAL_USERS,
  INITIAL_PRODUCTS,
  INITIAL_CUSTOMERS,
  INITIAL_VENDORS,
  INITIAL_SALES,
  INITIAL_HPP,
  INITIAL_OPEX,
  INITIAL_PAYMENT_REQUESTS,
  INITIAL_CAPEX_REQUESTS,
  INITIAL_ASSETS,
  INITIAL_NON_OPERATING,
  INITIAL_TAX_TRANSACTIONS,
  INITIAL_PAYROLL,
  INITIAL_DEBITUR_KASBON,
  INITIAL_KASBON_TRANSACTIONS,
  INITIAL_CASH_MUTATIONS,
  INITIAL_PURCHASE_ORDERS,
  INITIAL_PRICE_ADJUSTMENTS,
  INITIAL_BUDGETS,
  INITIAL_AUDIT_LOGS,
} from '../data/initialData';
import {
  INITIAL_BANK_CONNECTIONS,
  INITIAL_MARKETPLACE_CONNECTIONS,
  INITIAL_BANK_TRANSACTIONS,
  INITIAL_MARKETPLACE_ORDERS,
  INITIAL_MARKETPLACE_TRANSACTIONS,
  INITIAL_CHANNEL_SKU_MAPPINGS,
  INITIAL_MARKETPLACE_SETTLEMENTS,
  INITIAL_SYNC_BATCHES,
  INITIAL_RAW_EVENTS,
  INITIAL_FEE_MAPPINGS,
  INITIAL_BANK_RULES,
  INITIAL_INTEGRATION_SETTINGS
} from '../data/integrationData';
import {
  calculatePnlForMonth,
  generateMonthlyIncomeStatementTable,
  calculateCashFlowStatement,
  PnlSummary
} from '../utils/accountingCalculations';
import { IntegrationSyncService } from '../services/IntegrationSyncService';

interface AppSettings {
  taxRatePercent: number;
  companyName: string;
  currency: string;
}

interface FinanceContextType {
  entities: Entity[];
  users: User[];
  currentUser: User;
  setCurrentUser: (user: User) => void;
  products: Product[];
  customers: Customer[];
  vendors: Vendor[];
  sales: SalesTransaction[];
  hpp: HppRecord[];
  opex: OpexTransaction[];
  paymentRequests: PaymentRequest[];
  capexRequests: CapexRequest[];
  assets: AssetRecord[];
  nonOperating: NonOperatingTransaction[];
  taxes: TaxTransaction[];
  payrolls: PayrollRecord[];
  debiturKasbon: KasbonDebitur[];
  kasbonTransactions: KasbonTransaction[];
  cashMutations: CashMutation[];
  purchaseOrders: PurchaseOrder[];
  priceAdjustments: PriceAdjustment[];
  budgets: BudgetRecord[];
  auditLogs: AuditLog[];
  
  // Integration Hub State
  bankConnections: BankConnection[];
  bankTransactions: BankTransaction[];
  marketplaceConnections: MarketplaceConnection[];
  marketplaceOrders: MarketplaceOrder[];
  marketplaceTransactions: MarketplaceTransaction[];
  channelSkuMappings: ChannelSkuMapping[];
  marketplaceSettlements: MarketplaceSettlement[];
  syncBatches: SyncBatch[];
  rawEvents: IntegrationRawEvent[];
  feeMappings: FeeCategoryMapping[];
  bankRules: BankAutoRule[];
  integrationSettings: IntegrationSettings;

  globalFilter: GlobalFilter;
  setGlobalFilter: React.Dispatch<React.SetStateAction<GlobalFilter>>;
  resetFilter: () => void;
  
  settings: AppSettings;
  updateSettings: (newSettings: Partial<AppSettings>) => void;
  resetToDemoData: () => void;

  // Actions
  addSales: (tx: Omit<SalesTransaction, 'id'>) => void;
  addHpp: (rec: Omit<HppRecord, 'id'>) => void;
  addOpex: (opx: Omit<OpexTransaction, 'id' | 'opexNumber'>) => void;
  createPaymentRequest: (pr: Omit<PaymentRequest, 'id' | 'prNumber' | 'createdAt'>) => void;
  updatePaymentRequestStatus: (id: string, newStatus: PaymentRequestStatus) => void;
  createCapexRequest: (cpx: Omit<CapexRequest, 'id' | 'capexNumber'>) => void;
  updateCapexStatus: (id: string, newStatus: CapexStatus) => void;
  addAsset: (asset: Omit<AssetRecord, 'id' | 'monthlyDepreciation' | 'accumulatedDepreciation' | 'bookValue'>) => void;
  addNonOperating: (nonOp: Omit<NonOperatingTransaction, 'id'>) => void;
  addTax: (tax: Omit<TaxTransaction, 'id'>) => void;
  addPayroll: (pay: Omit<PayrollRecord, 'id'>) => void;
  addKasbonTransaction: (tx: Omit<KasbonTransaction, 'id' | 'transactionNumber'>) => void;
  repayKasbon: (txId: string, amount: number) => void;
  addCashMutation: (mut: Omit<CashMutation, 'id'>) => void;
  addPurchaseOrder: (po: Omit<PurchaseOrder, 'id'>) => void;
  addPriceAdjustment: (adj: Omit<PriceAdjustment, 'id'>) => void;

  // Integration Hub Actions
  runSync: (platformOrId: string, syncType: SyncType) => Promise<void>;
  importBankCsv: (csvText: string, bankConnectionId: string) => number;
  importMarketplaceCsv: (csvText: string, connectionId: string, platform: any) => number;
  connectBank: (connectionData: Partial<BankConnection>) => void;
  disconnectBank: (id: string) => void;
  connectMarketplace: (connectionData: Partial<MarketplaceConnection>) => void;
  disconnectMarketplace: (id: string) => void;
  updateChannelSkuMapping: (id: string, internalSku: string, internalProductId?: string) => void;
  reconcileSettlementWithBank: (settlementId: string, bankTxId: string) => void;
  unmatchReconciliation: (settlementId: string) => void;
  executeAutoMatch: () => number;
  updateIntegrationSettings: (newSettings: Partial<IntegrationSettings>) => void;
  addWebhookSimulation: (provider: string, eventType: string, payload: any) => void;
  
  // Computed Engine Values
  currentMonthPnl: PnlSummary;
  prevMonthPnl: PnlSummary;
  prevYearPnl: PnlSummary;
  yearlyPnlSummary: PnlSummary;
  monthlyPnlTable: MonthlyPnlRow[];
  cashFlowStatement: CashFlowStatementData;
  twelveMonthsPnl: PnlSummary[];
  hasRole: (allowedRoles: UserRole[]) => boolean;
}

const FinanceContext = createContext<FinanceContextType | undefined>(undefined);

const LOCAL_STORAGE_KEY = 'toko_cung_finance_store_v1';

export const FinanceProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [entities] = useState<Entity[]>(INITIAL_ENTITIES);
  const [users] = useState<User[]>(INITIAL_USERS);
  const [currentUser, setCurrentUser] = useState<User>(INITIAL_USERS[0]); // Default Director

  const [products] = useState<Product[]>(INITIAL_PRODUCTS);
  const [customers] = useState<Customer[]>(INITIAL_CUSTOMERS);
  const [vendors] = useState<Vendor[]>(INITIAL_VENDORS);

  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const saved = localStorage.getItem(`${LOCAL_STORAGE_KEY}_settings`);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return { taxRatePercent: 22, companyName: 'TOKO CUNG FINANCE', currency: 'IDR' };
  });

  const [globalFilter, setGlobalFilter] = useState<GlobalFilter>({
    entityId: 'ALL',
    period: 'Bulanan',
    month: 3, // March 2026 default for active demo month
    year: 2026,
  });

  // State persistence or fallback to rich initial data
  const [sales, setSales] = useState<SalesTransaction[]>(() => {
    try {
      const s = localStorage.getItem(`${LOCAL_STORAGE_KEY}_sales`);
      if (s) return JSON.parse(s);
    } catch {}
    return INITIAL_SALES;
  });

  const [hpp, setHpp] = useState<HppRecord[]>(() => {
    try {
      const s = localStorage.getItem(`${LOCAL_STORAGE_KEY}_hpp`);
      if (s) return JSON.parse(s);
    } catch {}
    return INITIAL_HPP;
  });

  const [opex, setOpex] = useState<OpexTransaction[]>(() => {
    try {
      const s = localStorage.getItem(`${LOCAL_STORAGE_KEY}_opex`);
      if (s) return JSON.parse(s);
    } catch {}
    return INITIAL_OPEX;
  });

  const [paymentRequests, setPaymentRequests] = useState<PaymentRequest[]>(() => {
    try {
      const s = localStorage.getItem(`${LOCAL_STORAGE_KEY}_payment_requests`);
      if (s) return JSON.parse(s);
    } catch {}
    return INITIAL_PAYMENT_REQUESTS;
  });

  const [capexRequests, setCapexRequests] = useState<CapexRequest[]>(() => {
    try {
      const s = localStorage.getItem(`${LOCAL_STORAGE_KEY}_capex_requests`);
      if (s) return JSON.parse(s);
    } catch {}
    return INITIAL_CAPEX_REQUESTS;
  });

  const [assets, setAssets] = useState<AssetRecord[]>(() => {
    try {
      const s = localStorage.getItem(`${LOCAL_STORAGE_KEY}_assets`);
      if (s) return JSON.parse(s);
    } catch {}
    return INITIAL_ASSETS;
  });

  const [nonOperating, setNonOperating] = useState<NonOperatingTransaction[]>(() => {
    try {
      const s = localStorage.getItem(`${LOCAL_STORAGE_KEY}_non_operating`);
      if (s) return JSON.parse(s);
    } catch {}
    return INITIAL_NON_OPERATING;
  });

  const [taxes, setTaxes] = useState<TaxTransaction[]>(() => {
    try {
      const s = localStorage.getItem(`${LOCAL_STORAGE_KEY}_taxes`);
      if (s) return JSON.parse(s);
    } catch {}
    return INITIAL_TAX_TRANSACTIONS;
  });

  const [payrolls, setPayrolls] = useState<PayrollRecord[]>(() => {
    try {
      const s = localStorage.getItem(`${LOCAL_STORAGE_KEY}_payrolls`);
      if (s) return JSON.parse(s);
    } catch {}
    return INITIAL_PAYROLL;
  });

  const [debiturKasbon, setDebiturKasbon] = useState<KasbonDebitur[]>(INITIAL_DEBITUR_KASBON);
  const [kasbonTransactions, setKasbonTransactions] = useState<KasbonTransaction[]>(INITIAL_KASBON_TRANSACTIONS);
  const [cashMutations, setCashMutations] = useState<CashMutation[]>(INITIAL_CASH_MUTATIONS);
  const [purchaseOrders, setPurchaseOrders] = useState<PurchaseOrder[]>(INITIAL_PURCHASE_ORDERS);
  const [priceAdjustments, setPriceAdjustments] = useState<PriceAdjustment[]>(INITIAL_PRICE_ADJUSTMENTS);
  const [budgets] = useState<BudgetRecord[]>(INITIAL_BUDGETS);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(INITIAL_AUDIT_LOGS);

  // Integration Hub State
  const [bankConnections, setBankConnections] = useState<BankConnection[]>(INITIAL_BANK_CONNECTIONS);
  const [bankTransactions, setBankTransactions] = useState<BankTransaction[]>(INITIAL_BANK_TRANSACTIONS);
  const [marketplaceConnections, setMarketplaceConnections] = useState<MarketplaceConnection[]>(INITIAL_MARKETPLACE_CONNECTIONS);
  const [marketplaceOrders, setMarketplaceOrders] = useState<MarketplaceOrder[]>(INITIAL_MARKETPLACE_ORDERS);
  const [marketplaceTransactions, setMarketplaceTransactions] = useState<MarketplaceTransaction[]>(INITIAL_MARKETPLACE_TRANSACTIONS);
  const [channelSkuMappings, setChannelSkuMappings] = useState<ChannelSkuMapping[]>(INITIAL_CHANNEL_SKU_MAPPINGS);
  const [marketplaceSettlements, setMarketplaceSettlements] = useState<MarketplaceSettlement[]>(INITIAL_MARKETPLACE_SETTLEMENTS);
  const [syncBatches, setSyncBatches] = useState<SyncBatch[]>(INITIAL_SYNC_BATCHES);
  const [rawEvents, setRawEvents] = useState<IntegrationRawEvent[]>(INITIAL_RAW_EVENTS);
  const [feeMappings, setFeeMappings] = useState<FeeCategoryMapping[]>(INITIAL_FEE_MAPPINGS);
  const [bankRules, setBankRules] = useState<BankAutoRule[]>(INITIAL_BANK_RULES);
  const [integrationSettings, setIntegrationSettings] = useState<IntegrationSettings>(INITIAL_INTEGRATION_SETTINGS);

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(`${LOCAL_STORAGE_KEY}_sales`, JSON.stringify(sales));
      localStorage.setItem(`${LOCAL_STORAGE_KEY}_hpp`, JSON.stringify(hpp));
      localStorage.setItem(`${LOCAL_STORAGE_KEY}_opex`, JSON.stringify(opex));
      localStorage.setItem(`${LOCAL_STORAGE_KEY}_payment_requests`, JSON.stringify(paymentRequests));
      localStorage.setItem(`${LOCAL_STORAGE_KEY}_capex_requests`, JSON.stringify(capexRequests));
      localStorage.setItem(`${LOCAL_STORAGE_KEY}_assets`, JSON.stringify(assets));
      localStorage.setItem(`${LOCAL_STORAGE_KEY}_non_operating`, JSON.stringify(nonOperating));
      localStorage.setItem(`${LOCAL_STORAGE_KEY}_taxes`, JSON.stringify(taxes));
      localStorage.setItem(`${LOCAL_STORAGE_KEY}_settings`, JSON.stringify(settings));
    } catch {
      // storage unavailable or full
    }
  }, [sales, hpp, opex, paymentRequests, capexRequests, assets, nonOperating, taxes, settings]);

  const addAuditLog = useCallback((action: AuditLog['action'], module: string, recordId: string, details: string) => {
    const newLog: AuditLog = {
      id: `aud-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      action,
      module,
      recordId,
      userName: currentUser.name,
      userRole: currentUser.role,
      details,
    };
    setAuditLogs(prev => [newLog, ...prev]);
  }, [currentUser]);

  const resetFilter = () => {
    setGlobalFilter({
      entityId: 'ALL',
      period: 'Bulanan',
      month: 3,
      year: 2026,
    });
  };

  const updateSettings = (newSettings: Partial<AppSettings>) => {
    setSettings(prev => {
      const updated = { ...prev, ...newSettings };
      addAuditLog('Edited', 'Settings', 'CFG-APP', `Mengubah pengaturan konfigurasi aplikasi`);
      return updated;
    });
  };

  const resetToDemoData = () => {
    setSales(INITIAL_SALES);
    setHpp(INITIAL_HPP);
    setOpex(INITIAL_OPEX);
    setPaymentRequests(INITIAL_PAYMENT_REQUESTS);
    setCapexRequests(INITIAL_CAPEX_REQUESTS);
    setAssets(INITIAL_ASSETS);
    setNonOperating(INITIAL_NON_OPERATING);
    setTaxes(INITIAL_TAX_TRANSACTIONS);
    setPayrolls(INITIAL_PAYROLL);
    setDebiturKasbon(INITIAL_DEBITUR_KASBON);
    setKasbonTransactions(INITIAL_KASBON_TRANSACTIONS);
    setCashMutations(INITIAL_CASH_MUTATIONS);
    setPurchaseOrders(INITIAL_PURCHASE_ORDERS);
    setPriceAdjustments(INITIAL_PRICE_ADJUSTMENTS);
    setAuditLogs(INITIAL_AUDIT_LOGS);
    addAuditLog('Created', 'Database', 'DEMO-RESET', 'Reset data aplikasi ke DATA DEMO lengkap 2026');
  };

  const hasRole = (allowedRoles: UserRole[]) => {
    return allowedRoles.includes(currentUser.role);
  };

  // Add Sales
  const addSales = (tx: Omit<SalesTransaction, 'id'>) => {
    const id = `sls-${Date.now()}`;
    const newTx: SalesTransaction = { ...tx, id };
    setSales(prev => [newTx, ...prev]);
    addAuditLog('Created', 'Sales', tx.transactionNumber, `Input penjualan ${tx.productName} senilai Rp ${tx.totalSales.toLocaleString('id-ID')}`);
  };

  // Add HPP
  const addHpp = (rec: Omit<HppRecord, 'id'>) => {
    const id = `hpp-${Date.now()}`;
    const newRec: HppRecord = { ...rec, id };
    setHpp(prev => [newRec, ...prev]);
    addAuditLog('Created', 'HPP', rec.sku, `Input HPP ${rec.productName} total Rp ${rec.totalHpp.toLocaleString('id-ID')}`);
  };

  // Add OPEX
  const addOpex = (opxData: Omit<OpexTransaction, 'id' | 'opexNumber'>) => {
    const id = `opx-${Date.now()}`;
    const month = opxData.date.split('-')[1] || '03';
    const num = `OPX-2026-${month}-${Math.floor(100 + Math.random() * 900)}`;
    const newOpx: OpexTransaction = {
      ...opxData,
      id,
      opexNumber: num,
    };
    setOpex(prev => [newOpx, ...prev]);
    addAuditLog('Created', 'OPEX', num, `Biaya operasional ${newOpx.category}: ${newOpx.description}`);
  };

  // Payment Request Workflow: Draft -> Submitted -> Reviewed -> Approved -> Paid -> Completed
  const createPaymentRequest = (prData: Omit<PaymentRequest, 'id' | 'prNumber' | 'createdAt'>) => {
    const id = `pr-${Date.now()}`;
    const prNumber = `PR-2026-${Math.floor(100 + Math.random() * 900)}`;
    const newPr: PaymentRequest = {
      ...prData,
      id,
      prNumber,
      createdAt: new Date().toISOString().substring(0, 10),
    };
    setPaymentRequests(prev => [newPr, ...prev]);
    addAuditLog('Created', 'Payment Request', prNumber, `Membuat Payment Request: ${prData.purpose}`);
  };

  const updatePaymentRequestStatus = (id: string, newStatus: PaymentRequestStatus) => {
    setPaymentRequests(prev => {
      const item = prev.find(p => p.id === id);
      if (!item) return prev;

      const updated = prev.map(p => {
        if (p.id === id) {
          const mod = { ...p, status: newStatus };
          if (newStatus === 'Reviewed') mod.reviewedBy = currentUser.name;
          if (newStatus === 'Approved') mod.approvedBy = currentUser.name;
          return mod;
        }
        return p;
      });

      addAuditLog(
        newStatus === 'Approved' ? 'Approved' : newStatus === 'Paid' ? 'Paid' : 'Edited',
        'Payment Request',
        item.prNumber,
        `Status Payment Request diubah menjadi ${newStatus} oleh ${currentUser.name}`
      );

      // AUTOMATIC ACCOUNTING FLOW: If Payment Request status changed to 'Paid', convert directly to OPEX!
      if (newStatus === 'Paid') {
        const opexId = `opx-${Date.now()}`;
        const newOpx: OpexTransaction = {
          id: opexId,
          opexNumber: `OPX-PR-${item.prNumber}`,
          paymentRequestNumber: item.prNumber,
          date: new Date().toISOString().substring(0, 10),
          entityId: 'cung-retail',
          vendorName: item.vendorName,
          category: 'Other Operating Expenses',
          description: `Realisasi PR ${item.prNumber}: ${item.purpose}`,
          nominal: item.subtotal,
          tax: item.tax,
          total: item.grandTotal,
          status: 'Dibayar',
          approver: currentUser.name,
          paymentDate: new Date().toISOString().substring(0, 10),
        };
        setOpex(opxList => [newOpx, ...opxList]);
        addAuditLog('Paid', 'OPEX', newOpx.opexNumber, `Otomatis generate OPEX dari Payment Request ${item.prNumber} yang telah lunas.`);
      }

      return updated;
    });
  };

  // CAPEX Workflow: Draft -> Reviewed -> Approved -> Paid -> Asset Created
  const createCapexRequest = (cpxData: Omit<CapexRequest, 'id' | 'capexNumber'>) => {
    const id = `cpx-${Date.now()}`;
    const capexNumber = `CPX-2026-${Math.floor(100 + Math.random() * 900)}`;
    const newCpx: CapexRequest = {
      ...cpxData,
      id,
      capexNumber,
    };
    setCapexRequests(prev => [newCpx, ...prev]);
    addAuditLog('Created', 'CAPEX Request', capexNumber, `Pengajuan CAPEX: ${cpxData.project} - ${cpxData.description}`);
  };

  const updateCapexStatus = (id: string, newStatus: CapexStatus) => {
    setCapexRequests(prev => {
      const item = prev.find(c => c.id === id);
      if (!item) return prev;

      const updated = prev.map(c => {
        if (c.id === id) {
          const mod = { ...c, status: newStatus };
          if (newStatus === 'Approved') mod.approvedBy = currentUser.name;
          return mod;
        }
        return c;
      });

      addAuditLog(
        newStatus === 'Approved' ? 'Approved' : 'Edited',
        'CAPEX Request',
        item.capexNumber,
        `Status CAPEX Request diubah menjadi ${newStatus} oleh ${currentUser.name}`
      );

      // STRICT ACCOUNTING RULE:
      // When CAPEX becomes 'Asset Created' (or paid/finalized), automatically enter into Asset Register!
      // Depreciation will automatically start in P&L, and CAPEX outflow is tracked in Cash Flow Investing Outflow!
      if (newStatus === 'Asset Created') {
        const monthlyDepr = Math.round(
          (item.acquisitionCost - item.residualValue) / Math.max(1, item.expectedUsefulLifeMonths)
        );
        const newAsset: AssetRecord = {
          id: `ast-${Date.now()}`,
          assetCode: `AST-${item.capexNumber}`,
          assetName: item.description,
          category: item.assetType,
          location: 'Operasional Toko Cung',
          acquisitionDate: item.acquisitionDate,
          acquisitionCost: item.acquisitionCost,
          usefulLifeMonths: item.expectedUsefulLifeMonths,
          residualValue: item.residualValue,
          depreciationMethod: 'Straight Line',
          monthlyDepreciation: monthlyDepr,
          accumulatedDepreciation: 0,
          bookValue: item.acquisitionCost,
          status: 'Active',
          isDemo: false,
        };

        setAssets(assetList => [newAsset, ...assetList]);
        addAuditLog(
          'Created',
          'Asset Register',
          newAsset.assetCode,
          `Aset otomatis terdaftar dari CAPEX ${item.capexNumber} dengan jadwal depresiasi garis lurus Rp ${monthlyDepr.toLocaleString('id-ID')}/bln`
        );
      }

      return updated;
    });
  };

  // Add Asset manually
  const addAsset = (assetData: Omit<AssetRecord, 'id' | 'monthlyDepreciation' | 'accumulatedDepreciation' | 'bookValue'>) => {
    const monthlyDepr = Math.round(
      (assetData.acquisitionCost - assetData.residualValue) / Math.max(1, assetData.usefulLifeMonths)
    );
    const newAsset: AssetRecord = {
      ...assetData,
      id: `ast-${Date.now()}`,
      monthlyDepreciation: monthlyDepr,
      accumulatedDepreciation: 0,
      bookValue: assetData.acquisitionCost,
    };
    setAssets(prev => [newAsset, ...prev]);
    addAuditLog('Created', 'Asset Register', newAsset.assetCode, `Pendaftaran aset baru: ${newAsset.assetName}`);
  };

  // Non-Operating
  const addNonOperating = (nonOpData: Omit<NonOperatingTransaction, 'id'>) => {
    const id = `nop-${Date.now()}`;
    const newNonOp: NonOperatingTransaction = { ...nonOpData, id };
    setNonOperating(prev => [newNonOp, ...prev]);
    addAuditLog('Created', 'Non-Operating', id, `${nonOpData.category}: Rp ${nonOpData.amount.toLocaleString('id-ID')} (${nonOpData.description})`);
  };

  // Tax
  const addTax = (taxData: Omit<TaxTransaction, 'id'>) => {
    const id = `tax-${Date.now()}`;
    const newTax: TaxTransaction = { ...taxData, id };
    setTaxes(prev => [newTax, ...prev]);
    addAuditLog('Created', 'Pajak', id, `Setoran/Perhitungan Pajak Periode ${taxData.taxPeriod}: Rp ${taxData.taxAmount.toLocaleString('id-ID')}`);
  };

  // Payroll
  const addPayroll = (payData: Omit<PayrollRecord, 'id'>) => {
    const id = `pay-${Date.now()}`;
    const newPay: PayrollRecord = { ...payData, id };
    setPayrolls(prev => [newPay, ...prev]);
    addAuditLog('Created', 'Payroll', id, `Penggajian ${payData.employeeName} (${payData.department}): Rp ${payData.netSalary.toLocaleString('id-ID')}`);
  };

  // Kasbon
  const addKasbonTransaction = (txData: Omit<KasbonTransaction, 'id' | 'transactionNumber'>) => {
    const id = `kb-${Date.now()}`;
    const txNum = `KB-2026-${Math.floor(100 + Math.random() * 900)}`;
    const newTx: KasbonTransaction = {
      ...txData,
      id,
      transactionNumber: txNum,
      repaidAmount: 0,
      remainingAmount: txData.amount,
      status: 'Diajukan',
    };
    setKasbonTransactions(prev => [newTx, ...prev]);
    // update debitur current balance
    setDebiturKasbon(prev =>
      prev.map(d => (d.id === txData.debiturId ? { ...d, currentBalance: d.currentBalance + txData.amount } : d))
    );
    addAuditLog('Created', 'Kasbon', txNum, `Pengajuan Kasbon ${txData.debiturName} senilai Rp ${txData.amount.toLocaleString('id-ID')}`);
  };

  const repayKasbon = (txId: string, amount: number) => {
    setKasbonTransactions(prev =>
      prev.map(tx => {
        if (tx.id === txId) {
          const newRepaid = tx.repaidAmount + amount;
          const newRemaining = Math.max(0, tx.amount - newRepaid);
          const newStatus = newRemaining === 0 ? 'Lunas' : 'Sebagian Lunas';
          
          // update debitur balance
          setDebiturKasbon(debs =>
            debs.map(d => (d.id === tx.debiturId ? { ...d, currentBalance: Math.max(0, d.currentBalance - amount) } : d))
          );

          addAuditLog('Paid', 'Kasbon', tx.transactionNumber, `Pembayaran kasbon ${tx.debiturName} sebesar Rp ${amount.toLocaleString('id-ID')}`);
          return {
            ...tx,
            repaidAmount: newRepaid,
            remainingAmount: newRemaining,
            status: newStatus,
          };
        }
        return tx;
      })
    );
  };

  // Cash Mutation
  const addCashMutation = (mutData: Omit<CashMutation, 'id'>) => {
    const id = `mut-${Date.now()}`;
    const newMut: CashMutation = { ...mutData, id };
    setCashMutations(prev => [newMut, ...prev]);
    addAuditLog('Created', 'Mutasi Kas', newMut.referenceNumber, `${mutData.type} ${mutData.account}: Rp ${mutData.amount.toLocaleString('id-ID')}`);
  };

  // Purchase Order
  const addPurchaseOrder = (poData: Omit<PurchaseOrder, 'id'>) => {
    const id = `po-${Date.now()}`;
    const newPo: PurchaseOrder = { ...poData, id };
    setPurchaseOrders(prev => [newPo, ...prev]);
    addAuditLog('Created', 'Purchase Orders', poData.poNumber, `PO ke ${poData.supplierName} total Rp ${poData.totalCost.toLocaleString('id-ID')}`);
  };

  // Price Adjustment
  const addPriceAdjustment = (adjData: Omit<PriceAdjustment, 'id'>) => {
    const id = `pa-${Date.now()}`;
    const newAdj: PriceAdjustment = { ...adjData, id };
    setPriceAdjustments(prev => [newAdj, ...prev]);
    addAuditLog('Created', 'Price Adjustments', adjData.sku, `Perubahan harga ${adjData.productName} dari Rp ${adjData.oldPrice.toLocaleString('id-ID')} ke Rp ${adjData.newPrice.toLocaleString('id-ID')}`);
  };

  // ==========================================
  // INTEGRATION HUB ACTIONS
  // ==========================================
  const runSync = async (platformOrId: string, syncType: SyncType) => {
    const batchId = `sync-${Date.now()}`;
    const startTime = new Date().toISOString();

    // Add in-progress batch
    const newBatch: SyncBatch = {
      id: batchId,
      platform: platformOrId,
      connection_name: platformOrId,
      sync_type: syncType,
      source: 'API_SYNC',
      started_at: startTime,
      status: 'IN_PROGRESS',
      records_synced: 0,
      records_failed: 0,
    };
    setSyncBatches(prev => [newBatch, ...prev]);

    // Simulate real provider API call with normalization
    setTimeout(() => {
      // Find orders to normalize if marketplace
      const unnormalizedOrders = marketplaceOrders.filter(
        o => !sales.some(s => s.external_order_id === o.external_order_id)
      );

      let generatedSales = 0;
      let generatedHpp = 0;

      unnormalizedOrders.forEach(order => {
        const { salesTx, hppRecords } = IntegrationSyncService.normalizeOrderToSalesAndHpp(
          order,
          channelSkuMappings,
          'cung-retail'
        );
        setSales(s => [salesTx, ...s]);
        setHpp(h => [...hppRecords, ...h]);
        generatedSales++;
        generatedHpp += hppRecords.length;
      });

      // Auto reconcile settlements
      const recon = IntegrationSyncService.autoReconcileSettlements(
        bankTransactions,
        marketplaceSettlements,
        integrationSettings.match_tolerance_amount
      );
      setBankTransactions(recon.updatedBankTxList);
      setMarketplaceSettlements(recon.updatedSettlements);

      // Finish batch
      const endTime = new Date().toISOString();
      setSyncBatches(prev =>
        prev.map(b =>
          b.id === batchId
            ? {
                ...b,
                status: 'SUCCESS',
                completed_at: endTime,
                records_synced: Math.max(12, generatedSales * 3 + recon.matchedCount * 2),
              }
            : b
        )
      );

      // Update connection last_sync_at
      setMarketplaceConnections(prev =>
        prev.map(c =>
          c.platform === platformOrId || c.id === platformOrId || platformOrId === 'ALL'
            ? { ...c, last_sync_at: endTime, last_success_at: endTime }
            : c
        )
      );
      setBankConnections(prev =>
        prev.map(c =>
          c.provider === platformOrId || c.id === platformOrId || platformOrId === 'ALL'
            ? { ...c, last_sync_at: endTime }
            : c
        )
      );

      addAuditLog('Created', 'Integration Sync', batchId, `Sync ${platformOrId} selesai: ${generatedSales} sales dan ${recon.matchedCount} rekonsiliasi diproses.`);
    }, 600);
  };

  const importBankCsv = (csvText: string, bankConnectionId: string): number => {
    const { headers, rows } = IntegrationSyncService.parseCsvToRecords(csvText);
    if (rows.length === 0) return 0;

    const targetBank = bankConnections.find(b => b.id === bankConnectionId) || bankConnections[0];
    const newBankTxs: BankTransaction[] = [];

    rows.forEach((r, idx) => {
      const date = r['Date'] || r['Tanggal'] || r['date'] || '2026-03-29';
      const desc = r['Description'] || r['Keterangan'] || r['desc'] || 'CSV Import Mutation';
      const amount = Number((r['Amount'] || r['Nominal'] || r['amount'] || '0').replace(/[^0-9.-]+/g, '')) || 100000;
      const type = (r['Type'] || r['Tipe'] || (desc.toUpperCase().includes('CR') ? 'CR' : 'DB')).toUpperCase() === 'CR' ? 'CR' : 'DB';
      const extId = `CSV-TX-${Date.now()}-${idx}`;

      const categorized = IntegrationSyncService.categorizeBankTransaction(desc, '', bankRules);

      newBankTxs.push({
        id: `btx-csv-${Date.now()}-${idx}`,
        bank_connection_id: targetBank.id,
        bank_name: targetBank.bank_name,
        external_transaction_id: extId,
        transaction_date: date,
        value_date: date,
        description: desc,
        reference_number: r['Reference'] || r['Ref'] || `CSV-REF-${idx}`,
        debit: type === 'DB' ? amount : 0,
        credit: type === 'CR' ? amount : 0,
        amount,
        currency: 'IDR',
        balance: 800000000,
        counterparty: r['Counterparty'] || 'Third Party',
        category: categorized.category,
        transaction_type: type,
        source: 'CSV_IMPORT',
        sync_batch_id: `batch-csv-${Date.now()}`,
        reconciliation_status: 'UNMATCHED',
        suggested_category: categorized.category,
        categorization_status: categorized.status,
        created_at: new Date().toISOString(),
      });
    });

    setBankTransactions(prev => [...newBankTxs, ...prev]);
    addAuditLog('Created', 'Bank Import', bankConnectionId, `Berhasil import ${newBankTxs.length} transaksi bank dari file CSV.`);
    return newBankTxs.length;
  };

  const importMarketplaceCsv = (csvText: string, connectionId: string, platform: any): number => {
    const { headers, rows } = IntegrationSyncService.parseCsvToRecords(csvText);
    if (rows.length === 0) return 0;

    let importedCount = 0;
    rows.forEach((r, idx) => {
      const extOrderId = r['Order ID'] || r['No Pesanan'] || r['order_id'] || `CSV-ORD-${Date.now()}-${idx}`;
      const gross = Number((r['Gross'] || r['Total Pesanan'] || r['Subtotal'] || '500000').replace(/[^0-9.-]+/g, '')) || 500000;
      const fee = Number((r['Fee'] || r['Potongan'] || r['Biaya Layanan'] || '25000').replace(/[^0-9.-]+/g, '')) || 25000;
      const net = gross - fee;
      const date = r['Date'] || r['Tanggal'] || '2026-03-29';

      const order: MarketplaceOrder = {
        id: `mpo-csv-${Date.now()}-${idx}`,
        platform: platform || 'SHOPEE',
        connection_id: connectionId,
        external_order_id: extOrderId,
        order_number: `TC-CSV-${extOrderId}`,
        order_date: date,
        status: 'COMPLETED',
        buyer_reference: r['Buyer'] || r['Pembeli'] || 'Customer CSV',
        currency: 'IDR',
        subtotal: gross,
        discount: 0,
        shipping_fee: 0,
        seller_discount: 0,
        platform_discount: 0,
        voucher: 0,
        tax: 0,
        platform_fee: fee * 0.4,
        commission_fee: fee * 0.6,
        payment_fee: 0,
        other_fee: 0,
        refund_amount: 0,
        gross_sales: gross,
        net_sales: net,
        settlement_amount: net,
        settlement_date: date,
        items: [
          {
            sku: r['SKU'] || 'BRS-PREM-5K',
            product_name: r['Product'] || r['Nama Produk'] || 'Produk Impor CSV',
            qty: 1,
            unit_price: gross,
            total_price: gross,
          },
        ],
        source: 'CSV_IMPORT',
        sync_batch_id: `batch-mp-csv-${Date.now()}`,
        created_at: new Date().toISOString(),
      };

      setMarketplaceOrders(prev => [order, ...prev]);

      // Normalize into internal sales
      const { salesTx, hppRecords } = IntegrationSyncService.normalizeOrderToSalesAndHpp(
        order,
        channelSkuMappings,
        'cung-retail'
      );
      setSales(prev => [salesTx, ...prev]);
      setHpp(prev => [...hppRecords, ...prev]);
      importedCount++;
    });

    addAuditLog('Created', 'Marketplace Import', connectionId, `Berhasil import ${importedCount} pesanan ${platform} dari CSV.`);
    return importedCount;
  };

  const connectBank = (connectionData: Partial<BankConnection>) => {
    const newConn: BankConnection = {
      id: `bnk-${Date.now()}`,
      provider: connectionData.provider || 'BCA_API',
      bank_name: connectionData.bank_name || 'Bank Baru',
      account_name: connectionData.account_name || 'PT TOKO CUNG',
      account_number_masked: connectionData.account_number_masked || '**** **** 9999',
      currency: 'IDR',
      connection_status: 'CONNECTED',
      last_sync_at: new Date().toISOString(),
      api_health: 'HEALTHY',
      records_synced: 0,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    setBankConnections(prev => [...prev, newConn]);
    addAuditLog('Created', 'Bank Connection', newConn.id, `Koneksi bank ${newConn.bank_name} berhasil dibuat.`);
  };

  const disconnectBank = (id: string) => {
    setBankConnections(prev =>
      prev.map(b => (b.id === id ? { ...b, connection_status: 'DISCONNECTED' } : b))
    );
    addAuditLog('Edited', 'Bank Connection', id, `Koneksi bank ${id} diputuskan.`);
  };

  const connectMarketplace = (connectionData: Partial<MarketplaceConnection>) => {
    const newConn: MarketplaceConnection = {
      id: `mp-${Date.now()}`,
      platform: connectionData.platform || 'SHOPEE',
      shop_id: connectionData.shop_id || `shop_${Date.now()}`,
      shop_name: connectionData.shop_name || 'Toko Baru',
      seller_id: connectionData.seller_id || `SEL_${Date.now()}`,
      country: 'ID',
      currency: 'IDR',
      status: 'CONNECTED',
      authorization_status: 'AUTHORIZED',
      api_version: connectionData.api_version || 'v2.0',
      last_sync_at: new Date().toISOString(),
      records_synced: 0,
      records_failed: 0,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    setMarketplaceConnections(prev => [...prev, newConn]);
    addAuditLog('Created', 'Marketplace Connection', newConn.id, `Toko ${newConn.shop_name} (${newConn.platform}) terhubung.`);
  };

  const disconnectMarketplace = (id: string) => {
    setMarketplaceConnections(prev =>
      prev.map(m => (m.id === id ? { ...m, status: 'DISCONNECTED', authorization_status: 'REVOKED' } : m))
    );
    addAuditLog('Edited', 'Marketplace Connection', id, `Koneksi marketplace ${id} diputuskan.`);
  };

  const updateChannelSkuMapping = (id: string, internalSku: string, internalProductId?: string) => {
    setChannelSkuMappings(prev =>
      prev.map(m =>
        m.id === id
          ? {
              ...m,
              internal_sku: internalSku,
              internal_product_id: internalProductId || m.internal_product_id,
              active: internalSku.length > 0,
            }
          : m
      )
    );
    addAuditLog('Edited', 'SKU Mapping', id, `Pemetaan SKU diubah ke internal SKU: ${internalSku}`);
  };

  const reconcileSettlementWithBank = (settlementId: string, bankTxId: string) => {
    const bankTx = bankTransactions.find(b => b.id === bankTxId);
    setMarketplaceSettlements(prev =>
      prev.map(s =>
        s.id === settlementId
          ? {
              ...s,
              reconciliation_status: 'MATCHED',
              bank_transaction_id: bankTxId,
              bank_name: bankTx?.bank_name || 'Bank Rekening Operasional',
            }
          : s
      )
    );
    setBankTransactions(prev =>
      prev.map(b =>
        b.id === bankTxId
          ? {
              ...b,
              reconciliation_status: 'MATCHED',
              matched_internal_id: settlementId,
              matched_internal_type: 'SETTLEMENT',
            }
          : b
      )
    );
    addAuditLog('Approved', 'Reconciliation', settlementId, `Manual match rekonsiliasi settlement dengan mutasi bank ${bankTxId}.`);
  };

  const unmatchReconciliation = (settlementId: string) => {
    const settlement = marketplaceSettlements.find(s => s.id === settlementId);
    const bankTxId = settlement?.bank_transaction_id;

    setMarketplaceSettlements(prev =>
      prev.map(s =>
        s.id === settlementId
          ? { ...s, reconciliation_status: 'RECEIVED', bank_transaction_id: undefined }
          : s
      )
    );
    if (bankTxId) {
      setBankTransactions(prev =>
        prev.map(b =>
          b.id === bankTxId
            ? { ...b, reconciliation_status: 'UNMATCHED', matched_internal_id: undefined, matched_internal_type: undefined }
            : b
        )
      );
    }
    addAuditLog('Rejected', 'Reconciliation', settlementId, `Batalkan rekonsiliasi settlement ${settlementId}.`);
  };

  const executeAutoMatch = (): number => {
    const recon = IntegrationSyncService.autoReconcileSettlements(
      bankTransactions,
      marketplaceSettlements,
      integrationSettings.match_tolerance_amount
    );
    setBankTransactions(recon.updatedBankTxList);
    setMarketplaceSettlements(recon.updatedSettlements);
    addAuditLog('Approved', 'Reconciliation', 'AUTO-MATCH', `Auto-match berhasil mencocokkan ${recon.matchedCount} transaksi settlement.`);
    return recon.matchedCount;
  };

  const updateIntegrationSettings = (newSettings: Partial<IntegrationSettings>) => {
    setIntegrationSettings(prev => ({ ...prev, ...newSettings }));
    addAuditLog('Edited', 'Integration Settings', 'CFG-INTEG', `Pengaturan integrasi diperbarui.`);
  };

  const addWebhookSimulation = (provider: string, eventType: string, payload: any) => {
    const newEvent: IntegrationRawEvent = {
      id: `raw-${Date.now()}`,
      provider,
      connection_id: `${provider.toLowerCase()}-live`,
      event_type: eventType,
      external_event_id: `evt-${Date.now()}`,
      payload,
      signature_valid: true,
      processed: true,
      processing_status: 'SUCCESS',
      received_at: new Date().toISOString(),
      processed_at: new Date().toISOString(),
    };
    setRawEvents(prev => [newEvent, ...prev]);
    addAuditLog('Created', 'Webhook', newEvent.external_event_id, `Webhook ${eventType} diterima dan diproses dari ${provider}.`);
  };

  // Reactive Derived Values
  const currentMonthPnl = useMemo(() => {
    return calculatePnlForMonth(
      globalFilter.month,
      globalFilter.year,
      globalFilter.entityId,
      sales,
      hpp,
      opex,
      assets,
      nonOperating,
      settings.taxRatePercent,
      globalFilter.channel
    );
  }, [globalFilter.month, globalFilter.year, globalFilter.entityId, globalFilter.channel, sales, hpp, opex, assets, nonOperating, settings.taxRatePercent]);

  const prevMonthPnl = useMemo(() => {
    const prevM = globalFilter.month === 1 ? 12 : globalFilter.month - 1;
    const prevY = globalFilter.month === 1 ? globalFilter.year - 1 : globalFilter.year;
    return calculatePnlForMonth(
      prevM,
      prevY,
      globalFilter.entityId,
      sales,
      hpp,
      opex,
      assets,
      nonOperating,
      settings.taxRatePercent,
      globalFilter.channel
    );
  }, [globalFilter.month, globalFilter.year, globalFilter.entityId, globalFilter.channel, sales, hpp, opex, assets, nonOperating, settings.taxRatePercent]);

  const prevYearPnl = useMemo(() => {
    return calculatePnlForMonth(
      globalFilter.month,
      globalFilter.year - 1,
      globalFilter.entityId,
      sales,
      hpp,
      opex,
      assets,
      nonOperating,
      settings.taxRatePercent,
      globalFilter.channel
    );
  }, [globalFilter.month, globalFilter.year, globalFilter.entityId, globalFilter.channel, sales, hpp, opex, assets, nonOperating, settings.taxRatePercent]);

  // All 12 months for charts and trend lines
  const twelveMonthsPnl = useMemo(() => {
    const list: PnlSummary[] = [];
    for (let m = 1; m <= 12; m++) {
      list.push(
        calculatePnlForMonth(
          m,
          globalFilter.year,
          globalFilter.entityId,
          sales,
          hpp,
          opex,
          assets,
          nonOperating,
          settings.taxRatePercent,
          globalFilter.channel
        )
      );
    }
    return list;
  }, [globalFilter.year, globalFilter.entityId, globalFilter.channel, sales, hpp, opex, assets, nonOperating, settings.taxRatePercent]);

  // Yearly Aggregation
  const yearlyPnlSummary = useMemo((): PnlSummary => {
    const totalSales = twelveMonthsPnl.reduce((acc, p) => acc + p.sales, 0);
    const totalHpp = twelveMonthsPnl.reduce((acc, p) => acc + p.hpp, 0);
    const grossProfit = totalSales - totalHpp;
    const totalOpex = twelveMonthsPnl.reduce((acc, p) => acc + p.totalOpex, 0);
    const ebitda = grossProfit - totalOpex;
    const totalDepreciation = twelveMonthsPnl.reduce((acc, p) => acc + p.totalDepreciation, 0);
    const ebit = ebitda - totalDepreciation;
    const nonOperatingIncome = twelveMonthsPnl.reduce((acc, p) => acc + p.nonOperatingIncome, 0);
    const nonOperatingExpense = twelveMonthsPnl.reduce((acc, p) => acc + p.nonOperatingExpense, 0);
    const netNonOperating = nonOperatingIncome - nonOperatingExpense;
    const ebt = ebit + netNonOperating;
    const incomeTax = twelveMonthsPnl.reduce((acc, p) => acc + p.incomeTax, 0);
    const netProfit = ebt - incomeTax;

    return {
      sales: totalSales,
      hpp: totalHpp,
      grossProfit,
      grossMarginPct: totalSales > 0 ? (grossProfit / totalSales) * 100 : 0,
      totalOpex,
      ebitda,
      ebitdaMarginPct: totalSales > 0 ? (ebitda / totalSales) * 100 : 0,
      totalDepreciation,
      ebit,
      ebitMarginPct: totalSales > 0 ? (ebit / totalSales) * 100 : 0,
      nonOperatingIncome,
      nonOperatingExpense,
      netNonOperating,
      ebt,
      incomeTax,
      netProfit,
      netProfitMarginPct: totalSales > 0 ? (netProfit / totalSales) * 100 : 0,
    };
  }, [twelveMonthsPnl]);

  // Income Statement Matrix
  const monthlyPnlTable = useMemo(() => {
    return generateMonthlyIncomeStatementTable(
      globalFilter.year,
      globalFilter.entityId,
      sales,
      hpp,
      opex,
      assets,
      nonOperating,
      settings.taxRatePercent,
      globalFilter.channel
    );
  }, [globalFilter.year, globalFilter.entityId, globalFilter.channel, sales, hpp, opex, assets, nonOperating, settings.taxRatePercent]);

  // Cash Flow Statement
  const cashFlowStatement = useMemo(() => {
    return calculateCashFlowStatement(currentMonthPnl, capexRequests, 850_000_000);
  }, [currentMonthPnl, capexRequests]);

  const value = {
    entities,
    users,
    currentUser,
    setCurrentUser,
    products,
    customers,
    vendors,
    sales,
    hpp,
    opex,
    paymentRequests,
    capexRequests,
    assets,
    nonOperating,
    taxes,
    payrolls,
    debiturKasbon,
    kasbonTransactions,
    cashMutations,
    purchaseOrders,
    priceAdjustments,
    budgets,
    auditLogs,

    // Integration Hub
    bankConnections,
    bankTransactions,
    marketplaceConnections,
    marketplaceOrders,
    marketplaceTransactions,
    channelSkuMappings,
    marketplaceSettlements,
    syncBatches,
    rawEvents,
    feeMappings,
    bankRules,
    integrationSettings,

    globalFilter,
    setGlobalFilter,
    resetFilter,
    settings,
    updateSettings,
    resetToDemoData,
    addSales,
    addHpp,
    addOpex,
    createPaymentRequest,
    updatePaymentRequestStatus,
    createCapexRequest,
    updateCapexStatus,
    addAsset,
    addNonOperating,
    addTax,
    addPayroll,
    addKasbonTransaction,
    repayKasbon,
    addCashMutation,
    addPurchaseOrder,
    addPriceAdjustment,

    // Integration actions
    runSync,
    importBankCsv,
    importMarketplaceCsv,
    connectBank,
    disconnectBank,
    connectMarketplace,
    disconnectMarketplace,
    updateChannelSkuMapping,
    reconcileSettlementWithBank,
    unmatchReconciliation,
    executeAutoMatch,
    updateIntegrationSettings,
    addWebhookSimulation,

    currentMonthPnl,
    prevMonthPnl,
    prevYearPnl,
    yearlyPnlSummary,
    monthlyPnlTable,
    cashFlowStatement,
    twelveMonthsPnl,
    hasRole,
  };

  return <FinanceContext.Provider value={value}>{children}</FinanceContext.Provider>;
};

export const useFinance = () => {
  const context = useContext(FinanceContext);
  if (!context) {
    throw new Error('useFinance must be used within a FinanceProvider');
  }
  return context;
};
