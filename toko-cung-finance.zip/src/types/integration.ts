/**
 * Types for Integration Hub Toko Cung Finance
 * Bank (Open Banking / SNAP / CSV), Shopee, TikTok Shop, Tokopedia, etc.
 */

export type IntegrationPlatform =
  | 'SHOPEE'
  | 'TIKTOK_SHOP'
  | 'TOKOPEDIA'
  | 'LAZADA'
  | 'BLIBLI'
  | 'SHOPIFY'
  | 'OTHER';

export type BankProvider =
  | 'BCA_API'
  | 'MANDIRI_API'
  | 'BRI_OPEN_BANKING'
  | 'BNI_OPEN_BANKING'
  | 'SNAP_BI'
  | 'OPEN_BANKING_AGGREGATOR'
  | 'MANUAL_CSV';

export type ConnectionStatus =
  | 'CONNECTED'
  | 'SYNCING'
  | 'WARNING'
  | 'ERROR'
  | 'DISCONNECTED';

export type ReconciliationStatus =
  | 'UNMATCHED'
  | 'MATCHED'
  | 'PARTIAL'
  | 'DUPLICATE'
  | 'IGNORED';

export type SettlementStatus =
  | 'PENDING'
  | 'RECEIVED'
  | 'MATCHED'
  | 'PARTIAL'
  | 'DISPUTED';

export type MarketplaceTxType =
  | 'SALE'
  | 'REFUND'
  | 'SHIPPING'
  | 'COMMISSION'
  | 'SERVICE_FEE'
  | 'TRANSACTION_FEE'
  | 'TAX'
  | 'VOUCHER'
  | 'ADJUSTMENT'
  | 'SETTLEMENT';

export type SyncType = 'ORDERS' | 'FINANCE_FEES' | 'SETTLEMENTS' | 'BANK_TRANSACTIONS' | 'FULL_SYNC';
export type SyncSource = 'API_SYNC' | 'CSV_IMPORT' | 'WEBHOOK';

// ==========================================
// E. BANK CONNECTIONS
// ==========================================
export interface BankConnection {
  id: string;
  provider: BankProvider;
  bank_name: string; // e.g. "Bank Central Asia (BCA)", "Bank Mandiri"
  account_name: string; // e.g. "PT TOKO CUNG RETAIL"
  account_number_masked: string; // e.g. "**** **** 1234"
  currency: string; // 'IDR'
  connection_status: ConnectionStatus;
  access_token_encrypted?: string; // encrypted server-side token reference
  refresh_token_encrypted?: string;
  token_expired_at?: string;
  last_sync_at?: string;
  next_sync_at?: string;
  api_health?: 'HEALTHY' | 'DEGRADED' | 'DOWN';
  records_synced?: number;
  created_at: string;
  updated_at: string;
}

// ==========================================
// F. BANK TRANSACTION
// ==========================================
export interface BankTransaction {
  id: string;
  bank_connection_id: string;
  bank_name?: string;
  external_transaction_id: string;
  transaction_date: string; // YYYY-MM-DD
  value_date: string;
  description: string;
  reference_number: string;
  debit: number; // Pengeluaran
  credit: number; // Penerimaan
  amount: number; // absolute amount
  currency: string;
  balance: number;
  counterparty: string;
  category: string;
  sub_category?: string;
  transaction_type: 'CR' | 'DB';
  source: SyncSource;
  raw_payload?: Record<string, any>;
  sync_batch_id: string;
  reconciliation_status: ReconciliationStatus;
  matched_internal_id?: string;
  matched_internal_type?: 'SETTLEMENT' | 'SALES' | 'OPEX' | 'CAPEX' | 'MUTATION';
  suggested_category?: string;
  categorization_status?: 'AUTO_MATCH' | 'REVIEW' | 'CONFIRM';
  created_at: string;
}

// ==========================================
// L. MARKETPLACE CONNECTIONS
// ==========================================
export interface MarketplaceConnection {
  id: string;
  platform: IntegrationPlatform;
  shop_id: string;
  shop_name: string;
  seller_id: string;
  country: string; // 'ID'
  currency: string; // 'IDR'
  status: ConnectionStatus;
  authorization_status: 'AUTHORIZED' | 'PENDING_AUTH' | 'EXPIRED' | 'REVOKED';
  api_version: string; // e.g. "v2.0", "v202309", "v1"
  access_token_encrypted?: string;
  refresh_token_encrypted?: string;
  token_expires_at?: string;
  last_sync_at?: string;
  last_success_at?: string;
  last_error_at?: string;
  last_error_message?: string;
  records_synced?: number;
  records_failed?: number;
  created_at: string;
  updated_at: string;
}

// ==========================================
// M. MARKETPLACE ORDER
// ==========================================
export interface MarketplaceOrderItem {
  sku: string;
  product_name: string;
  qty: number;
  unit_price: number;
  total_price: number;
  internal_sku?: string;
}

export interface MarketplaceOrder {
  id: string;
  platform: IntegrationPlatform;
  connection_id: string;
  external_order_id: string;
  order_number: string;
  order_date: string;
  status: 'PENDING' | 'CONFIRMED' | 'SHIPPED' | 'DELIVERED' | 'COMPLETED' | 'CANCELLED' | 'RETURNED';
  buyer_reference?: string;
  currency: string;
  subtotal: number;
  discount: number;
  shipping_fee: number;
  seller_discount: number;
  platform_discount: number;
  voucher: number;
  tax: number;
  platform_fee: number;
  commission_fee: number;
  payment_fee: number;
  other_fee: number;
  refund_amount: number;
  gross_sales: number; // subtotal
  net_sales: number; // gross_sales - seller_discount - voucher - refund_amount
  settlement_amount: number;
  settlement_date?: string;
  items: MarketplaceOrderItem[];
  source: SyncSource;
  raw_payload?: Record<string, any>;
  sync_batch_id: string;
  created_at: string;
}

// ==========================================
// N. NORMALIZED MARKETPLACE TRANSACTION
// ==========================================
export interface MarketplaceTransaction {
  id: string;
  platform: IntegrationPlatform;
  connection_id: string;
  external_transaction_id: string;
  external_order_id?: string;
  transaction_date: string;
  transaction_type: MarketplaceTxType;
  gross_amount: number;
  discount_amount: number;
  shipping_amount: number;
  fee_amount: number;
  tax_amount: number;
  refund_amount: number;
  net_amount: number;
  currency: string;
  category: string;
  sub_category?: string;
  source: SyncSource;
  raw_payload?: Record<string, any>;
  created_at: string;
}

// ==========================================
// O. CHANNEL SKU MAPPING
// ==========================================
export interface ChannelSkuMapping {
  id: string;
  platform: IntegrationPlatform;
  connection_id: string;
  external_sku: string;
  external_product_name: string;
  internal_product_id: string;
  internal_sku: string;
  hpp_method: 'FIFO' | 'AVERAGE' | 'STANDARD_COST';
  active: boolean;
  unit_hpp_estimate: number;
}

// ==========================================
// P. MARKETPLACE SETTLEMENT
// ==========================================
export interface MarketplaceSettlement {
  id: string;
  platform: IntegrationPlatform;
  connection_id: string;
  settlement_id: string;
  settlement_period_start: string;
  settlement_period_end: string;
  gross_sales: number;
  discount: number;
  shipping: number;
  commission: number;
  service_fee: number;
  transaction_fee: number;
  tax: number;
  refund: number;
  adjustment: number;
  net_settlement: number;
  settlement_date: string;
  bank_transaction_id?: string;
  bank_name?: string;
  reconciliation_status: SettlementStatus;
  notes?: string;
  created_at: string;
}

// ==========================================
// X. RAW DATA STORAGE & WEBHOOK EVENTS
// ==========================================
export interface IntegrationRawEvent {
  id: string;
  provider: string; // 'SHOPEE' | 'TIKTOK' | 'TOKOPEDIA' | 'BCA' | etc.
  connection_id: string;
  event_type: string; // 'ORDER_STATUS_UPDATE' | 'SETTLEMENT_CREATED' | 'BANK_MUTATION_CR'
  external_event_id: string;
  payload: Record<string, any>;
  signature_valid: boolean;
  processed: boolean;
  processing_status: 'SUCCESS' | 'FAILED' | 'PENDING' | 'SKIPPED';
  error_message?: string;
  received_at: string;
  processed_at?: string;
}

// ==========================================
// SYNC CENTER & LOGS
// ==========================================
export interface SyncBatch {
  id: string;
  platform: string;
  connection_name: string;
  sync_type: SyncType;
  source: SyncSource;
  date_range_start?: string;
  date_range_end?: string;
  started_at: string;
  completed_at?: string;
  status: 'IN_PROGRESS' | 'SUCCESS' | 'PARTIAL' | 'FAILED';
  records_synced: number;
  records_failed: number;
  error_details?: string;
}

// ==========================================
// Z. ACCOUNTING MAPPING RULES
// ==========================================
export interface FeeCategoryMapping {
  id: string;
  fee_type: string; // 'Shopee Commission', 'TikTok Service Fee', etc.
  platform: IntegrationPlatform;
  accounting_category: string; // e.g. 'Selling Expense - Marketplace Commission'
  chart_of_account_code: string; // e.g. '6-1020'
}

export interface BankAutoRule {
  id: string;
  keyword: string; // e.g. 'SHOPEE', 'TIKTOK', 'TOKOPEDIA', 'J&T'
  match_field: 'description' | 'counterparty';
  suggested_category: string;
  suggested_type: 'CR' | 'DB';
  auto_confirm: boolean;
}

// ==========================================
// AI. SETTINGS
// ==========================================
export interface IntegrationSettings {
  default_currency: string;
  timezone: string; // 'Asia/Jakarta'
  sync_frequency: '15_MIN' | '30_MIN' | '1_HOUR' | 'DAILY';
  retry_limit: number;
  timeout_seconds: number;
  auto_match_enabled: boolean;
  match_tolerance_percent: number; // e.g. 1%
  match_tolerance_amount: number; // e.g. 50000 IDR
  default_entity_id: string;
  default_bank_account_id: string;
  webhook_signature_secret_configured: boolean;
  open_banking_configured: boolean;
  shopee_app_configured: boolean;
  tiktok_app_configured: boolean;
  tokopedia_app_configured: boolean;
}
