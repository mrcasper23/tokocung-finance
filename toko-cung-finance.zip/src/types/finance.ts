export type UserRole = 'Director' | 'Finance' | 'Operations' | 'Accounting' | 'Viewer';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  department: string;
  avatar?: string;
  active: boolean;
}

export type EntityId = 'ALL' | 'cung-retail' | 'cung-distribusi' | 'cung-flagship';

export interface Entity {
  id: string;
  code: string;
  name: string;
  type: string;
  location: string;
}

export interface Customer {
  id: string;
  name: string;
  category: 'Retail' | 'Wholesale' | 'Corporate';
  phone: string;
  email: string;
  address: string;
}

export interface Vendor {
  id: string;
  name: string;
  category: string;
  phone: string;
  email: string;
  bankAccount: string;
}

export interface Product {
  id: string;
  sku: string;
  name: string;
  category: string;
  unit: string;
  sellingPrice: number;
  costPrice: number;
}

export type SalesChannel = 'ALL' | 'OFFLINE' | 'WEBSITE' | 'SHOPEE' | 'TIKTOK_SHOP' | 'TOKOPEDIA' | 'OTHER';

export interface SalesTransaction {
  id: string;
  transactionNumber: string;
  date: string; // YYYY-MM-DD
  entityId: string;
  customerName: string;
  productName: string;
  productCategory: string;
  qty: number;
  unitPrice: number;
  discount: number;
  totalSales: number;
  status: 'Lunas' | 'Belum Lunas' | 'Dibatalkan';
  isDemo?: boolean;
  salesChannel?: SalesChannel;
  external_order_id?: string;
  external_channel_id?: string;
  source_platform?: string;
  marketplace_fee?: number;
}

export interface HppRecord {
  id: string;
  date: string;
  sku: string;
  productName: string;
  qty: number;
  unitCost: number;
  totalHpp: number; // qty * unitCost
  supplierName: string;
  poNumber: string;
  referenceNumber: string;
  isDemo?: boolean;
}

export type OpexCategoryName =
  | 'ATK'
  | 'Advertisement'
  | 'Gaji'
  | 'Utilities'
  | 'Insurance'
  | 'Internet'
  | 'Maintenance'
  | 'Transportation'
  | 'Tunjangan'
  | 'Administrasi'
  | 'Professional Fee'
  | 'Server'
  | 'Logistik'
  | 'Other Operating Expenses';

export interface OpexTransaction {
  id: string;
  opexNumber: string;
  paymentRequestNumber?: string;
  date: string;
  entityId: string;
  vendorName: string;
  category: OpexCategoryName;
  description: string;
  nominal: number;
  tax: number;
  total: number;
  status: 'Draft' | 'Diajukan' | 'Disetujui' | 'Dibayar';
  attachment?: string;
  approver?: string;
  paymentDate?: string;
  isDemo?: boolean;
}

export type PaymentRequestStatus =
  | 'Draft'
  | 'Submitted'
  | 'Reviewed'
  | 'Approved'
  | 'Paid'
  | 'Completed';

export interface PaymentRequestItem {
  id: string;
  description: string;
  qty: number;
  unit: string;
  price: number;
  total: number;
}

export interface PaymentRequest {
  id: string;
  prNumber: string;
  requestor: string;
  department: string;
  purpose: string;
  dueDate: string;
  priority: 'Rendah' | 'Sedang' | 'Tinggi';
  vendorName: string;
  invoiceNumber: string;
  invoiceDate: string;
  items: PaymentRequestItem[];
  subtotal: number;
  tax: number;
  grandTotal: number;
  attachment?: string;
  status: PaymentRequestStatus;
  reviewedBy?: string;
  approvedBy?: string;
  createdAt: string;
  isDemo?: boolean;
}

export type CapexStatus =
  | 'Draft'
  | 'Reviewed'
  | 'Approved'
  | 'Paid'
  | 'Asset Created';

export interface CapexRequest {
  id: string;
  capexNumber: string;
  requestor: string;
  project: string;
  description: string;
  vendorName: string;
  assetType: string;
  acquisitionDate: string;
  acquisitionCost: number;
  expectedUsefulLifeMonths: number;
  residualValue: number;
  depreciationMethod: 'Straight Line';
  status: CapexStatus;
  approvedBy?: string;
  isDemo?: boolean;
}

export type AssetStatus =
  | 'Active'
  | 'Disposed'
  | 'Sold'
  | 'Under Maintenance'
  | 'Fully Depreciated';

export interface AssetRecord {
  id: string;
  assetCode: string;
  assetName: string;
  category: string;
  location: string;
  acquisitionDate: string;
  acquisitionCost: number;
  usefulLifeMonths: number;
  residualValue: number;
  depreciationMethod: 'Straight Line';
  monthlyDepreciation: number;
  accumulatedDepreciation: number;
  bookValue: number;
  status: AssetStatus;
  isDemo?: boolean;
}

export interface DepreciationScheduleItem {
  id: string;
  assetId: string;
  assetCode: string;
  assetName: string;
  year: number;
  month: number; // 1-12
  monthlyAmount: number;
  accumulatedAmount: number;
  bookValueAfter: number;
  status: 'Posted' | 'Scheduled';
}

export interface NonOperatingTransaction {
  id: string;
  date: string;
  category: 'Pendapatan Bunga' | 'Beban Bunga' | 'Pendapatan Lainnya' | 'Beban Lainnya';
  amount: number;
  description: string;
  entityId: string;
  isDemo?: boolean;
}

export interface TaxTransaction {
  id: string;
  taxPeriod: string; // e.g. "2026-03"
  taxBase: number;
  taxRate: number; // e.g. 22
  taxAmount: number;
  status: 'Dihitung' | 'Disetor' | 'Tertunda';
  paymentDate?: string;
  notes?: string;
  isDemo?: boolean;
}

export interface PayrollRecord {
  id: string;
  period: string; // YYYY-MM
  employeeName: string;
  department: string;
  baseSalary: number;
  allowances: number;
  deductions: number; // BPJS + PPh21
  netSalary: number;
  status: 'Draft' | 'Disetujui' | 'Dibayar';
  paymentDate?: string;
  isDemo?: boolean;
}

export interface KasbonDebitur {
  id: string;
  employeeName: string;
  department: string;
  phone: string;
  ceilingLimit: number;
  currentBalance: number;
  status: 'Aktif' | 'Ditangguhkan';
}

export interface KasbonTransaction {
  id: string;
  transactionNumber: string;
  debiturId: string;
  debiturName: string;
  date: string;
  purpose: string;
  amount: number;
  repaidAmount: number;
  remainingAmount: number;
  status: 'Diajukan' | 'Disetujui' | 'Sebagian Lunas' | 'Lunas';
  isDemo?: boolean;
}

export interface CashMutation {
  id: string;
  date: string;
  account: 'BCA Operasional' | 'Mandiri Bisnis' | 'Kas Kecil (Petty Cash)';
  type: 'Masuk' | 'Keluar';
  category: string;
  amount: number;
  balanceAfter: number;
  description: string;
  referenceNumber: string;
  isDemo?: boolean;
}

export interface PurchaseOrder {
  id: string;
  poNumber: string;
  date: string;
  supplierName: string;
  totalItems: number;
  totalCost: number;
  status: 'Draft' | 'Dipesan' | 'Diterima Sebagian' | 'Diterima Lengkap' | 'Dibatalkan';
  receivedDate?: string;
  isDemo?: boolean;
}

export interface PriceAdjustment {
  id: string;
  sku: string;
  productName: string;
  oldPrice: number;
  newPrice: number;
  effectiveDate: string;
  reason: string;
  status: 'Aktif' | 'Dijadwalkan' | 'Ditolak';
  isDemo?: boolean;
}

export interface BudgetRecord {
  id: string;
  year: number;
  month: number; // 0 for full year, 1-12 for specific month
  entityId: string;
  category: string;
  department: string;
  type: 'Sales' | 'OPEX' | 'CAPEX';
  budgetAmount: number;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  action: 'Created' | 'Edited' | 'Submitted' | 'Approved' | 'Rejected' | 'Paid' | 'Cancelled';
  module: string;
  recordId: string;
  userName: string;
  userRole: UserRole;
  details: string;
}

export interface GlobalFilter {
  entityId: string;
  channel?: SalesChannel; // Filter by channel (ALL, OFFLINE, SHOPEE, TIKTOK_SHOP, TOKOPEDIA, WEBSITE)
  period: 'Bulanan' | 'YTD' | 'Q1' | 'Q2' | 'Q3' | 'Q4';
  month: number; // 1-12
  year: number; // e.g. 2026
}

export interface MonthlyPnlRow {
  label: string;
  level: 'sales' | 'cogs' | 'gross_profit' | 'gross_margin' | 'opex' | 'ebitda' | 'depreciation' | 'ebit' | 'non_operating' | 'ebt' | 'tax' | 'net_profit' | 'net_margin';
  isHeader?: boolean;
  isTotal?: boolean;
  isPercentage?: boolean;
  isIndent?: boolean;
  values: number[]; // 12 elements (months 0-11)
  ytd: number;
}

export interface CashFlowStatementData {
  beginningCash: number;
  operatingCashFlow: {
    netProfit: number;
    depreciation: number;
    workingCapitalChange: number;
    total: number;
  };
  investingCashFlow: {
    capexOutflow: number; // negative
    total: number;
  };
  financingCashFlow: {
    debtMovement: number;
    equityMovement: number;
    total: number;
  };
  netCashFlow: number;
  endingCash: number;
}
